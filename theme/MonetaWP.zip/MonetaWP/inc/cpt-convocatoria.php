<?php
/**
 * Custom Post Type: convocatoria
 * Taxonomías: tipo_ayuda, comunidad_autonoma, beneficiario
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', 'mw_register_cpt_convocatoria' );
function mw_register_cpt_convocatoria() {

    // ── CPT: convocatoria ─────────────────────────────────────────────────────
    $labels = [
        'name'               => __( 'Convocatorias',             'monetawp' ),
        'singular_name'      => __( 'Convocatoria',              'monetawp' ),
        'add_new'            => __( 'Añadir nueva',              'monetawp' ),
        'add_new_item'       => __( 'Añadir nueva convocatoria', 'monetawp' ),
        'edit_item'          => __( 'Editar convocatoria',       'monetawp' ),
        'new_item'           => __( 'Nueva convocatoria',        'monetawp' ),
        'view_item'          => __( 'Ver convocatoria',          'monetawp' ),
        'search_items'       => __( 'Buscar convocatorias',      'monetawp' ),
        'not_found'          => __( 'No se encontraron convocatorias', 'monetawp' ),
        'not_found_in_trash' => __( 'No hay convocatorias en la papelera', 'monetawp' ),
        'menu_name'          => __( 'Convocatorias',             'monetawp' ),
    ];

    register_post_type( 'convocatoria', [
        'labels'        => $labels,
        'public'        => true,
        'has_archive'   => true,
        'rewrite'       => [ 'slug' => 'convocatorias', 'with_front' => false ],
        'supports'      => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'revisions' ],
        'show_in_rest'  => true,
        'menu_icon'     => 'dashicons-money-alt',
        'menu_position' => 5,
        'taxonomies'    => [ 'tipo_ayuda', 'comunidad_autonoma', 'beneficiario' ],
        'show_in_nav_menus' => true,
    ] );

    // ── Taxonomía: tipo_ayuda (jerárquica) ────────────────────────────────────
    register_taxonomy( 'tipo_ayuda', [ 'convocatoria', 'post' ], [
        'labels' => [
            'name'          => __( 'Tipos de Ayuda',    'monetawp' ),
            'singular_name' => __( 'Tipo de Ayuda',     'monetawp' ),
            'all_items'     => __( 'Todos los tipos',   'monetawp' ),
            'edit_item'     => __( 'Editar tipo',       'monetawp' ),
            'add_new_item'  => __( 'Añadir tipo',       'monetawp' ),
        ],
        'hierarchical'      => true,
        'public'            => true,
        'show_in_rest'      => true,
        'rewrite'           => [ 'slug' => 'tipo-ayuda', 'with_front' => false ],
        'show_admin_column' => true,
    ] );

    // ── Taxonomía: comunidad_autonoma (plana) ─────────────────────────────────
    register_taxonomy( 'comunidad_autonoma', [ 'convocatoria', 'post' ], [
        'labels' => [
            'name'          => __( 'Comunidades Autónomas', 'monetawp' ),
            'singular_name' => __( 'Comunidad Autónoma',   'monetawp' ),
            'all_items'     => __( 'Todas las comunidades', 'monetawp' ),
            'edit_item'     => __( 'Editar comunidad',      'monetawp' ),
            'add_new_item'  => __( 'Añadir comunidad',      'monetawp' ),
        ],
        'hierarchical'      => false,
        'public'            => true,
        'show_in_rest'      => true,
        'rewrite'           => [ 'slug' => 'comunidad', 'with_front' => false ],
        'show_admin_column' => true,
    ] );

    // ── Taxonomía: beneficiario (plana) ───────────────────────────────────────
    register_taxonomy( 'beneficiario', [ 'convocatoria', 'post' ], [
        'labels' => [
            'name'          => __( 'Beneficiarios',           'monetawp' ),
            'singular_name' => __( 'Beneficiario',            'monetawp' ),
            'all_items'     => __( 'Todos los beneficiarios', 'monetawp' ),
            'edit_item'     => __( 'Editar beneficiario',     'monetawp' ),
            'add_new_item'  => __( 'Añadir beneficiario',     'monetawp' ),
        ],
        'hierarchical'      => false,
        'public'            => true,
        'show_in_rest'      => true,
        'rewrite'           => [ 'slug' => 'beneficiario', 'with_front' => false ],
        'show_admin_column' => true,
    ] );
}

// ── Insertar términos por defecto al activar el tema ─────────────────────────
add_action( 'after_switch_theme', 'mw_insert_default_terms' );
function mw_insert_default_terms() {

    // Tipos de ayuda
    $tipos = [ 'Becas', 'Subvenciones', 'Convocatorias', 'Préstamos', 'Bonificaciones', 'Deducciones Fiscales' ];
    foreach ( $tipos as $tipo ) {
        if ( ! term_exists( $tipo, 'tipo_ayuda' ) ) {
            wp_insert_term( $tipo, 'tipo_ayuda' );
        }
    }

    // Comunidades Autónomas
    $ccaa = [
        'Andalucía', 'Aragón', 'Asturias', 'Islas Baleares', 'Canarias',
        'Cantabria', 'Castilla-La Mancha', 'Castilla y León', 'Cataluña',
        'Extremadura', 'Galicia', 'La Rioja', 'Comunidad de Madrid',
        'Región de Murcia', 'Navarra', 'País Vasco', 'Comunitat Valenciana',
        'Ceuta', 'Melilla', 'Nacional',
    ];
    foreach ( $ccaa as $comunidad ) {
        if ( ! term_exists( $comunidad, 'comunidad_autonoma' ) ) {
            wp_insert_term( $comunidad, 'comunidad_autonoma' );
        }
    }

    // Beneficiarios
    $beneficiarios = [
        'Estudiantes', 'Autónomos', 'PYMES', 'Emprendedores',
        'Familias', 'Desempleados', 'Mayores de 45 años',
        'Personas con Discapacidad', 'Agricultores', 'Artistas',
    ];
    foreach ( $beneficiarios as $beneficiario ) {
        if ( ! term_exists( $beneficiario, 'beneficiario' ) ) {
            wp_insert_term( $beneficiario, 'beneficiario' );
        }
    }
}
