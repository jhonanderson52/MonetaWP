<?php
/**
 * Registrar bloques Gutenberg custom del tema.
 * Los bloques usan render callbacks PHP (server-side rendering).
 */

defined( 'ABSPATH' ) || exit;

// ── Registrar categoría de bloques ────────────────────────────────────────────
add_filter( 'block_categories_all', 'mw_block_categories', 10, 2 );
function mw_block_categories( $categories, $editor_context ) {
    return array_merge(
        [
            [
                'slug'  => 'monetawp',
                'title' => __( 'Ayudas España', 'monetawp' ),
                'icon'  => 'money-alt',
            ],
        ],
        $categories
    );
}

// ── Registrar bloques ─────────────────────────────────────────────────────────
add_action( 'init', 'mw_register_blocks' );
function mw_register_blocks() {

    $blocks = [ 'ayuda-card', 'requisitos-list', 'deadline-banner', 'cta-whatsapp' ];

    foreach ( $blocks as $block ) {
        $block_dir = MW_DIR . '/blocks/' . $block;
        if ( file_exists( $block_dir . '/block.json' ) ) {
            register_block_type( $block_dir );
        }
    }

    // Encolar script de bloques en el editor
    wp_register_script(
        'ae-blocks',
        MW_ASSETS . '/js/blocks.js',
        [ 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ],
        MW_VERSION,
        true
    );
}

// ── Encolar assets del editor ─────────────────────────────────────────────────
add_action( 'enqueue_block_editor_assets', 'mw_enqueue_block_editor_assets' );
function mw_enqueue_block_editor_assets() {
    wp_enqueue_script( 'ae-blocks' );
    wp_enqueue_style(
        'ae-editor',
        MW_ASSETS . '/css/editor.css',
        [ 'wp-edit-blocks' ],
        MW_VERSION
    );
}
