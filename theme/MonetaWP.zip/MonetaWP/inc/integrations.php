<?php
/**
 * Integraciones externas — Google Search Console, GA4, GTM, Bing,
 * Facebook Pixel, ads.txt y app-ads.txt dinámicos.
 */

defined( 'ABSPATH' ) || exit;

// ── 1. Verificaciones de propiedad (meta tags en <head>) ─────────────────────
add_action( 'wp_head', 'mw_verification_tags', 1 );
function mw_verification_tags() {
    $gsc  = get_theme_mod( 'mw_gsc_verification',  '' );
    $bing = get_theme_mod( 'mw_bing_verification',  '' );
    $yand = get_theme_mod( 'mw_yandex_verification', '' );

    if ( $gsc )  echo '<meta name="google-site-verification" content="' . esc_attr( $gsc )  . '">' . "\n";
    if ( $bing ) echo '<meta name="msvalidate.01"             content="' . esc_attr( $bing ) . '">' . "\n";
    if ( $yand ) echo '<meta name="yandex-verification"       content="' . esc_attr( $yand ) . '">' . "\n";
}

// ── 2. Google Analytics 4 (GA4) ──────────────────────────────────────────────
add_action( 'wp_head', 'mw_ga4_script', 4 );
function mw_ga4_script() {
    $ga4_id       = sanitize_text_field( get_theme_mod( 'mw_ga4_id', '' ) );
    $consent_only = get_theme_mod( 'mw_ga4_consent_only', '1' );

    if ( ! $ga4_id ) return;

    if ( $consent_only ) {
        // Carga diferida: espera al evento de aceptación de cookies
        ?>
<!-- Google Analytics 4 — carga tras consentimiento -->
<script>
(function(){
    var GA4_ID = '<?php echo esc_js( $ga4_id ); ?>';
    function loadGA4() {
        if (window._mw_ga4_loaded) return;
        window._mw_ga4_loaded = true;
        var s = document.createElement('script');
        s.async = true;
        s.src = 'https://www.googletagmanager.com/gtag/js?id=' + GA4_ID;
        document.head.appendChild(s);
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        window.gtag = gtag;
        gtag('js', new Date());
        gtag('config', GA4_ID);
    }
    // Si ya aceptó en sesión anterior
    if (document.cookie.indexOf('mw_consent=all') !== -1 ||
        document.cookie.indexOf('mw_consent=partial') !== -1) {
        loadGA4();
    }
    // Si acepta ahora
    document.addEventListener('mw_cookies_accepted', loadGA4, { once: true });
})();
</script>
        <?php
    } else {
        // Carga inmediata (sin esperar consentimiento — úsalo solo si lo exige tu configuración legal)
        ?>
<!-- Google Analytics 4 — carga inmediata -->
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo esc_attr( $ga4_id ); ?>"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', '<?php echo esc_js( $ga4_id ); ?>');
</script>
        <?php
    }
}

// ── 3. Google Tag Manager ─────────────────────────────────────────────────────
add_action( 'wp_head', 'mw_gtm_head_script', 2 );
function mw_gtm_head_script() {
    $gtm_id = sanitize_text_field( get_theme_mod( 'mw_gtm_id', '' ) );
    if ( ! $gtm_id ) return;
    ?>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','<?php echo esc_js( $gtm_id ); ?>');</script>
<!-- End Google Tag Manager -->
    <?php
}

add_action( 'wp_body_open', 'mw_gtm_body_noscript', 1 );
function mw_gtm_body_noscript() {
    $gtm_id = sanitize_text_field( get_theme_mod( 'mw_gtm_id', '' ) );
    if ( ! $gtm_id ) return;
    ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=<?php echo esc_attr( $gtm_id ); ?>"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
    <?php
}

// ── 4. Facebook Pixel ────────────────────────────────────────────────────────
add_action( 'wp_head', 'mw_facebook_pixel_script', 5 );
function mw_facebook_pixel_script() {
    $pixel_id = sanitize_text_field( get_theme_mod( 'mw_fb_pixel_id', '' ) );
    if ( ! $pixel_id ) return;
    ?>
<!-- Facebook Pixel -->
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?php echo esc_js( $pixel_id ); ?>');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=<?php echo esc_attr( $pixel_id ); ?>&ev=PageView&noscript=1"/></noscript>
<!-- End Facebook Pixel -->
    <?php
}

// ── 5. ads.txt y app-ads.txt — servidos dinámicamente ────────────────────────
add_action( 'init', 'mw_register_ads_txt_rewrite' );
function mw_register_ads_txt_rewrite() {
    add_rewrite_rule( '^ads\.txt$',     'index.php?mw_serve_ads_txt=ads', 'top' );
    add_rewrite_rule( '^app-ads\.txt$', 'index.php?mw_serve_ads_txt=app', 'top' );
}

add_filter( 'query_vars', function( $vars ) {
    $vars[] = 'mw_serve_ads_txt';
    return $vars;
} );

add_action( 'template_redirect', 'mw_serve_ads_txt_file' );
function mw_serve_ads_txt_file() {
    $type = get_query_var( 'mw_serve_ads_txt' );
    if ( ! $type ) return;

    if ( $type === 'ads' ) {
        $content = mw_build_ads_txt();
    } else {
        $content = get_theme_mod( 'mw_app_ads_txt_content', '' );
    }

    nocache_headers();
    header( 'Content-Type: text/plain; charset=utf-8' );
    echo $content;
    exit;
}

/**
 * Construye el contenido de ads.txt:
 * - Auto-genera la línea de AdSense si hay Publisher ID
 * - Combina con el contenido manual adicional
 */
function mw_build_ads_txt() {
    $manual  = trim( get_theme_mod( 'mw_ads_txt_content', '' ) );
    $pub_id  = trim( get_theme_mod( 'mw_adsense_pub_id', '' ) );
    $auto_ok = get_theme_mod( 'mw_ads_txt_auto', '1' );

    $lines = [];

    // Línea oficial de AdSense si Publisher ID está configurado
    if ( $auto_ok && $pub_id && strpos( $pub_id, 'ca-pub-' ) === 0 ) {
        $lines[] = 'google.com, ' . $pub_id . ', DIRECT, f08c47fec0942fa0';
    }

    // Contenido manual adicional (otras redes, líneas extra)
    if ( $manual ) {
        foreach ( explode( "\n", $manual ) as $line ) {
            $line = trim( $line );
            if ( $line && ! in_array( $line, $lines, true ) ) {
                $lines[] = $line;
            }
        }
    }

    return implode( "\n", $lines );
}

// Refrescar rewrite rules cuando se activa/actualiza el tema
add_action( 'after_switch_theme', function() {
    mw_register_ads_txt_rewrite();
    flush_rewrite_rules();
} );
