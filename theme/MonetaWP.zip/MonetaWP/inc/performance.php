<?php
/**
 * Performance — Limpieza de wp_head, eliminación de jQuery, lazy load.
 */

defined( 'ABSPATH' ) || exit;

// ── Limpiar wp_head ───────────────────────────────────────────────────────────
add_action( 'init', 'mw_cleanup_head' );
function mw_cleanup_head() {
    remove_action( 'wp_head', 'wp_generator' );
    remove_action( 'wp_head', 'wlwmanifest_link' );
    remove_action( 'wp_head', 'rsd_link' );
    remove_action( 'wp_head', 'wp_shortlink_wp_head' );
    remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
    remove_action( 'wp_head', 'rest_output_link_wp_head' );
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' );

    // Desactivar oEmbed
    remove_action( 'wp_head', 'wp_oembed_add_host_js' );
    add_filter( 'embed_oembed_discover', '__return_false' );

    // Quitar versión de WP de URLs de assets
    add_filter( 'the_generator', '__return_empty_string' );
    add_filter( 'style_loader_src',  'mw_remove_ver_param', 999 );
    add_filter( 'script_loader_src', 'mw_remove_ver_param', 999 );
}

function mw_remove_ver_param( $src ) {
    if ( strpos( $src, 'ver=' ) ) {
        $src = remove_query_arg( 'ver', $src );
    }
    return $src;
}

// ── Eliminar jQuery en frontend (sin jQuery en el tema) ──────────────────────
add_action( 'wp_enqueue_scripts', 'mw_remove_jquery', 999 );
function mw_remove_jquery() {
    if ( ! is_admin() && ! is_user_logged_in() ) {
        wp_deregister_script( 'jquery' );
        wp_register_script( 'jquery', '', [], '', false );
    }
}

// ── Deshabilitar Gutenberg en posts estándar si se desea (comentado por defecto)
// add_filter( 'use_block_editor_for_post', '__return_false' );

// ── Lazy load en imágenes que no lo tengan ────────────────────────────────────
add_filter( 'the_content', 'mw_add_lazy_loading' );
add_filter( 'post_thumbnail_html', 'mw_add_lazy_loading' );
function mw_add_lazy_loading( $html ) {
    // Solo añadir si no tiene loading= ya
    if ( strpos( $html, ' loading=' ) === false ) {
        $html = str_replace( '<img ', '<img loading="lazy" ', $html );
    }
    return $html;
}

// ── Deshabilitar comentarios globalmente ──────────────────────────────────────
add_action( 'admin_init', function() {
    foreach ( get_post_types() as $post_type ) {
        if ( post_type_supports( $post_type, 'comments' ) ) {
            remove_post_type_support( $post_type, 'comments' );
            remove_post_type_support( $post_type, 'trackbacks' );
        }
    }
} );
add_filter( 'comments_open', '__return_false', 20, 2 );
add_filter( 'pings_open',    '__return_false', 20, 2 );

// ── Seguridad HTTP — cabeceras de seguridad ───────────────────────────────────
add_action( 'send_headers', 'mw_security_headers' );
function mw_security_headers() {
    if ( is_admin() ) return;

    // Forzar HTTPS por 1 año (HSTS) — solo se envía si la conexión ya es HTTPS
    if ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ) {
        header( 'Strict-Transport-Security: max-age=31536000; includeSubDomains; preload' );
    }

    // Protección contra clickjacking
    header( 'X-Frame-Options: SAMEORIGIN' );

    // Evitar MIME-type sniffing
    header( 'X-Content-Type-Options: nosniff' );

    // Política de referrer segura
    header( 'Referrer-Policy: strict-origin-when-cross-origin' );

    // Aislamiento de origen — allow-popups necesario para ventanas de AdSense/OAuth
    header( 'Cross-Origin-Opener-Policy: same-origin-allow-popups' );

    // Deshabilitar funciones de hardware no usadas
    header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
}

// ── Forzar HTTPS en URLs de adjuntos (imágenes subidas) ───────────────────────
// Evita contenido mixto (HTTP en página HTTPS) reportado por PageSpeed
add_filter( 'wp_get_attachment_url', 'mw_force_https_url' );
add_filter( 'wp_get_attachment_image_src', function( $image ) {
    if ( is_array( $image ) && ! empty( $image[0] ) ) {
        $image[0] = mw_force_https_url( $image[0] );
    }
    return $image;
} );
function mw_force_https_url( $url ) {
    if ( $url && strpos( $url, 'http://' ) === 0 ) {
        $url = set_url_scheme( $url, 'https' );
    }
    return $url;
}

// ── Limitar revisiones de posts ───────────────────────────────────────────────
if ( ! defined( 'WP_POST_REVISIONS' ) ) {
    define( 'WP_POST_REVISIONS', 3 );
}

// ── Optimizar queries de homepage ─────────────────────────────────────────────
add_action( 'pre_get_posts', 'mw_optimize_main_query' );
function mw_optimize_main_query( $query ) {
    if ( ! is_admin() && $query->is_main_query() && $query->is_home() ) {
        $query->set( 'posts_per_page', 6 );
    }
}
