<?php
/**
 * Meta Boxes para CPT convocatoria.
 * Campos: deadline, importe, organismo, url_boe, estado, featured.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'add_meta_boxes', 'mw_add_convocatoria_meta_boxes' );
function mw_add_convocatoria_meta_boxes() {
    add_meta_box(
        'mw_convocatoria_details',
        __( 'Detalles de la Convocatoria', 'monetawp' ),
        'mw_convocatoria_meta_box_cb',
        'convocatoria',
        'normal',
        'high'
    );
}

function mw_convocatoria_meta_box_cb( $post ) {
    wp_nonce_field( 'mw_convocatoria_meta', 'mw_convocatoria_nonce' );

    $deadline  = get_post_meta( $post->ID, '_convocatoria_deadline',  true );
    $amount    = get_post_meta( $post->ID, '_convocatoria_amount',    true );
    $organismo = get_post_meta( $post->ID, '_convocatoria_organismo', true );
    $url_boe   = get_post_meta( $post->ID, '_convocatoria_url_boe',   true );
    $estado    = get_post_meta( $post->ID, '_convocatoria_estado',    true ) ?: 'abierta';
    $featured  = get_post_meta( $post->ID, '_convocatoria_featured',  true );
    ?>
    <style>
    .ae-meta-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:8px 0}
    .ae-meta-field{display:flex;flex-direction:column;gap:4px}
    .ae-meta-field label{font-weight:600;font-size:13px;color:#1d2327}
    .ae-meta-field input,.ae-meta-field select,.ae-meta-field textarea{width:100%;padding:6px 8px;border:1px solid #8c8f94;border-radius:4px;font-size:13px}
    .ae-meta-full{grid-column:1/-1}
    .ae-featured-row{background:#fff8e5;border:1px solid #f5a623;border-radius:6px;padding:12px;margin-top:8px;display:flex;align-items:center;gap:8px}
    </style>
    <div class="ae-meta-grid">
        <div class="ae-meta-field">
            <label for="mw_deadline"><?php _e( 'Fecha límite solicitud', 'monetawp' ); ?></label>
            <input type="date" id="mw_deadline" name="mw_deadline" value="<?php echo esc_attr( $deadline ); ?>">
        </div>
        <div class="ae-meta-field">
            <label for="mw_estado"><?php _e( 'Estado', 'monetawp' ); ?></label>
            <select id="mw_estado" name="mw_estado">
                <option value="abierta"        <?php selected( $estado, 'abierta' ); ?>><?php _e( '🟢 Abierta',         'monetawp' ); ?></option>
                <option value="proxima"         <?php selected( $estado, 'proxima' ); ?>><?php _e( '🟡 Próximamente',    'monetawp' ); ?></option>
                <option value="cerrada"         <?php selected( $estado, 'cerrada' ); ?>><?php _e( '🔴 Cerrada',         'monetawp' ); ?></option>
            </select>
        </div>
        <div class="ae-meta-field">
            <label for="mw_amount"><?php _e( 'Importe / Cuantía (ej: Hasta 6.000€)', 'monetawp' ); ?></label>
            <input type="text" id="mw_amount" name="mw_amount" value="<?php echo esc_attr( $amount ); ?>" placeholder="Hasta 6.000€">
        </div>
        <div class="ae-meta-field">
            <label for="mw_organismo"><?php _e( 'Organismo convocante', 'monetawp' ); ?></label>
            <input type="text" id="mw_organismo" name="mw_organismo" value="<?php echo esc_attr( $organismo ); ?>" placeholder="Ministerio de Economía">
        </div>
        <div class="ae-meta-field ae-meta-full">
            <label for="mw_url_boe"><?php _e( 'URL oficial (BOE / organismo)', 'monetawp' ); ?></label>
            <input type="url" id="mw_url_boe" name="mw_url_boe" value="<?php echo esc_attr( $url_boe ); ?>" placeholder="https://www.boe.es/...">
        </div>
    </div>
    <div class="ae-featured-row">
        <input type="checkbox" id="mw_featured" name="mw_featured" value="1" <?php checked( $featured, '1' ); ?>>
        <label for="mw_featured"><strong><?php _e( '⭐ Destacar en Homepage', 'monetawp' ); ?></strong> — <?php _e( 'Aparece en la sección "Convocatorias Destacadas" de la portada.', 'monetawp' ); ?></label>
    </div>
    <?php
}

add_action( 'save_post_convocatoria', 'mw_save_convocatoria_meta' );
function mw_save_convocatoria_meta( $post_id ) {

    if ( ! isset( $_POST['mw_convocatoria_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['mw_convocatoria_nonce'], 'mw_convocatoria_meta' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $fields = [
        'mw_deadline'  => '_convocatoria_deadline',
        'mw_amount'    => '_convocatoria_amount',
        'mw_organismo' => '_convocatoria_organismo',
        'mw_estado'    => '_convocatoria_estado',
        'mw_url_boe'   => '_convocatoria_url_boe',
    ];

    foreach ( $fields as $input => $meta_key ) {
        if ( $meta_key === '_convocatoria_url_boe' ) {
            $value = isset( $_POST[ $input ] ) ? esc_url_raw( $_POST[ $input ] ) : '';
        } else {
            $value = isset( $_POST[ $input ] ) ? sanitize_text_field( $_POST[ $input ] ) : '';
        }
        update_post_meta( $post_id, $meta_key, $value );
    }

    // Checkbox featured
    $featured = isset( $_POST['mw_featured'] ) ? '1' : '0';
    update_post_meta( $post_id, '_convocatoria_featured', $featured );
}
