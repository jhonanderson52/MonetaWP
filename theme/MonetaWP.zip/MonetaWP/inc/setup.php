<?php
/**
 * Theme Setup — add_theme_support(), nav menus, image sizes, sitemaps, Customizer.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'after_setup_theme', 'mw_setup' );
function mw_setup() {

    load_theme_textdomain( 'monetawp', MW_DIR . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'custom-logo', [
        'height'      => 80,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ] );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'wp-block-styles' );
    add_theme_support( 'align-wide' );
    add_theme_support( 'editor-styles' );
    add_editor_style( 'assets/css/editor.css' );

    add_image_size( 'ae-card',   480, 320, true );
    add_image_size( 'ae-hero',  1200, 630, true );
    add_image_size( 'ae-thumb',  100, 100, true );

    register_nav_menus( [
        'primary' => __( 'Menú Principal', 'monetawp' ),
        'footer'  => __( 'Menú Footer',    'monetawp' ),
        'legal'   => __( 'Menú Legal',     'monetawp' ),
    ] );
}

// ── Customizer — v1.1 ────────────────────────────────────────────────────────
add_action( 'customize_register', 'mw_customize_register' );
function mw_customize_register( $wp_customize ) {

    $wp_customize->add_panel( 'mw_panel', [
        'title'    => __( 'MonetaWP', 'monetawp' ),
        'priority' => 30,
    ] );

    // ── SECCIÓN: Logo ─────────────────────────────────────────────────────────
    $wp_customize->add_section( 'mw_logo', [
        'title'    => __( 'Logo y Cabecera', 'monetawp' ),
        'panel'    => 'mw_panel',
        'priority' => 10,
    ] );


    // ── Tamaño logo Desktop ───────────────────────────────────────────────────
    $wp_customize->add_setting( 'mw_logo_height', [
        'default'           => 48,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_logo_height', [
        'label'       => __( 'Altura del logo — Desktop (px)', 'monetawp' ),
        'description' => __( 'Visible en pantallas ≥ 1024 px. Entre 30 y 100 px.', 'monetawp' ),
        'section'     => 'mw_logo',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 30, 'max' => 100, 'step' => 2 ],
    ] );

    $wp_customize->add_setting( 'mw_logo_max_width', [
        'default'           => 220,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_logo_max_width', [
        'label'       => __( 'Ancho máximo del logo — Desktop (px)', 'monetawp' ),
        'description' => __( 'Entre 80 y 400 px.', 'monetawp' ),
        'section'     => 'mw_logo',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 80, 'max' => 400, 'step' => 10 ],
    ] );

    // ── Tamaño logo Móvil ─────────────────────────────────────────────────────
    $wp_customize->add_setting( 'mw_logo_height_mobile', [
        'default'           => 36,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_logo_height_mobile', [
        'label'       => __( 'Altura del logo — Móvil (px)', 'monetawp' ),
        'description' => __( 'Visible en pantallas < 1024 px. Entre 24 y 80 px.', 'monetawp' ),
        'section'     => 'mw_logo',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 24, 'max' => 80, 'step' => 2 ],
    ] );

    $wp_customize->add_setting( 'mw_logo_max_width_mobile', [
        'default'           => 160,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_logo_max_width_mobile', [
        'label'       => __( 'Ancho máximo del logo — Móvil (px)', 'monetawp' ),
        'description' => __( 'Entre 60 y 280 px.', 'monetawp' ),
        'section'     => 'mw_logo',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 60, 'max' => 280, 'step' => 10 ],
    ] );

    // Color de fondo de la cabecera
    $wp_customize->add_setting( 'mw_header_bg', [
        'default'           => '#002244',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_header_bg', [
        'label'       => __( 'Color de fondo de la cabecera', 'monetawp' ),
        'description' => __( 'Color principal del header (por defecto azul marino).', 'monetawp' ),
        'section'     => 'mw_logo',
    ] ) );

    // Color del menú desktop (texto de los items)
    $wp_customize->add_setting( 'mw_header_menu_color', [
        'default'           => '#FFFFFF',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_header_menu_color', [
        'label'   => __( 'Color texto del menú', 'monetawp' ),
        'section' => 'mw_logo',
    ] ) );

    // Botón de búsqueda: texto o icono
    $wp_customize->add_setting( 'mw_search_btn_style', [
        'default'           => 'text',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'refresh',
    ] );
    $wp_customize->add_control( 'mw_search_btn_style', [
        'label'       => __( 'Botón de búsqueda', 'monetawp' ),
        'description' => __( 'Elige si mostrar texto o un icono en el botón de búsqueda.', 'monetawp' ),
        'section'     => 'mw_logo',
        'type'        => 'select',
        'choices'     => [
            'text'        => __( '🔤 Texto: "Buscar"',          'monetawp' ),
            'icon-lupa'   => __( '🔍 Icono: Lupa',              'monetawp' ),
            'icon-arrow'  => __( '➡ Icono: Flecha derecha',    'monetawp' ),
            'icon-bolt'   => __( '⚡ Icono: Rayo (rápido)',     'monetawp' ),
            'icon-check'  => __( '✓ Icono: Aceptar/Check',     'monetawp' ),
            'icon-enter'  => __( '↩ Icono: Enter/Intro',       'monetawp' ),
        ],
    ] );

    // Color del botón de búsqueda
    $wp_customize->add_setting( 'mw_search_btn_color', [
        'default'           => '#F97316',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_search_btn_color', [
        'label'   => __( 'Color del botón de búsqueda', 'monetawp' ),
        'section' => 'mw_logo',
    ] ) );

    // ── Alineación del menú desktop ───────────────────────────────────────────
    // El orden siempre es: Logo | Menú | Buscar
    // Esta opción controla la alineación interna de los ítems dentro del espacio central
    $wp_customize->add_setting( 'mw_nav_layout', [
        'default'           => 'center',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_nav_layout', [
        'label'       => __( 'Alineación del menú (desktop)', 'monetawp' ),
        'description' => __( 'Logo y Buscar son fijos. El menú ocupa el espacio central.', 'monetawp' ),
        'section'     => 'mw_logo',
        'type'        => 'select',
        'choices'     => [
            'left'   => __( '← Izquierda  | Logo | Menú · · · · · | Buscar |', 'monetawp' ),
            'center' => __( '↔ Centro      | Logo | · · Menú · · · | Buscar |', 'monetawp' ),
            'right'  => __( '→ Derecha     | Logo | · · · · · Menú | Buscar |', 'monetawp' ),
        ],
    ] );

    // ── Tamaño de fuente del menú desktop ─────────────────────────────────────
    $wp_customize->add_setting( 'mw_nav_font_size', [
        'default'           => 14,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_nav_font_size', [
        'label'       => __( 'Tamaño de fuente del menú (px)', 'monetawp' ),
        'description' => __( 'Entre 11 y 18 px. Por defecto 14 px.', 'monetawp' ),
        'section'     => 'mw_logo',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 11, 'max' => 18, 'step' => 1 ],
    ] );

    // ── SECCIÓN: Redes Sociales ───────────────────────────────────────────────
    $wp_customize->add_section( 'mw_social', [
        'title'    => __( 'Redes Sociales', 'monetawp' ),
        'panel'    => 'mw_panel',
        'priority' => 20,
    ] );

    $fields = [
        'mw_whatsapp_number'  => [ 'label' => 'Número WhatsApp (ej: 34600000000)', 'default' => '' ],
        'mw_whatsapp_message' => [ 'label' => 'Mensaje WhatsApp predeterminado',    'default' => 'Hola, quiero recibir información sobre ayudas' ],
        'mw_manychat_id'      => [ 'label' => 'ManyChat Page ID',                  'default' => '' ],
        'mw_facebook_page'    => [ 'label' => 'URL Página Facebook',               'default' => '' ],
        'mw_instagram_url'    => [ 'label' => 'URL Instagram',                     'default' => '' ],
    ];
    foreach ( $fields as $id => $args ) {
        $wp_customize->add_setting( $id, [ 'default' => $args['default'], 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $id, [ 'label' => $args['label'], 'section' => 'mw_social', 'type' => 'text' ] );
    }

    // ── SECCIÓN: Hero Homepage ────────────────────────────────────────────────
    $wp_customize->add_section( 'mw_hero', [
        'title'    => __( 'Hero Homepage', 'monetawp' ),
        'panel'    => 'mw_panel',
        'priority' => 30,
    ] );

    $hero_fields = [
        'mw_hero_title'    => [ 'label' => 'Título Hero',    'default' => 'Becas, Subvenciones y Ayudas en España 2026' ],
        'mw_hero_subtitle' => [ 'label' => 'Subtítulo Hero', 'default' => 'Encuentra toda la información actualizada sobre ayudas y convocatorias abiertas.' ],
        'mw_hero_cta1_text'=> [ 'label' => 'Botón 1 — Texto',   'default' => 'Ver Becas' ],
        'mw_hero_cta1_url' => [ 'label' => 'Botón 1 — URL',     'default' => '/tipo-ayuda/becas/' ],
        'mw_hero_cta2_text'=> [ 'label' => 'Botón 2 — Texto',   'default' => 'Ayudas Autónomos' ],
        'mw_hero_cta2_url' => [ 'label' => 'Botón 2 — URL',     'default' => '/beneficiario/autonomos/' ],
        'mw_hero_cta3_text'=> [ 'label' => 'Botón 3 — Texto',   'default' => 'Convocatorias Abiertas' ],
        'mw_hero_cta3_url' => [ 'label' => 'Botón 3 — URL',     'default' => '/tipo-ayuda/convocatorias/' ],
    ];
    foreach ( $hero_fields as $id => $args ) {
        $wp_customize->add_setting( $id, [ 'default' => $args['default'], 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $id, [ 'label' => $args['label'], 'section' => 'mw_hero', 'type' => 'text' ] );
    }

    // Iconos de los 3 botones del Hero
    $hero_icons = [
        'mw_hero_cta1_icon' => [ 'label' => 'Botón 1 — Icono', 'default' => '🎓' ],
        'mw_hero_cta2_icon' => [ 'label' => 'Botón 2 — Icono', 'default' => '💼' ],
        'mw_hero_cta3_icon' => [ 'label' => 'Botón 3 — Icono', 'default' => '📖' ],
    ];
    $icon_choices = [
        ''   => '— Sin icono —',
        '🎓' => '🎓 Educación / Becas',
        '💼' => '💼 Trabajo / Autónomos',
        '🏠' => '🏠 Vivienda',
        '👨‍👩‍👧' => '👨‍👩‍👧 Familias',
        '📋' => '📋 Documentos / Guía',
        '📖' => '📖 Leer / Guía',
        '🌍' => '🌍 Global / Internacional',
        '🤱' => '🤱 Madres',
        '💰' => '💰 Dinero / Subsidios',
        '🏥' => '🏥 Salud',
        '🚀' => '🚀 Emprendimiento',
        '✅' => '✅ Verificado',
        '🔍' => '🔍 Buscar',
        '📣' => '📣 Convocatorias',
        '⚡' => '⚡ Urgente / Activo',
        '🎯' => '🎯 Objetivo',
        '💡' => '💡 Información',
    ];
    foreach ( $hero_icons as $id => $args ) {
        $wp_customize->add_setting( $id, [
            'default'           => $args['default'],
            'sanitize_callback' => 'sanitize_text_field',
            'transport'         => 'refresh',
        ] );
        $wp_customize->add_control( $id, [
            'label'   => __( $args['label'], 'monetawp' ),
            'section' => 'mw_hero',
            'type'    => 'select',
            'choices' => $icon_choices,
        ] );
    }

    // Colores de los 3 botones del Hero
    $hero_btn_colors = [
        'mw_hero_cta1_bg'     => [ 'label' => 'Botón 1 — Color de fondo',  'default' => '#F97316' ],
        'mw_hero_cta1_text_c' => [ 'label' => 'Botón 1 — Color de texto',  'default' => '#FFFFFF' ],
        'mw_hero_cta2_bg'     => [ 'label' => 'Botón 2 — Color de fondo',  'default' => '#0891B2' ],
        'mw_hero_cta2_text_c' => [ 'label' => 'Botón 2 — Color de texto',  'default' => '#FFFFFF' ],
        'mw_hero_cta3_bg'     => [ 'label' => 'Botón 3 — Color de fondo',  'default' => 'transparent' ],
        'mw_hero_cta3_text_c' => [ 'label' => 'Botón 3 — Color de texto',  'default' => '#FFFFFF' ],
    ];
    foreach ( $hero_btn_colors as $id => $args ) {
        // transparent no es un hex color válido, usamos sanitize_text_field para el bg
        $sanitize = ( strpos( $id, '_bg' ) !== false ) ? 'sanitize_text_field' : 'sanitize_hex_color';
        $wp_customize->add_setting( $id, [
            'default'           => $args['default'],
            'sanitize_callback' => $sanitize,
            'transport'         => 'postMessage',
        ] );
        // El botón 3 bg es transparent por defecto, no usar color picker (puede confundir)
        if ( $id === 'mw_hero_cta3_bg' ) {
            $wp_customize->add_control( $id, [
                'label'       => $args['label'],
                'description' => __( 'Usa "transparent" para fondo transparente o un color hex (#RRGGBB).', 'monetawp' ),
                'section'     => 'mw_hero',
                'type'        => 'text',
            ] );
        } else {
            $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $id, [
                'label'   => $args['label'],
                'section' => 'mw_hero',
            ] ) );
        }
    }

    $wp_customize->add_setting( 'mw_hero_bg', [ 'default' => '', 'sanitize_callback' => 'esc_url_raw' ] );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'mw_hero_bg', [
        'label'   => __( 'Imagen de Fondo Hero', 'monetawp' ),
        'section' => 'mw_hero',
    ] ) );

    // Oscuridad del overlay de la imagen hero
    $wp_customize->add_setting( 'mw_hero_overlay', [
        'default'           => 60,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_hero_overlay', [
        'label'       => __( 'Oscuridad de la imagen (%)', 'monetawp' ),
        'description' => __( '0% = imagen sin filtro · 100% = negro total. Recomendado: 50-70% para que el texto sea legible.', 'monetawp' ),
        'section'     => 'mw_hero',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 0, 'max' => 100, 'step' => 5 ],
    ] );

    // ── SECCIÓN: Grid de Países ───────────────────────────────────────────────
    $wp_customize->add_section( 'mw_countries', [
        'title'       => __( 'Grid de Países', 'monetawp' ),
        'panel'       => 'mw_panel',
        'priority'    => 31,
        'description' => __( 'Sección "Encuentra Ayudas en tu País" de la homepage.', 'monetawp' ),
    ] );

    $wp_customize->add_setting( 'mw_countries_title', [
        'default'           => 'Encuentra Ayudas en tu País',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_countries_title', [
        'label'   => __( 'Título de la sección', 'monetawp' ),
        'section' => 'mw_countries',
        'type'    => 'text',
    ] );

    $wp_customize->add_setting( 'mw_countries_cta', [
        'default'           => 'Explorar ayudas',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_countries_cta', [
        'label'   => __( 'Texto del enlace en cada tarjeta', 'monetawp' ),
        'section' => 'mw_countries',
        'type'    => 'text',
    ] );

    $wp_customize->add_setting( 'mw_countries_card_height', [
        'default'           => 280,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_countries_card_height', [
        'label'       => __( 'Altura de las tarjetas (px)', 'monetawp' ),
        'description' => __( 'Entre 180 y 420 px.', 'monetawp' ),
        'section'     => 'mw_countries',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 180, 'max' => 420, 'step' => 10 ],
    ] );

    $wp_customize->add_setting( 'mw_countries_card_bg', [
        'default'           => '#002244',
        'sanitize_callback' => 'sanitize_hex_color',
    ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_countries_card_bg', [
        'label'       => __( 'Color de fondo de tarjeta (sin imagen)', 'monetawp' ),
        'section'     => 'mw_countries',
    ] ) );

    // Distribución del grid
    $wp_customize->add_setting( 'mw_countries_layout', [
        'default'           => '2-3',
        'sanitize_callback' => 'sanitize_text_field',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_countries_layout', [
        'label'   => __( 'Distribución del grid', 'monetawp' ),
        'section' => 'mw_countries',
        'type'    => 'select',
        'choices' => [
            '2-3'  => __( '2 arriba + 3 abajo (Mockup)', 'monetawp' ),
            '2-2'  => __( '2 × 2 (cuadrícula)', 'monetawp' ),
            '3-3'  => __( '3 columnas', 'monetawp' ),
            '1-2'  => __( '1 grande + 2 pequeñas', 'monetawp' ),
        ],
    ] );

    // Oscuridad del overlay sobre la imagen
    $wp_customize->add_setting( 'mw_countries_overlay', [
        'default'           => 40,
        'sanitize_callback' => 'absint',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( 'mw_countries_overlay', [
        'label'       => __( 'Oscuridad de la imagen (%)', 'monetawp' ),
        'description' => __( '0 = imagen original · 100 = completamente oscura.', 'monetawp' ),
        'section'     => 'mw_countries',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 0, 'max' => 100, 'step' => 5 ],
    ] );

    // Color del texto dentro de las tarjetas
    $wp_customize->add_setting( 'mw_countries_text_color', [
        'default'           => '#FFFFFF',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_countries_text_color', [
        'label'   => __( 'Color del texto de las tarjetas', 'monetawp' ),
        'section' => 'mw_countries',
    ] ) );

    // Color del enlace CTA dentro de las tarjetas
    $wp_customize->add_setting( 'mw_countries_link_color', [
        'default'           => '#67E8F9',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_countries_link_color', [
        'label'   => __( 'Color del enlace "Explorar ayudas"', 'monetawp' ),
        'section' => 'mw_countries',
    ] ) );

    // Controles por tarjeta — imagen y enlace, uno por cada post del CPT 'pais' (dinámico)
    $mw_pais_posts = get_posts( [
        'post_type'      => 'pais',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'orderby'        => 'meta_value_num',
        'meta_key'       => '_pais_orden',
        'order'          => 'ASC',
    ] );
    foreach ( $mw_pais_posts as $mw_pais ) {
        $mw_code  = strtolower( trim( get_post_meta( $mw_pais->ID, '_pais_codigo', true ) ) );
        $mw_name  = $mw_pais->post_title;
        if ( ! $mw_code ) continue;

        // Imagen de fondo
        $wp_customize->add_setting( 'mw_country_img_' . $mw_code, [
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ] );
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'mw_country_img_' . $mw_code, [
            'label'   => $mw_name . ' — ' . __( 'Imagen de fondo', 'monetawp' ),
            'section' => 'mw_countries',
        ] ) );

        // Enlace de la tarjeta
        $wp_customize->add_setting( 'mw_country_url_' . $mw_code, [
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ] );
        $wp_customize->add_control( 'mw_country_url_' . $mw_code, [
            'label'       => $mw_name . ' — ' . __( 'Enlace de la tarjeta', 'monetawp' ),
            'description' => __( 'URL al hacer clic en la tarjeta. Vacío = usa el campo "URL del blog" del post.', 'monetawp' ),
            'section'     => 'mw_countries',
            'type'        => 'url',
        ] );
    }
    unset( $mw_pais_posts, $mw_pais, $mw_code, $mw_name );

    // Botón "Ver todas"
    $wp_customize->add_setting( 'mw_countries_cta_show', [
        'default'           => '1',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_countries_cta_show', [
        'label'   => __( 'Mostrar botón "Ver todas"', 'monetawp' ),
        'section' => 'mw_countries',
        'type'    => 'checkbox',
    ] );

    $wp_customize->add_setting( 'mw_countries_cta_text', [
        'default'           => 'Ver todos los países →',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_countries_cta_text', [
        'label'   => __( 'Texto del botón "Ver todas"', 'monetawp' ),
        'section' => 'mw_countries',
        'type'    => 'text',
    ] );

    $wp_customize->add_setting( 'mw_countries_cta_url', [
        'default'           => '/paises/',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_countries_cta_url', [
        'label'   => __( 'URL del botón "Ver todas"', 'monetawp' ),
        'section' => 'mw_countries',
        'type'    => 'text',
    ] );

    $wp_customize->add_setting( 'mw_countries_cta_color', [
        'default'           => '#002244',
        'sanitize_callback' => 'sanitize_hex_color',
    ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_countries_cta_color', [
        'label'   => __( 'Color del botón "Ver todas"', 'monetawp' ),
        'section' => 'mw_countries',
    ] ) );

    // ── SECCIÓN: Cuadros de Categorías ───────────────────────────────────────
    $wp_customize->add_section( 'mw_segments', [
        'title'       => __( 'Cuadros de Categorías', 'monetawp' ),
        'panel'       => 'mw_panel',
        'priority'    => 32,
        'description' => __( 'Los 4 cuadros de imagen con enlace a categorías de la homepage.', 'monetawp' ),
    ] );

    // Título de la sección
    $wp_customize->add_setting( 'mw_segments_title', [ 'default' => 'Encuentra Ayudas para Ti', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_segments_title', [
        'label'   => __( 'Título de la sección', 'monetawp' ),
        'section' => 'mw_segments',
        'type'    => 'text',
    ] );

    // Número de columnas (2 = cuadros grandes, 4 = fila horizontal)
    $wp_customize->add_setting( 'mw_segments_cols', [ 'default' => '2', 'sanitize_callback' => 'absint', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( 'mw_segments_cols', [
        'label'   => __( 'Columnas (disposición)', 'monetawp' ),
        'section' => 'mw_segments',
        'type'    => 'select',
        'choices' => [
            '1' => __( '1 — Apilados verticales', 'monetawp' ),
            '2' => __( '2 — Cuadrícula 2×2 (default)', 'monetawp' ),
            '4' => __( '4 — Fila horizontal', 'monetawp' ),
        ],
    ] );

    // Altura de las tarjetas en px
    $wp_customize->add_setting( 'mw_segments_height', [ 'default' => 280, 'sanitize_callback' => 'absint', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( 'mw_segments_height', [
        'label'       => __( 'Altura de los cuadros (px)', 'monetawp' ),
        'description' => __( 'Recomendado: 200–400 px. A más columnas, usa menos altura.', 'monetawp' ),
        'section'     => 'mw_segments',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 120, 'max' => 500, 'step' => 10 ],
    ] );

    // Color inicio del degradado de la etiqueta (izquierda)
    $wp_customize->add_setting( 'mw_segments_label_bg', [ 'default' => '#1E3A5F', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_segments_label_bg', [
        'label'       => __( 'Etiqueta — Color izquierdo del degradado', 'monetawp' ),
        'section'     => 'mw_segments',
    ] ) );

    // Color fin del degradado de la etiqueta (derecha)
    $wp_customize->add_setting( 'mw_segments_label_bg2', [ 'default' => '#0891B2', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_segments_label_bg2', [
        'label'       => __( 'Etiqueta — Color derecho del degradado', 'monetawp' ),
        'section'     => 'mw_segments',
    ] ) );

    // Opacidad del overlay oscuro sobre la imagen (0 = sin oscurecer, 100 = negro total)
    $wp_customize->add_setting( 'mw_segments_overlay', [ 'default' => 30, 'sanitize_callback' => 'absint', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( 'mw_segments_overlay', [
        'label'       => __( 'Oscuridad de la imagen (%)', 'monetawp' ),
        'description' => __( '0 = imagen original · 100 = completamente oscura.', 'monetawp' ),
        'section'     => 'mw_segments',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 0, 'max' => 100, 'step' => 5 ],
    ] );

    // Términos disponibles para asociar (category + taxonomías del tema)
    $mw_term_choices = [ '' => __( '— Sin asociar (solo URL manual) —', 'monetawp' ) ];
    $mw_tax_list = [ 'category', 'post_tag', 'tipo_ayuda', 'comunidad_autonoma', 'beneficiario' ];
    foreach ( $mw_tax_list as $_tax ) {
        $_terms = get_terms( [ 'taxonomy' => $_tax, 'hide_empty' => false ] );
        if ( is_wp_error( $_terms ) || empty( $_terms ) ) continue;
        $_tax_obj = get_taxonomy( $_tax );
        $_tax_label = $_tax_obj ? $_tax_obj->label : $_tax;
        foreach ( $_terms as $_t ) {
            $mw_term_choices[ $_tax . '|' . $_t->term_id ] = '[' . $_tax_label . '] ' . $_t->name;
        }
    }

    // Iconos disponibles (mismo set que tarjetas destacadas)
    $mw_seg_icons = [
        '🎓' => '🎓 Formación / Becas',   '💼' => '💼 Empleo / Autónomos',
        '🏢' => '🏢 Empresas / PYMES',     '🚀' => '🚀 Emprendedores',
        '🏠' => '🏠 Vivienda',              '👨‍👩‍👧' => '👨‍👩‍👧 Familias',
        '🏥' => '🏥 Salud',                 '♿' => '♿ Discapacidad',
        '📚' => '📚 Educación',             '⚡' => '⚡ Energía',
        '🌱' => '🌱 Medio Ambiente',        '🌍' => '🌍 Internacional',
        '🏗️' => '🏗️ Obras',               '🌾' => '🌾 Agricultura',
        '🏭' => '🏭 Industria',             '🔬' => '🔬 Investigación',
        '🎨' => '🎨 Cultura',               '🤝' => '🤝 Cooperación',
        '⭐' => '⭐ Destacado',              '💰' => '💰 Subvenciones',
    ];
    $mw_seg_default_icons = [ 1 => '🎓', 2 => '💼', 3 => '🏢', 4 => '🚀' ];

    for ( $n = 1; $n <= 4; $n++ ) {
        $sp     = 'mw_seg_' . $n;
        $slabel = sprintf( __( 'Cuadro %d', 'monetawp' ), $n );

        // Imagen
        $wp_customize->add_setting( $sp . '_image', [ 'default' => '', 'sanitize_callback' => 'esc_url_raw' ] );
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $sp . '_image', [
            'label'   => $slabel . ' — ' . __( 'Imagen de fondo', 'monetawp' ),
            'section' => 'mw_segments',
        ] ) );

        // Categoría/término asociado
        $wp_customize->add_setting( $sp . '_term', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $sp . '_term', [
            'label'       => $slabel . ' — ' . __( 'Categoría asociada', 'monetawp' ),
            'description' => __( 'El enlace y el nombre se toman de este término si no hay URL/label manual.', 'monetawp' ),
            'section'     => 'mw_segments',
            'type'        => 'select',
            'choices'     => $mw_term_choices,
        ] );

        // Etiqueta personalizada
        $wp_customize->add_setting( $sp . '_label', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $sp . '_label', [
            'label'       => $slabel . ' — ' . __( 'Etiqueta (vacío = nombre de la categoría)', 'monetawp' ),
            'section'     => 'mw_segments',
            'type'        => 'text',
        ] );

        // URL personalizada
        $wp_customize->add_setting( $sp . '_url', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $sp . '_url', [
            'label'       => $slabel . ' — ' . __( 'URL manual (vacío = URL de la categoría)', 'monetawp' ),
            'section'     => 'mw_segments',
            'type'        => 'text',
        ] );

        // Icono
        $wp_customize->add_setting( $sp . '_icon', [ 'default' => $mw_seg_default_icons[ $n ], 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $sp . '_icon', [
            'label'   => $slabel . ' — ' . __( 'Icono', 'monetawp' ),
            'section' => 'mw_segments',
            'type'    => 'select',
            'choices' => $mw_seg_icons,
        ] );
    }

    // ── SECCIÓN: Sección de Pills / Etiquetas ─────────────────────────────────
    $wp_customize->add_section( 'mw_pills', [
        'title'       => __( 'Sección de Etiquetas (Pills)', 'monetawp' ),
        'panel'       => 'mw_panel',
        'priority'    => 33,
        'description' => __( 'Sección de pills/chips con enlaces. Actívala y configura cada ítem con emoji, nombre y URL.', 'monetawp' ),
    ] );

    // Activar / desactivar
    $wp_customize->add_setting( 'mw_pills_enable', [ 'default' => '1', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'mw_pills_enable', [
        'label'   => __( 'Mostrar esta sección en la homepage', 'monetawp' ),
        'section' => 'mw_pills',
        'type'    => 'checkbox',
    ] );

    // Título
    $wp_customize->add_setting( 'mw_pills_title', [ 'default' => 'Subvenciones por Comunidad Autónoma', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_pills_title', [
        'label'   => __( 'Título de la sección', 'monetawp' ),
        'section' => 'mw_pills',
        'type'    => 'text',
    ] );

    // Color fondo de la pill
    $wp_customize->add_setting( 'mw_pills_bg', [ 'default' => '#FFFFFF', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_pills_bg', [
        'label'   => __( 'Color de fondo de las etiquetas', 'monetawp' ),
        'section' => 'mw_pills',
    ] ) );

    // Color borde de la pill
    $wp_customize->add_setting( 'mw_pills_border', [ 'default' => '#E5E7EB', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_pills_border', [
        'label'   => __( 'Color de borde de las etiquetas', 'monetawp' ),
        'section' => 'mw_pills',
    ] ) );

    // Color texto
    $wp_customize->add_setting( 'mw_pills_color', [ 'default' => '#1A2B4A', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_pills_color', [
        'label'   => __( 'Color de texto de las etiquetas', 'monetawp' ),
        'section' => 'mw_pills',
    ] ) );

    // Color hover
    $wp_customize->add_setting( 'mw_pills_hover', [ 'default' => '#CC0000', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_pills_hover', [
        'label'   => __( 'Color hover (fondo al pasar el cursor)', 'monetawp' ),
        'section' => 'mw_pills',
    ] ) );

    // Ítems: una línea por ítem con formato "emoji | Nombre | /url/"
    $mw_pills_default = "🌿 | Andalucía | /comunidad-autonoma/andalucia/\n"
        . "⚓ | Aragón | /comunidad-autonoma/aragon/\n"
        . "🏔️ | Asturias | /comunidad-autonoma/asturias/\n"
        . "🌋 | Canarias | /comunidad-autonoma/canarias/\n"
        . "⛵ | Cantabria | /comunidad-autonoma/cantabria/\n"
        . "🏰 | Castilla y León | /comunidad-autonoma/castilla-y-leon/\n"
        . "🏰 | Castilla-La Mancha | /comunidad-autonoma/castilla-la-mancha/\n"
        . "🎨 | Cataluña | /comunidad-autonoma/cataluna/\n"
        . "🕌 | Ceuta | /comunidad-autonoma/ceuta/\n"
        . "🏙️ | Madrid | /comunidad-autonoma/comunidad-de-madrid/\n"
        . "🍊 | Com. Valenciana | /comunidad-autonoma/comunitat-valenciana/\n"
        . "🌾 | Extremadura | /comunidad-autonoma/extremadura/\n"
        . "🌊 | Galicia | /comunidad-autonoma/galicia/\n"
        . "🏝️ | Islas Baleares | /comunidad-autonoma/islas-baleares/\n"
        . "🍷 | La Rioja | /comunidad-autonoma/la-rioja/\n"
        . "🕌 | Melilla | /comunidad-autonoma/melilla/\n"
        . "🇪🇸 | Nacional | /comunidad-autonoma/nacional/\n"
        . "⛰️ | Navarra | /comunidad-autonoma/navarra/\n"
        . "🔱 | País Vasco | /comunidad-autonoma/pais-vasco/\n"
        . "☀️ | Murcia | /comunidad-autonoma/region-de-murcia/";

    $wp_customize->add_setting( 'mw_pills_items', [
        'default'           => $mw_pills_default,
        'sanitize_callback' => 'sanitize_textarea_field',
    ] );
    $wp_customize->add_control( 'mw_pills_items', [
        'label'       => __( 'Ítems (una línea por ítem)', 'monetawp' ),
        'description' => __( 'Formato: emoji | Nombre | /url/  — Deja la URL vacía para que use la taxonomía automáticamente.', 'monetawp' ),
        'section'     => 'mw_pills',
        'type'        => 'textarea',
    ] );

    // ── SECCIÓN: Tarjetas Destacadas ──────────────────────────────────────────
    $wp_customize->add_section( 'mw_featured', [
        'title'       => __( 'Tarjetas Destacadas', 'monetawp' ),
        'panel'       => 'mw_panel',
        'priority'    => 35,
        'description' => __( 'Configura las 4 tarjetas de la sección principal de la homepage.', 'monetawp' ),
    ] );

    // Mostrar / ocultar sección
    $wp_customize->add_setting( 'mw_featured_visible', [
        'default'           => true,
        'sanitize_callback' => function( $v ) { return (bool) $v; },
    ] );
    $wp_customize->add_control( 'mw_featured_visible', [
        'label'   => __( 'Mostrar sección en la homepage', 'monetawp' ),
        'section' => 'mw_featured',
        'type'    => 'checkbox',
    ] );

    // Título de la sección
    $wp_customize->add_setting( 'mw_featured_title', [
        'default'           => 'Convocatorias Destacadas',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_featured_title', [
        'label'   => __( 'Título de la sección', 'monetawp' ),
        'section' => 'mw_featured',
        'type'    => 'text',
    ] );

    // Texto e URL del botón CTA inferior
    $wp_customize->add_setting( 'mw_featured_cta_text', [ 'default' => 'Ver todas las convocatorias →', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_featured_cta_text', [
        'label'   => __( 'Texto del botón "Ver todas"', 'monetawp' ),
        'section' => 'mw_featured',
        'type'    => 'text',
    ] );
    $wp_customize->add_setting( 'mw_featured_cta_url', [ 'default' => '/convocatorias/', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_featured_cta_url', [
        'label'   => __( 'URL del botón "Ver todas"', 'monetawp' ),
        'section' => 'mw_featured',
        'type'    => 'text',
    ] );

    // Íconos disponibles
    $mw_icon_choices = [
        '📋' => '📋 Convocatoria',
        '🎓' => '🎓 Becas / Formación',
        '💰' => '💰 Subvenciones',
        '🏦' => '🏦 Préstamos',
        '🏠' => '🏠 Vivienda',
        '👨‍👩‍👧' => '👨‍👩‍👧 Familias',
        '💼' => '💼 Empleo / Autónomos',
        '🌱' => '🌱 Emprendedores',
        '🎨' => '🎨 Cultura',
        '🏥' => '🏥 Salud',
        '♿' => '♿ Discapacidad',
        '📚' => '📚 Educación',
        '⚡' => '⚡ Energía',
        '🚀' => '🚀 Innovación / I+D',
        '🌍' => '🌍 Internacional',
        '🏗️' => '🏗️ Obras / Reforma',
        '🌾' => '🌾 Agricultura',
        '🏭' => '🏭 Industria / PYME',
        '🔬' => '🔬 Investigación',
        '🤝' => '🤝 Cooperación',
        '⭐' => '⭐ Destacado',
        '🆕' => '🆕 Nuevo',
    ];

    // Opciones de posts (convocatorias + posts estándar)
    $mw_post_choices = [ '' => __( '— Entrada automática (más recientes) —', 'monetawp' ) ];
    $conv_posts = get_posts( [ 'post_type' => 'convocatoria', 'numberposts' => 100, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'publish' ] );
    foreach ( $conv_posts as $_p ) {
        $mw_post_choices[ $_p->ID ] = '📋 ' . wp_trim_words( $_p->post_title, 7, '…' );
    }
    $std_posts = get_posts( [ 'post_type' => 'post', 'numberposts' => 100, 'orderby' => 'title', 'order' => 'ASC', 'post_status' => 'publish' ] );
    foreach ( $std_posts as $_p ) {
        $mw_post_choices[ $_p->ID ] = '📄 ' . wp_trim_words( $_p->post_title, 7, '…' );
    }

    // Colores de fondo del icono
    $mw_color_choices = [
        'red'   => __( '🔴 Rojo',   'monetawp' ),
        'blue'  => __( '🔵 Azul',   'monetawp' ),
        'green' => __( '🟢 Verde',  'monetawp' ),
        'gold'  => __( '🟡 Dorado', 'monetawp' ),
    ];
    $mw_default_icons   = [ '📋', '🎓', '💰', '🏦' ];
    $mw_default_colors  = [ 'red', 'blue', 'green', 'gold' ];

    // Controles para las 4 tarjetas
    for ( $n = 1; $n <= 4; $n++ ) {
        $prefix = 'mw_card_' . $n;
        $label  = sprintf( __( 'Tarjeta %d', 'monetawp' ), $n );

        // Post asociado
        $wp_customize->add_setting( $prefix . '_post_id', [ 'default' => '', 'sanitize_callback' => 'absint' ] );
        $wp_customize->add_control( $prefix . '_post_id', [
            'label'       => $label . ' — ' . __( 'Entrada asociada', 'monetawp' ),
            'description' => __( 'Selecciona el artículo o convocatoria que mostrará esta tarjeta.', 'monetawp' ),
            'section'     => 'mw_featured',
            'type'        => 'select',
            'choices'     => $mw_post_choices,
        ] );

        // Icono
        $wp_customize->add_setting( $prefix . '_icon', [ 'default' => $mw_default_icons[ $n - 1 ], 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $prefix . '_icon', [
            'label'   => $label . ' — ' . __( 'Icono', 'monetawp' ),
            'section' => 'mw_featured',
            'type'    => 'select',
            'choices' => $mw_icon_choices,
        ] );

        // Color del fondo del icono
        $wp_customize->add_setting( $prefix . '_color', [ 'default' => $mw_default_colors[ $n - 1 ], 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $prefix . '_color', [
            'label'   => $label . ' — ' . __( 'Color del icono', 'monetawp' ),
            'section' => 'mw_featured',
            'type'    => 'select',
            'choices' => $mw_color_choices,
        ] );

        // Título personalizado (opcional)
        $wp_customize->add_setting( $prefix . '_custom_title', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
        $wp_customize->add_control( $prefix . '_custom_title', [
            'label'       => $label . ' — ' . __( 'Título personalizado', 'monetawp' ),
            'description' => __( 'Deja vacío para usar el título de la entrada seleccionada.', 'monetawp' ),
            'section'     => 'mw_featured',
            'type'        => 'text',
        ] );

        // Texto / extracto personalizado (opcional)
        $wp_customize->add_setting( $prefix . '_custom_text', [ 'default' => '', 'sanitize_callback' => 'sanitize_textarea_field' ] );
        $wp_customize->add_control( $prefix . '_custom_text', [
            'label'       => $label . ' — ' . __( 'Extracto personalizado', 'monetawp' ),
            'description' => __( 'Deja vacío para usar el extracto de la entrada seleccionada.', 'monetawp' ),
            'section'     => 'mw_featured',
            'type'        => 'textarea',
        ] );
    }

    // ── SECCIÓN: Últimos Artículos ────────────────────────────────────────────
    $wp_customize->add_section( 'mw_latest', [
        'title'    => __( 'Últimos Artículos', 'monetawp' ),
        'panel'    => 'mw_panel',
        'priority' => 36,
    ] );

    // Título de la sección
    $wp_customize->add_setting( 'mw_latest_title', [ 'default' => 'Últimos Artículos', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_latest_title', [
        'label'   => __( 'Título de la sección', 'monetawp' ),
        'section' => 'mw_latest',
        'type'    => 'text',
    ] );

    // Cantidad de artículos
    $wp_customize->add_setting( 'mw_latest_count', [ 'default' => 6, 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'mw_latest_count', [
        'label'       => __( 'Número de artículos', 'monetawp' ),
        'description' => __( 'Total de artículos a mostrar (1–12).', 'monetawp' ),
        'section'     => 'mw_latest',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 1, 'max' => 12, 'step' => 1 ],
    ] );

    // Layout
    $wp_customize->add_setting( 'mw_latest_layout', [ 'default' => 'grid', 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( 'mw_latest_layout', [
        'label'   => __( 'Disposición', 'monetawp' ),
        'section' => 'mw_latest',
        'type'    => 'select',
        'choices' => [
            'grid' => __( '⊞ Cuadrícula (grid)', 'monetawp' ),
            'list' => __( '☰ Lista (imagen + texto en fila)', 'monetawp' ),
        ],
    ] );

    // Columnas (solo para grid)
    $wp_customize->add_setting( 'mw_latest_cols', [ 'default' => 3, 'sanitize_callback' => 'absint', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( 'mw_latest_cols', [
        'label'       => __( 'Columnas (solo en cuadrícula)', 'monetawp' ),
        'description' => __( '1 = lista apilada · 2 · 3 · 4 columnas por fila.', 'monetawp' ),
        'section'     => 'mw_latest',
        'type'        => 'select',
        'choices'     => [
            '1' => __( '1 columna', 'monetawp' ),
            '2' => __( '2 columnas', 'monetawp' ),
            '3' => __( '3 columnas (default)', 'monetawp' ),
            '4' => __( '4 columnas', 'monetawp' ),
        ],
    ] );

    // Mostrar fecha
    $wp_customize->add_setting( 'mw_latest_show_date', [ 'default' => '1', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'mw_latest_show_date', [
        'label'   => __( 'Mostrar fecha de publicación', 'monetawp' ),
        'section' => 'mw_latest',
        'type'    => 'checkbox',
    ] );

    // Mostrar autor
    $wp_customize->add_setting( 'mw_latest_show_author', [ 'default' => '0', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'mw_latest_show_author', [
        'label'   => __( 'Mostrar nombre del autor', 'monetawp' ),
        'section' => 'mw_latest',
        'type'    => 'checkbox',
    ] );

    // Botón "Ver todos"
    $wp_customize->add_setting( 'mw_latest_cta_show', [ 'default' => '1', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'mw_latest_cta_show', [
        'label'   => __( 'Mostrar botón "Ver todos"', 'monetawp' ),
        'section' => 'mw_latest',
        'type'    => 'checkbox',
    ] );

    $wp_customize->add_setting( 'mw_latest_cta_text', [ 'default' => 'Ver todos los artículos →', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_latest_cta_text', [
        'label'   => __( 'Texto del botón', 'monetawp' ),
        'section' => 'mw_latest',
        'type'    => 'text',
    ] );

    $wp_customize->add_setting( 'mw_latest_cta_url', [ 'default' => '/blog/', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_latest_cta_url', [
        'label'   => __( 'URL del botón', 'monetawp' ),
        'section' => 'mw_latest',
        'type'    => 'text',
    ] );

    $wp_customize->add_setting( 'mw_latest_cta_color', [ 'default' => '#1A2B4A', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_latest_cta_color', [
        'label'   => __( 'Color del botón', 'monetawp' ),
        'section' => 'mw_latest',
    ] ) );

    // ── SECCIÓN: Google & Verificaciones ─────────────────────────────────────
    $wp_customize->add_section( 'mw_google', [
        'title'       => __( 'Google & Verificaciones', 'monetawp' ),
        'panel'       => 'mw_panel',
        'priority'    => 35,
        'description' => __( 'Conecta tu sitio con Google Search Console, Analytics, Tag Manager y otras plataformas.', 'monetawp' ),
    ] );

    // ─ Google Search Console ────────────────────────────────────────────────
    $wp_customize->add_setting( 'mw_gsc_verification', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_gsc_verification', [
        'label'       => __( 'Google Search Console — Código de verificación', 'monetawp' ),
        'description' => __( 'Pega solo el valor del atributo content del meta tag. Ej: abc123XYZ. Lo encontrarás en Search Console → Configuración → Verificación de propiedad → Meta tag.', 'monetawp' ),
        'section'     => 'mw_google',
        'type'        => 'text',
    ] );

    // ─ Google Analytics 4 ───────────────────────────────────────────────────
    $wp_customize->add_setting( 'mw_ga4_id', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_ga4_id', [
        'label'       => __( 'Google Analytics 4 — Measurement ID', 'monetawp' ),
        'description' => __( 'Formato: G-XXXXXXXXXX. Lo encontrarás en GA4 → Admin → Flujo de datos.', 'monetawp' ),
        'section'     => 'mw_google',
        'type'        => 'text',
    ] );

    $wp_customize->add_setting( 'mw_ga4_consent_only', [ 'default' => '1', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_ga4_consent_only', [
        'label'       => __( 'GA4: cargar solo tras aceptar cookies (recomendado RGPD)', 'monetawp' ),
        'description' => __( 'Espera al evento de aceptación del banner de cookies antes de cargar Analytics.', 'monetawp' ),
        'section'     => 'mw_google',
        'type'        => 'checkbox',
    ] );

    // ─ Google Tag Manager ────────────────────────────────────────────────────
    $wp_customize->add_setting( 'mw_gtm_id', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_gtm_id', [
        'label'       => __( 'Google Tag Manager — Container ID', 'monetawp' ),
        'description' => __( 'Formato: GTM-XXXXXXX. Si usas GTM no necesitas poner el ID de GA4 por separado, gestiona todo desde GTM.', 'monetawp' ),
        'section'     => 'mw_google',
        'type'        => 'text',
    ] );

    // ─ Bing Webmaster Tools ──────────────────────────────────────────────────
    $wp_customize->add_setting( 'mw_bing_verification', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_bing_verification', [
        'label'       => __( 'Bing Webmaster Tools — Código de verificación', 'monetawp' ),
        'description' => __( 'Pega solo el valor del content del meta tag msvalidate.01.', 'monetawp' ),
        'section'     => 'mw_google',
        'type'        => 'text',
    ] );

    // ─ Yandex Webmaster ──────────────────────────────────────────────────────
    $wp_customize->add_setting( 'mw_yandex_verification', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_yandex_verification', [
        'label'       => __( 'Yandex Webmaster — Código de verificación', 'monetawp' ),
        'description' => __( 'Opcional. Pega solo el valor del content del meta tag yandex-verification.', 'monetawp' ),
        'section'     => 'mw_google',
        'type'        => 'text',
    ] );

    // ─ Facebook Pixel ────────────────────────────────────────────────────────
    $wp_customize->add_setting( 'mw_fb_pixel_id', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_fb_pixel_id', [
        'label'       => __( 'Facebook / Meta Pixel ID', 'monetawp' ),
        'description' => __( 'Solo el número de ID. Ej: 1234567890. Lo encontrarás en Meta Business Suite → Píxeles.', 'monetawp' ),
        'section'     => 'mw_google',
        'type'        => 'text',
    ] );

    // ── SECCIÓN: ads.txt / app-ads.txt ────────────────────────────────────────
    $wp_customize->add_section( 'mw_ads_txt', [
        'title'       => __( 'ads.txt / app-ads.txt', 'monetawp' ),
        'panel'       => 'mw_panel',
        'priority'    => 42,
        'description' => __( 'El archivo ads.txt previene el fraude publicitario y es obligatorio para maximizar ingresos con AdSense. Se sirve automáticamente en yourdomain.com/ads.txt', 'monetawp' ),
    ] );

    $wp_customize->add_setting( 'mw_ads_txt_auto', [ 'default' => '1', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_ads_txt_auto', [
        'label'       => __( 'Auto-generar línea de AdSense desde el Publisher ID', 'monetawp' ),
        'description' => __( 'Requiere que el Publisher ID (ca-pub-XXXXXXXX) esté configurado en la sección AdSense.', 'monetawp' ),
        'section'     => 'mw_ads_txt',
        'type'        => 'checkbox',
    ] );

    $wp_customize->add_setting( 'mw_ads_txt_content', [ 'default' => '', 'sanitize_callback' => 'sanitize_textarea_field' ] );
    $wp_customize->add_control( 'mw_ads_txt_content', [
        'label'       => __( 'Contenido adicional de ads.txt', 'monetawp' ),
        'description' => __( "Una entrada por línea. Formato estándar IAB:\ndomain.com, ID_publicador, DIRECT o RESELLER, ID_certificación\n\nLa línea de Google AdSense se añade automáticamente si está activada arriba.", 'monetawp' ),
        'section'     => 'mw_ads_txt',
        'type'        => 'textarea',
    ] );

    $wp_customize->add_setting( 'mw_app_ads_txt_content', [ 'default' => '', 'sanitize_callback' => 'sanitize_textarea_field' ] );
    $wp_customize->add_control( 'mw_app_ads_txt_content', [
        'label'       => __( 'Contenido de app-ads.txt (opcional)', 'monetawp' ),
        'description' => __( 'Para monetización de apps móviles. Se sirve en yourdomain.com/app-ads.txt', 'monetawp' ),
        'section'     => 'mw_ads_txt',
        'type'        => 'textarea',
    ] );

    // ── SECCIÓN: AdSense ──────────────────────────────────────────────────────
    $wp_customize->add_section( 'mw_adsense', [
        'title'    => __( 'AdSense', 'monetawp' ),
        'panel'    => 'mw_panel',
        'priority' => 40,
    ] );

    $wp_customize->add_setting( 'mw_adsense_pub_id', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_adsense_pub_id', [
        'label'       => __( 'AdSense Publisher ID (ca-pub-XXXXXXXXXX)', 'monetawp' ),
        'section'     => 'mw_adsense',
        'type'        => 'text',
        'description' => __( 'Tu ID de publicador de Google AdSense', 'monetawp' ),
    ] );
    $wp_customize->add_setting( 'mw_adsense_auto_ads', [ 'default' => '0', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'mw_adsense_auto_ads', [
        'label'   => __( 'Activar Auto Ads de AdSense', 'monetawp' ),
        'section' => 'mw_adsense',
        'type'    => 'checkbox',
    ] );

    // ── SECCIÓN: Cookies ──────────────────────────────────────────────────────
    $wp_customize->add_section( 'mw_cookies', [
        'title'       => __( 'Aviso de Cookies', 'monetawp' ),
        'panel'       => 'mw_panel',
        'priority'    => 50,
        'description' => __( 'Configura el banner de consentimiento de cookies (requerido por RGPD/LOPD).', 'monetawp' ),
    ] );

    // Activar/desactivar banner
    $wp_customize->add_setting( 'mw_cookie_enable', [ 'default' => '1', 'sanitize_callback' => 'absint' ] );
    $wp_customize->add_control( 'mw_cookie_enable', [
        'label'   => __( 'Mostrar aviso de cookies', 'monetawp' ),
        'section' => 'mw_cookies',
        'type'    => 'checkbox',
    ] );

    // Texto del banner
    $wp_customize->add_setting( 'mw_cookie_text', [
        'default'           => 'Utilizamos cookies propias y de terceros para mejorar tu experiencia y mostrarte publicidad personalizada. Al continuar navegando aceptas nuestra',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_cookie_text', [
        'label'   => __( 'Texto del aviso', 'monetawp' ),
        'section' => 'mw_cookies',
        'type'    => 'textarea',
    ] );

    // Texto botón aceptar
    $wp_customize->add_setting( 'mw_cookie_accept_text', [ 'default' => 'Aceptar todas', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_cookie_accept_text', [
        'label'   => __( 'Texto botón Aceptar', 'monetawp' ),
        'section' => 'mw_cookies',
        'type'    => 'text',
    ] );

    // Texto botón rechazar / solo necesarias
    $wp_customize->add_setting( 'mw_cookie_reject_text', [ 'default' => 'Solo necesarias', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_cookie_reject_text', [
        'label'   => __( 'Texto botón Rechazar (dejar vacío para ocultarlo)', 'monetawp' ),
        'section' => 'mw_cookies',
        'type'    => 'text',
    ] );

    // Texto del enlace a política de cookies
    $wp_customize->add_setting( 'mw_cookie_policy_text', [ 'default' => 'Política de Cookies', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_cookie_policy_text', [
        'label'   => __( 'Texto enlace política de cookies', 'monetawp' ),
        'section' => 'mw_cookies',
        'type'    => 'text',
    ] );

    // URL política de cookies
    $wp_customize->add_setting( 'mw_cookie_policy_url', [ 'default' => '/politica-de-cookies/', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_cookie_policy_url', [
        'label'   => __( 'URL Política de Cookies', 'monetawp' ),
        'section' => 'mw_cookies',
        'type'    => 'text',
    ] );

    // Posición del banner
    $wp_customize->add_setting( 'mw_cookie_position', [ 'default' => 'bottom', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_cookie_position', [
        'label'   => __( 'Posición del banner', 'monetawp' ),
        'section' => 'mw_cookies',
        'type'    => 'select',
        'choices' => [
            'bottom' => __( 'Abajo (recomendado)', 'monetawp' ),
            'top'    => __( 'Arriba',              'monetawp' ),
        ],
    ] );

    // Color de fondo del banner
    $wp_customize->add_setting( 'mw_cookie_bg_color', [ 'default' => '#1A2B4A', 'sanitize_callback' => 'sanitize_hex_color' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_cookie_bg_color', [
        'label'   => __( 'Color de fondo del banner', 'monetawp' ),
        'section' => 'mw_cookies',
    ] ) );

    // Color botón aceptar
    $wp_customize->add_setting( 'mw_cookie_btn_color', [ 'default' => '#CC0000', 'sanitize_callback' => 'sanitize_hex_color' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_cookie_btn_color', [
        'label'   => __( 'Color botón Aceptar', 'monetawp' ),
        'section' => 'mw_cookies',
    ] ) );

    // ── SECCIÓN: Footer — Columnas de Categorías ─────────────────────────────
    $wp_customize->add_section( 'mw_footer_cols', [
        'title'    => __( 'Footer — Columnas de Categorías', 'monetawp' ),
        'panel'    => 'mw_panel',
        'priority' => 90,
    ] );

    // Orden de las entradas (global para las 3 columnas)
    $wp_customize->add_setting( 'mw_footer_order', [
        'default'           => 'date',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_footer_order', [
        'label'   => __( 'Orden de las entradas', 'monetawp' ),
        'section' => 'mw_footer_cols',
        'type'    => 'select',
        'choices' => [
            'date' => __( 'Más recientes primero', 'monetawp' ),
            'rand' => __( 'Aleatorio',             'monetawp' ),
        ],
    ] );

    // Construir opciones de términos para los selects de columna
    $footer_term_choices = [ '' => __( '— Sin columna —', 'monetawp' ) ];
    $footer_tax_labels   = [
        'tipo_ayuda'        => __( 'Tipo Ayuda', 'monetawp' ),
        'beneficiario'      => __( 'Beneficiario', 'monetawp' ),
        'comunidad_autonoma'=> __( 'Comunidad Autónoma', 'monetawp' ),
        'category'          => __( 'Categoría', 'monetawp' ),
    ];
    foreach ( $footer_tax_labels as $_tax_key => $_tax_label ) {
        $_terms = get_terms( [ 'taxonomy' => $_tax_key, 'hide_empty' => false ] );
        if ( ! is_wp_error( $_terms ) && ! empty( $_terms ) ) {
            foreach ( $_terms as $_t ) {
                $footer_term_choices[ $_tax_key . '|' . $_t->term_id ] = '[' . $_tax_label . '] ' . $_t->name;
            }
        }
    }

    // Configuración de cada columna (1, 2, 3)
    for ( $n = 1; $n <= 3; $n++ ) {
        $sp = 'mw_footer_col' . $n;

        // Término asociado a la columna
        $wp_customize->add_setting( $sp . '_term', [
            'default'           => '',
            'sanitize_callback' => 'sanitize_text_field',
        ] );
        $wp_customize->add_control( $sp . '_term', [
            'label'   => sprintf( __( 'Columna %d — Categoría', 'monetawp' ), $n ),
            'section' => 'mw_footer_cols',
            'type'    => 'select',
            'choices' => $footer_term_choices,
        ] );

        // Número de entradas en esta columna
        $wp_customize->add_setting( $sp . '_count', [
            'default'           => '5',
            'sanitize_callback' => 'sanitize_text_field',
        ] );
        $wp_customize->add_control( $sp . '_count', [
            'label'   => sprintf( __( 'Columna %d — Nº de entradas', 'monetawp' ), $n ),
            'section' => 'mw_footer_cols',
            'type'    => 'select',
            'choices' => [ '3' => '3', '4' => '4', '5' => '5' ],
        ] );
    }

    // ── SECCIÓN: Página Blog ──────────────────────────────────────────────────
    $wp_customize->add_section( 'mw_blog', [
        'title'       => __( 'Página Blog', 'monetawp' ),
        'panel'       => 'mw_panel',
        'priority'    => 84,
        'description' => __( 'Configura la página de entradas (Blog) — el índice principal de artículos.', 'monetawp' ),
    ] );

    // Título de la página blog
    $wp_customize->add_setting( 'mw_blog_title', [ 'default' => 'Últimas Ayudas', 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( 'mw_blog_title', [
        'label'   => __( 'Título de la página', 'monetawp' ),
        'section' => 'mw_blog',
        'type'    => 'text',
    ] );

    // Subtítulo / descripción
    $wp_customize->add_setting( 'mw_blog_subtitle', [ 'default' => '', 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( 'mw_blog_subtitle', [
        'label'       => __( 'Subtítulo / descripción', 'monetawp' ),
        'description' => __( 'Texto bajo el título. Déjalo vacío para ocultarlo.', 'monetawp' ),
        'section'     => 'mw_blog',
        'type'        => 'textarea',
    ] );

    // Mostrar cabecera
    $wp_customize->add_setting( 'mw_blog_show_header', [ 'default' => '1', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_blog_show_header', [
        'label'   => __( 'Mostrar cabecera con título', 'monetawp' ),
        'section' => 'mw_blog',
        'type'    => 'checkbox',
    ] );

    // Color de fondo de la cabecera
    $wp_customize->add_setting( 'mw_blog_header_bg', [ 'default' => '#F0F9FF', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_blog_header_bg', [
        'label'   => __( 'Color de fondo de la cabecera', 'monetawp' ),
        'section' => 'mw_blog',
    ] ) );

    // Color del texto de la cabecera
    $wp_customize->add_setting( 'mw_blog_header_tc', [ 'default' => '#002244', 'sanitize_callback' => 'sanitize_hex_color', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'mw_blog_header_tc', [
        'label'   => __( 'Color del texto de la cabecera', 'monetawp' ),
        'section' => 'mw_blog',
    ] ) );

    // Columnas del grid
    $wp_customize->add_setting( 'mw_blog_cols', [ 'default' => '2', 'sanitize_callback' => 'absint', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( 'mw_blog_cols', [
        'label'   => __( 'Columnas (desktop)', 'monetawp' ),
        'section' => 'mw_blog',
        'type'    => 'select',
        'choices' => [ '1' => '1 columna', '2' => '2 columnas', '3' => '3 columnas', '4' => '4 columnas' ],
    ] );

    // Altura de la imagen de la tarjeta
    $wp_customize->add_setting( 'mw_blog_card_img_height', [ 'default' => 200, 'sanitize_callback' => 'absint', 'transport' => 'postMessage' ] );
    $wp_customize->add_control( 'mw_blog_card_img_height', [
        'label'       => __( 'Altura de la imagen de las tarjetas (px)', 'monetawp' ),
        'description' => __( 'Entre 120 y 400 px.', 'monetawp' ),
        'section'     => 'mw_blog',
        'type'        => 'range',
        'input_attrs' => [ 'min' => 120, 'max' => 400, 'step' => 10 ],
    ] );

    // Mostrar fecha
    $wp_customize->add_setting( 'mw_blog_show_date', [ 'default' => '1', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_blog_show_date', [
        'label'   => __( 'Mostrar fecha de publicación', 'monetawp' ),
        'section' => 'mw_blog',
        'type'    => 'checkbox',
    ] );

    // Mostrar autor
    $wp_customize->add_setting( 'mw_blog_show_author', [ 'default' => '0', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_blog_show_author', [
        'label'   => __( 'Mostrar autor', 'monetawp' ),
        'section' => 'mw_blog',
        'type'    => 'checkbox',
    ] );

    // Mostrar extracto
    $wp_customize->add_setting( 'mw_blog_show_excerpt', [ 'default' => '1', 'sanitize_callback' => 'sanitize_text_field' ] );
    $wp_customize->add_control( 'mw_blog_show_excerpt', [
        'label'   => __( 'Mostrar extracto del artículo', 'monetawp' ),
        'section' => 'mw_blog',
        'type'    => 'checkbox',
    ] );

    // ── SECCIÓN: Páginas de Archivo ───────────────────────────────────────────
    $wp_customize->add_section( 'mw_archive', [
        'title'    => __( 'Páginas de Archivo', 'monetawp' ),
        'panel'    => 'mw_panel',
        'priority' => 85,
    ] );

    $wp_customize->add_setting( 'mw_archive_cols', [
        'default'           => '3',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_archive_cols', [
        'label'   => __( 'Columnas (desktop)', 'monetawp' ),
        'section' => 'mw_archive',
        'type'    => 'select',
        'choices' => [ '2' => '2 columnas', '3' => '3 columnas', '4' => '4 columnas' ],
    ] );

    $wp_customize->add_setting( 'mw_archive_posts_per_page', [
        'default'           => '9',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_archive_posts_per_page', [
        'label'   => __( 'Entradas por página', 'monetawp' ),
        'section' => 'mw_archive',
        'type'    => 'select',
        'choices' => [ '6' => '6', '9' => '9', '12' => '12', '18' => '18' ],
    ] );

    $wp_customize->add_setting( 'mw_archive_show_date', [
        'default'           => '1',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_archive_show_date', [
        'label'   => __( 'Mostrar fecha de publicación', 'monetawp' ),
        'section' => 'mw_archive',
        'type'    => 'checkbox',
    ] );

    $wp_customize->add_setting( 'mw_archive_show_author', [
        'default'           => '0',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_archive_show_author', [
        'label'   => __( 'Mostrar autor', 'monetawp' ),
        'section' => 'mw_archive',
        'type'    => 'checkbox',
    ] );

    $wp_customize->add_setting( 'mw_archive_show_excerpt', [
        'default'           => '1',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_archive_show_excerpt', [
        'label'   => __( 'Mostrar extracto', 'monetawp' ),
        'section' => 'mw_archive',
        'type'    => 'checkbox',
    ] );

    $wp_customize->add_setting( 'mw_archive_show_filters', [
        'default'           => '1',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_archive_show_filters', [
        'label'       => __( 'Mostrar pills de filtro', 'monetawp' ),
        'description' => __( 'Muestra términos relacionados para filtrar.', 'monetawp' ),
        'section'     => 'mw_archive',
        'type'        => 'checkbox',
    ] );

    $wp_customize->add_setting( 'mw_archive_show_related', [
        'default'           => '1',
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    $wp_customize->add_control( 'mw_archive_show_related', [
        'label'       => __( 'Mostrar categorías relacionadas al final', 'monetawp' ),
        'description' => __( 'Enlaza a otras taxonomías — bueno para SEO.', 'monetawp' ),
        'section'     => 'mw_archive',
        'type'        => 'checkbox',
    ] );

    // ── Live preview JS para tamaño de logo (los 4 settings) ─────────────────
    foreach ( [ 'mw_logo_height', 'mw_logo_max_width', 'mw_logo_height_mobile', 'mw_logo_max_width_mobile' ] as $_s ) {
        $wp_customize->get_setting( $_s )->transport = 'postMessage';
    }
}

// ── Detectar si un color hex es claro (luminancia > 0.55) ────────────────────
function mw_is_light_color( $hex ) {
    $hex = ltrim( $hex, '#' );
    if ( strlen( $hex ) < 6 ) return false;
    $r = hexdec( substr( $hex, 0, 2 ) );
    $g = hexdec( substr( $hex, 2, 2 ) );
    $b = hexdec( substr( $hex, 4, 2 ) );
    return ( 0.299 * $r + 0.587 * $g + 0.114 * $b ) / 255 > 0.55;
}

// ── CSS inline para tamaño de logo + colores de cabecera (server-side) ────────
add_action( 'wp_head', 'mw_logo_size_css', 20 );
function mw_logo_size_css() {
    $height        = absint( get_theme_mod( 'mw_logo_height',           48  ) );
    $max_width     = absint( get_theme_mod( 'mw_logo_max_width',        220 ) );
    $height_mob    = absint( get_theme_mod( 'mw_logo_height_mobile',    36  ) );
    $max_width_mob = absint( get_theme_mod( 'mw_logo_max_width_mobile', 160 ) );
    $header_bg     = get_theme_mod( 'mw_header_bg',          '#002244' );
    $menu_color    = get_theme_mod( 'mw_header_menu_color',  '#FFFFFF' );
    $btn_color     = get_theme_mod( 'mw_search_btn_color',   '#F97316' );
    $nav_layout    = get_theme_mod( 'mw_nav_layout',         'right'   );
    $nav_font_size = absint( get_theme_mod( 'mw_nav_font_size', 14 ) );

    $logo_sel = '.nav-brand .custom-logo,.nav-brand .custom-logo-link img';
    $css = '';

    // Tamaño móvil (base, sin media query)
    $css .= $logo_sel . '{height:' . $height_mob . 'px !important;max-width:' . $max_width_mob . 'px !important;}';
    // Tamaño desktop (≥ 1024 px)
    $css .= '@media(min-width:1024px){' . $logo_sel . '{height:' . $height . 'px !important;max-width:' . $max_width . 'px !important;}}';

    $is_light = mw_is_light_color( $header_bg );

    if ( strtolower( $header_bg ) !== '#002244' ) {
        $css .= '.site-header{background:' . sanitize_hex_color( $header_bg ) . ';';
        if ( $is_light ) {
            $css .= '--hdr-fg:#002244;--hdr-fg-muted:rgba(0,0,0,.45);--hdr-input-bg:rgba(0,0,0,.06);--hdr-input-border:rgba(0,0,0,.20);';
            $css .= 'box-shadow:0 2px 8px rgba(0,0,0,.10);}';
        } else {
            $css .= '}';
        }
    }

    if ( strtolower( $menu_color ) !== '#ffffff' ) {
        $css .= '.site-header{--hdr-fg:' . sanitize_hex_color( $menu_color ) . ';}';
    }

    // Color botón búsqueda — siempre aplicar para reflejar paleta actual
    $safe_btn = sanitize_hex_color( $btn_color ) ?: '#F97316';
    $css .= '.search-form button,.search-form input[type="submit"]{background:' . $safe_btn . ' !important;border-color:' . $safe_btn . ' !important;}';

    // ── Alineación interna del menú desktop ───────────────────────────────────
    // Logo=izq siempre | Menú=centro flex:1 | Buscar=der siempre
    $align_map = [
        'left'   => 'flex-start',
        'center' => 'center',
        'right'  => 'flex-end',
    ];
    $justify = isset( $align_map[ $nav_layout ] ) ? $align_map[ $nav_layout ] : 'center';
    $css .= '@media(min-width:1024px){.nav-menu-desktop>ul{justify-content:' . $justify . ';}}';

    if ( $nav_font_size !== 14 ) {
        $css .= '.nav-menu-desktop a{font-size:' . $nav_font_size . 'px !important;}';
    }

    if ( $css ) {
        echo '<style id="ae-logo-size">' . $css . '</style>' . "\n";
    }
}

// ── Live preview (postMessage) ────────────────────────────────────────────────
add_action( 'customize_preview_init', 'mw_customize_preview_js' );
function mw_customize_preview_js() {
    wp_add_inline_script( 'customize-preview',
        "(function($){
            function aeUpdateStyle(id, css){
                var el = $('#' + id);
                el.length ? el.text(css) : $('head').append('<style id=\"' + id + '\">' + css + '</style>');
            }
            var _logoSel = '.nav-brand .custom-logo,.nav-brand .custom-logo-link img';
            function aeLogoSizeCSS(){
                var h   = wp.customize('mw_logo_height').get();
                var mw  = wp.customize('mw_logo_max_width').get();
                var hm  = wp.customize('mw_logo_height_mobile').get();
                var mwm = wp.customize('mw_logo_max_width_mobile').get();
                var css = _logoSel+'{height:'+hm+'px !important;max-width:'+mwm+'px !important;}';
                css    += '@media(min-width:1024px){'+_logoSel+'{height:'+h+'px !important;max-width:'+mw+'px !important;}}';
                aeUpdateStyle('ae-logo-size', css);
            }
            wp.customize('mw_logo_height',           function(v){ v.bind(aeLogoSizeCSS); });
            wp.customize('mw_logo_max_width',        function(v){ v.bind(aeLogoSizeCSS); });
            wp.customize('mw_logo_height_mobile',    function(v){ v.bind(aeLogoSizeCSS); });
            wp.customize('mw_logo_max_width_mobile', function(v){ v.bind(aeLogoSizeCSS); });

            // Luminancia para detectar fondo claro en JS
            function aeIsLight(hex){
                hex = hex.replace('#','');
                var r=parseInt(hex.substr(0,2),16), g=parseInt(hex.substr(2,2),16), b=parseInt(hex.substr(4,2),16);
                return (0.299*r + 0.587*g + 0.114*b)/255 > 0.55;
            }
            wp.customize('mw_header_bg', function(v){
                v.bind(function(val){
                    var light = aeIsLight(val);
                    var vars = light
                        ? '--hdr-fg:#1A2B4A;--hdr-fg-muted:rgba(0,0,0,.45);--hdr-input-bg:rgba(0,0,0,.06);--hdr-input-border:rgba(0,0,0,.20);'
                        : '--hdr-fg:#ffffff;--hdr-fg-muted:rgba(255,255,255,.55);--hdr-input-bg:rgba(255,255,255,.12);--hdr-input-border:rgba(255,255,255,.30);';
                    aeUpdateStyle('ae-header-bg', '.site-header{background:' + val + ';' + vars + '}');
                });
            });
            wp.customize('mw_header_menu_color', function(v){
                v.bind(function(val){
                    aeUpdateStyle('ae-menu-color', '.site-header{--hdr-fg:' + val + ';}');
                });
            });
            wp.customize('mw_search_btn_color', function(v){
                v.bind(function(val){
                    aeUpdateStyle('ae-btn-color', '.search-form button,.search-form input[type=\"submit\"]{background:' + val + ' !important;border-color:' + val + ' !important;}');
                });
            });
            // Alineación menú — live preview
            wp.customize('mw_nav_layout', function(v){
                v.bind(function(val){
                    var map = {left:'flex-start', center:'center', right:'flex-end'};
                    var justify = map[val] || 'center';
                    aeUpdateStyle('ae-nav-layout',
                        '@media(min-width:1024px){.nav-menu-desktop>ul{justify-content:' + justify + ';}}');
                });
            });
            // Tamaño fuente menú — live preview
            wp.customize('mw_nav_font_size', function(v){
                v.bind(function(val){
                    aeUpdateStyle('ae-nav-font', '.nav-menu-desktop a{font-size:' + val + 'px !important;}');
                });
            });
            // Últimos artículos — live preview
            var mwLatestSection = document.querySelector('.latest-section');
            wp.customize('mw_latest_cols', function(v){
                v.bind(function(val){
                    if(mwLatestSection) mwLatestSection.style.setProperty('--latest-cols', val);
                });
            });
            wp.customize('mw_latest_layout', function(v){
                v.bind(function(val){
                    if(!mwLatestSection) return;
                    if(val === 'list'){
                        mwLatestSection.classList.add('latest--list');
                    } else {
                        mwLatestSection.classList.remove('latest--list');
                    }
                });
            });
            wp.customize('mw_latest_cta_color', function(v){
                v.bind(function(val){
                    var btn = document.querySelector('.latest-section .btn');
                    if(btn){ btn.style.background = val; btn.style.borderColor = val; }
                });
            });

            // Pills — live preview de colores
            wp.customize('mw_pills_bg', function(v){
                v.bind(function(val){ aeUpdateStyle('mw-pills-colors',
                    '.comunidad-pill{background:' + val + ';border-color:' + wp.customize('mw_pills_border').get() + ';color:' + wp.customize('mw_pills_color').get() + '}'
                    + '.comunidad-pill:hover{background:' + wp.customize('mw_pills_hover').get() + ';border-color:' + wp.customize('mw_pills_hover').get() + ';color:#fff}'); });
            });
            wp.customize('mw_pills_border', function(v){ v.bind(function(){ document.querySelectorAll('.comunidad-pill').forEach(function(el){ el.style.borderColor = wp.customize('mw_pills_border').get(); }); }); });
            wp.customize('mw_pills_color',  function(v){ v.bind(function(val){ document.querySelectorAll('.comunidad-pill').forEach(function(el){ el.style.color = val; }); }); });
            wp.customize('mw_pills_hover',  function(v){ v.bind(function(val){ aeUpdateStyle('mw-pills-hover', '.comunidad-pill:hover{background:'+val+' !important;border-color:'+val+' !important;color:#fff !important}'); }); });

            // Cuadros de categorías — live preview via CSS custom properties en el <section>
            var mwSegSection = document.querySelector('.segments-section');
            wp.customize('mw_segments_cols', function(v){
                v.bind(function(val){
                    if(mwSegSection) mwSegSection.style.setProperty('--seg-cols', val);
                });
            });
            wp.customize('mw_segments_height', function(v){
                v.bind(function(val){
                    if(mwSegSection) mwSegSection.style.setProperty('--seg-height', val + 'px');
                });
            });
            function mwUpdateSegGradient(){
                var c1 = wp.customize('mw_segments_label_bg').get()  || '#1E3A5F';
                var c2 = wp.customize('mw_segments_label_bg2').get() || '#0891B2';
                document.querySelectorAll('.segment-card__label').forEach(function(el){
                    el.style.background = 'linear-gradient(to right, '+c1+', '+c2+')';
                });
            }
            wp.customize('mw_segments_label_bg',  function(v){ v.bind(mwUpdateSegGradient); });
            wp.customize('mw_segments_label_bg2', function(v){ v.bind(mwUpdateSegGradient); });
            wp.customize('mw_segments_overlay', function(v){
                v.bind(function(val){
                    var alpha = Math.min(parseInt(val, 10), 100) / 100;
                    if(mwSegSection) mwSegSection.style.setProperty('--seg-overlay', alpha);
                });
            });
            // Grid de Países — live preview
            var mwCtrySection = document.querySelector('.countries-section');
            wp.customize('mw_countries_overlay', function(v){
                v.bind(function(val){
                    var alpha = Math.min(parseInt(val,10),100)/100;
                    if(mwCtrySection) mwCtrySection.style.setProperty('--ctry-overlay', alpha);
                });
            });
            wp.customize('mw_countries_text_color', function(v){
                v.bind(function(val){
                    if(mwCtrySection) mwCtrySection.style.setProperty('--ctry-text', val);
                });
            });
            wp.customize('mw_countries_link_color', function(v){
                v.bind(function(val){
                    if(mwCtrySection) mwCtrySection.style.setProperty('--ctry-link', val);
                });
            });
            wp.customize('mw_countries_card_height', function(v){
                v.bind(function(val){
                    if(mwCtrySection) mwCtrySection.style.setProperty('--ctry-height', val+'px');
                });
            });
            wp.customize('mw_countries_layout', function(v){
                v.bind(function(val){
                    if(mwCtrySection) mwCtrySection.setAttribute('data-layout', val);
                });
            });
            // Blog page — live preview
            var mwBlogArchive = document.querySelector('.blog-archive');
            var mwBlogHeader  = document.querySelector('.blog-header');
            wp.customize('mw_blog_title', function(v){
                v.bind(function(val){
                    var el = document.querySelector('.blog-header__title');
                    if(el) el.textContent = val;
                });
            });
            wp.customize('mw_blog_subtitle', function(v){
                v.bind(function(val){
                    var el = document.querySelector('.blog-header__subtitle');
                    if(el) el.textContent = val;
                });
            });
            wp.customize('mw_blog_header_bg', function(v){
                v.bind(function(val){
                    if(mwBlogHeader) mwBlogHeader.style.background = val;
                });
            });
            wp.customize('mw_blog_header_tc', function(v){
                v.bind(function(val){
                    if(mwBlogHeader) mwBlogHeader.style.color = val;
                    var t = document.querySelector('.blog-header__title');
                    var s = document.querySelector('.blog-header__subtitle');
                    if(t) t.style.color = val;
                    if(s) s.style.color = val;
                });
            });
            wp.customize('mw_blog_cols', function(v){
                v.bind(function(val){
                    if(mwBlogArchive) mwBlogArchive.style.setProperty('--blog-cols', val);
                });
            });
            wp.customize('mw_blog_card_img_height', function(v){
                v.bind(function(val){
                    if(mwBlogArchive) mwBlogArchive.style.setProperty('--blog-img-height', val+'px');
                });
            });
            wp.customize('mw_hero_overlay', function(v){
                v.bind(function(val){
                    var alpha = Math.round(val) / 100;
                    var hero = document.querySelector('.hero');
                    if (hero) hero.style.setProperty('--hero-overlay-opacity', alpha);
                });
            });
            // Colores botones hero — live preview
            function mwApplyBtnColor(selector, bg, tc){
                var btns = document.querySelectorAll(selector);
                btns.forEach(function(b){
                    b.style.color = tc;
                    if(bg === 'transparent'){
                        b.style.background = 'transparent';
                        b.style.borderColor = tc;
                    } else {
                        b.style.background = bg;
                        b.style.borderColor = bg;
                    }
                });
            }
            var mwCtaBtns = document.querySelectorAll('.hero__ctas .btn');
            wp.customize('mw_hero_cta1_bg',     function(v){ v.bind(function(val){ if(mwCtaBtns[0]){ mwCtaBtns[0].style.background=val; mwCtaBtns[0].style.borderColor=val; } }); });
            wp.customize('mw_hero_cta1_text_c', function(v){ v.bind(function(val){ if(mwCtaBtns[0]) mwCtaBtns[0].style.color=val; }); });
            wp.customize('mw_hero_cta2_bg',     function(v){ v.bind(function(val){ if(mwCtaBtns[1]){ mwCtaBtns[1].style.background=val; mwCtaBtns[1].style.borderColor=val; } }); });
            wp.customize('mw_hero_cta2_text_c', function(v){ v.bind(function(val){ if(mwCtaBtns[1]) mwCtaBtns[1].style.color=val; }); });
            wp.customize('mw_hero_cta3_bg',     function(v){ v.bind(function(val){ if(mwCtaBtns[2]){ mwCtaBtns[2].style.background=val==='transparent'?'transparent':val; mwCtaBtns[2].style.borderColor=val==='transparent'?wp.customize('mw_hero_cta3_text_c').get():val; } }); });
            wp.customize('mw_hero_cta3_text_c', function(v){ v.bind(function(val){ if(mwCtaBtns[2]) mwCtaBtns[2].style.color=val; }); });
        }(jQuery));"
    );
}

// ── Formulario de búsqueda personalizado (icono o texto) ─────────────────────
add_filter( 'get_search_form', 'mw_custom_search_form' );
function mw_custom_search_form( $form ) {
    $style   = get_theme_mod( 'mw_search_btn_style', 'text' );
    $btn_color = get_theme_mod( 'mw_search_btn_color', '#CC0000' );

    // SVGs inline para cada icono
    $icons = [
        'icon-lupa'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
        'icon-arrow' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
        'icon-bolt'  => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
        'icon-check' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>',
        'icon-enter' => '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 10 4 15 9 20"/><path d="M20 4v7a4 4 0 0 1-4 4H4"/></svg>',
    ];

    $btn_inner = ( $style === 'text' )
        ? esc_html__( 'Buscar', 'monetawp' )
        : ( $icons[ $style ] ?? $icons['icon-lupa'] );

    $icon_class = ( $style !== 'text' ) ? ' search-btn--icon' : '';
    $btn_label  = ( $style !== 'text' ) ? esc_attr__( 'Buscar', 'monetawp' ) : '';
    $aria_label = $btn_label ? ' aria-label="' . $btn_label . '"' : '';

    $color_style = 'style="background:' . esc_attr( $btn_color ) . ';border-color:' . esc_attr( $btn_color ) . '"';

    $form = '<form role="search" method="get" class="search-form" action="' . esc_url( home_url( '/' ) ) . '">'
        . '<label>'
        . '<span class="screen-reader-text">' . esc_html__( 'Buscar:', 'monetawp' ) . '</span>'
        . '<input type="search" class="search-field" placeholder="' . esc_attr__( 'Buscar ayudas...', 'monetawp' ) . '" value="' . get_search_query() . '" name="s" />'
        . '</label>'
        . '<button type="submit" class="search-submit' . esc_attr( $icon_class ) . '" ' . $color_style . $aria_label . '>'
        . $btn_inner
        . '</button>'
        . '</form>';

    return $form;
}

// ── Crear páginas legales al activar el tema ──────────────────────────────────
add_action( 'after_switch_theme', 'mw_create_legal_pages' );
function mw_create_legal_pages() {
    $pages = [
        'aviso-legal' => [
            'title'   => 'Aviso Legal',
            'content' => mw_legal_content( 'aviso-legal' ),
        ],
        'politica-de-privacidad' => [
            'title'   => 'Política de Privacidad',
            'content' => mw_legal_content( 'politica-privacidad' ),
        ],
        'politica-de-cookies' => [
            'title'   => 'Política de Cookies',
            'content' => mw_legal_content( 'politica-cookies' ),
        ],
        'terminos-y-condiciones' => [
            'title'   => 'Términos y Condiciones',
            'content' => mw_legal_content( 'terminos' ),
        ],
    ];

    foreach ( $pages as $slug => $data ) {
        // Solo crear si no existe ya una página con ese slug
        $exists = get_page_by_path( $slug );
        if ( $exists ) continue;

        wp_insert_post( [
            'post_title'   => $data['title'],
            'post_content' => $data['content'],
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_name'    => $slug,
            'post_author'  => 1,
        ] );
    }
}

function mw_legal_content( $type ) {
    $site  = get_bloginfo( 'name' );
    $url   = home_url( '/' );
    $email = get_bloginfo( 'admin_email' );
    $year  = date( 'Y' );

    switch ( $type ) {
        case 'aviso-legal':
            return "<!-- wp:paragraph --><p><strong>AVISO LEGAL</strong></p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>En cumplimiento de la Ley 34/2002, de 11 de julio, de Servicios de la Sociedad de la Información y de Comercio Electrónico (LSSICE), se informa a los usuarios de los datos del titular de este sitio web.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>Titular del sitio web</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p><strong>Nombre del sitio:</strong> {$site}<br><strong>URL:</strong> {$url}<br><strong>Correo electrónico:</strong> {$email}</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>Objeto</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>{$site} es un portal informativo sobre ayudas, becas y subvenciones públicas en España. El contenido publicado tiene carácter meramente informativo y no constituye asesoramiento jurídico, fiscal ni profesional de ningún tipo. Los usuarios deben verificar la vigencia y condiciones de cada convocatoria en las fuentes oficiales antes de actuar.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>Propiedad intelectual</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>Todos los contenidos de este sitio web (textos, imágenes, diseño y código) están protegidos por derechos de propiedad intelectual. Queda prohibida su reproducción, distribución o comunicación pública sin autorización expresa.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>Limitación de responsabilidad</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>El titular no garantiza la exactitud, integridad o actualidad de la información proporcionada. Las convocatorias oficiales pueden modificarse; consulta siempre el BOE y los organismos competentes.</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p><em>Última actualización: {$year}</em></p><!-- /wp:paragraph -->";

        case 'politica-privacidad':
            return "<!-- wp:paragraph --><p><strong>POLÍTICA DE PRIVACIDAD</strong></p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>En cumplimiento del Reglamento General de Protección de Datos (RGPD) (UE) 2016/679 y la Ley Orgánica 3/2018, de Protección de Datos Personales (LOPDGDD), te informamos sobre el tratamiento de tus datos personales.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>Responsable del tratamiento</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p><strong>Sitio web:</strong> {$site}<br><strong>Correo de contacto:</strong> {$email}</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>Datos que recogemos</h3><!-- /wp:heading -->
<!-- wp:list --><ul><li>Datos de navegación y cookies (ver Política de Cookies)</li><li>Dirección IP y datos técnicos del dispositivo</li><li>Datos que el usuario facilite voluntariamente a través de formularios</li></ul><!-- /wp:list -->
<!-- wp:heading {\"level\":3} --><h3>Finalidad y base jurídica</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>Los datos se tratan para: (1) prestar los servicios del sitio web; (2) mostrar publicidad personalizada a través de Google AdSense (interés legítimo y consentimiento); (3) analizar el tráfico web mediante cookies analíticas (consentimiento).</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>Transferencias internacionales</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>Google AdSense puede transferir datos a servidores en Estados Unidos. Google LLC está adherida al marco EU-U.S. Data Privacy Framework.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>Tus derechos</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>Puedes ejercer los derechos de acceso, rectificación, supresión, limitación, portabilidad y oposición escribiendo a: <strong>{$email}</strong></p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>Puedes presentar una reclamación ante la Agencia Española de Protección de Datos (aepd.es).</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p><em>Última actualización: {$year}</em></p><!-- /wp:paragraph -->";

        case 'politica-cookies':
            return "<!-- wp:paragraph --><p><strong>POLÍTICA DE COOKIES</strong></p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>Este sitio web utiliza cookies propias y de terceros. En cumplimiento de la Ley 34/2002 (LSSICE) y el RGPD, te informamos sobre su uso.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>¿Qué son las cookies?</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>Las cookies son pequeños ficheros de texto que se almacenan en tu dispositivo cuando visitas una web. Permiten recordar tus preferencias y mejorar la experiencia de navegación.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>Tipos de cookies que utilizamos</h3><!-- /wp:heading -->
<!-- wp:table --><figure class=\"wp-block-table\"><table><thead><tr><th>Tipo</th><th>Nombre</th><th>Finalidad</th><th>Duración</th></tr></thead><tbody><tr><td>Necesaria</td><td>mw_cookie_consent</td><td>Almacena tu preferencia de cookies</td><td>1 año</td></tr><tr><td>Analítica</td><td>_ga, _gid</td><td>Google Analytics – estadísticas anónimas</td><td>2 años</td></tr><tr><td>Publicidad</td><td>IDE, DSID</td><td>Google AdSense – anuncios personalizados</td><td>1 año</td></tr></tbody></table></figure><!-- /wp:table -->
<!-- wp:heading {\"level\":3} --><h3>Cómo gestionar las cookies</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>Puedes aceptar, rechazar o revocar tu consentimiento en cualquier momento usando el botón de preferencias de cookies en la parte inferior de la página, o configurando tu navegador:</p><!-- /wp:paragraph -->
<!-- wp:list --><ul><li><a href=\"https://support.google.com/chrome/answer/95647\" rel=\"noopener\">Google Chrome</a></li><li><a href=\"https://support.mozilla.org/es/kb/habilitar-y-deshabilitar-cookies-sitios-web\" rel=\"noopener\">Mozilla Firefox</a></li><li><a href=\"https://support.apple.com/es-es/guide/safari/sfri11471\" rel=\"noopener\">Safari</a></li></ul><!-- /wp:list -->
<!-- wp:paragraph --><p>Para optar fuera de la publicidad personalizada de Google: <a href=\"https://adssettings.google.com\" rel=\"noopener\">adssettings.google.com</a></p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p><em>Última actualización: {$year}</em></p><!-- /wp:paragraph -->";

        case 'terminos':
            return "<!-- wp:paragraph --><p><strong>TÉRMINOS Y CONDICIONES DE USO</strong></p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p>El acceso y uso de {$site} implica la aceptación de los presentes términos. Si no estás de acuerdo, debes abstenerte de usar el sitio.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>1. Objeto</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>{$site} es un portal informativo sobre ayudas, becas, subvenciones y convocatorias públicas en España. La información publicada es de carácter divulgativo y no sustituye el asesoramiento profesional.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>2. Uso permitido</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>El usuario se compromete a usar el sitio de forma lícita, sin dañar, inutilizar o deteriorar los servicios. Queda prohibido el scraping automatizado, la reproducción de contenidos sin autorización y cualquier uso comercial no autorizado.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>3. Exactitud de la información</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>Nos esforzamos por mantener la información actualizada, pero las convocatorias pueden modificarse o cerrarse sin previo aviso. Siempre verifica los datos en las fuentes oficiales (BOE, organismo convocante) antes de presentar una solicitud.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>4. Publicidad</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>Este sitio muestra anuncios de Google AdSense. La visualización de anuncios no implica recomendación de los productos o servicios anunciados.</p><!-- /wp:paragraph -->
<!-- wp:heading {\"level\":3} --><h3>5. Ley aplicable</h3><!-- /wp:heading -->
<!-- wp:paragraph --><p>Estos términos se rigen por la legislación española. Para cualquier controversia, las partes se someten a los Juzgados y Tribunales del domicilio del usuario, salvo que la ley establezca otro fuero.</p><!-- /wp:paragraph -->
<!-- wp:paragraph --><p><em>Última actualización: {$year}</em></p><!-- /wp:paragraph -->";
    }
    return '';
}

// ── Term meta: campo "Título H1 personalizado" en admin de categorías ─────────
add_action( 'init', function() {
    foreach ( [ 'tipo_ayuda', 'beneficiario', 'comunidad_autonoma', 'category' ] as $_tax ) {
        add_action( $_tax . '_edit_form_fields', 'mw_term_custom_h1_field' );
    }
} );

function mw_term_custom_h1_field( $term ) {
    $custom_h1   = get_term_meta( $term->term_id, 'mw_custom_h1',   true );
    $custom_desc = get_term_meta( $term->term_id, 'mw_custom_desc', true );
    ?>
    <tr class="form-field">
        <th scope="row"><label for="mw_custom_h1"><?php _e( 'Título H1 personalizado', 'monetawp' ); ?></label></th>
        <td>
            <input type="text" name="mw_custom_h1" id="mw_custom_h1" value="<?php echo esc_attr( $custom_h1 ); ?>" class="large-text">
            <p class="description"><?php _e( 'Titular principal de la página de archivo. Si se deja vacío, se usa el nombre de la categoría.', 'monetawp' ); ?></p>
        </td>
    </tr>
    <tr class="form-field">
        <th scope="row"><label for="mw_custom_desc"><?php _e( 'Descripción SEO / intro', 'monetawp' ); ?></label></th>
        <td>
            <textarea name="mw_custom_desc" id="mw_custom_desc" rows="3" class="large-text"><?php echo esc_textarea( $custom_desc ); ?></textarea>
            <p class="description"><?php _e( 'Párrafo introductorio bajo el título. También se usa como meta description si no hay plugin SEO activo.', 'monetawp' ); ?></p>
        </td>
    </tr>
    <?php
}

add_action( 'edited_term', 'mw_save_term_custom_h1' );
function mw_save_term_custom_h1( $term_id ) {
    if ( isset( $_POST['mw_custom_h1'] ) ) {
        update_term_meta( $term_id, 'mw_custom_h1',   sanitize_text_field( $_POST['mw_custom_h1'] ) );
    }
    if ( isset( $_POST['mw_custom_desc'] ) ) {
        update_term_meta( $term_id, 'mw_custom_desc', sanitize_textarea_field( $_POST['mw_custom_desc'] ) );
    }
}

// ── Ajustar posts_per_page en archivos según Customizer ───────────────────────
add_action( 'pre_get_posts', function( $query ) {
    if ( is_admin() || ! $query->is_main_query() ) return;
    if ( $query->is_tax() || $query->is_category() || $query->is_tag() || $query->is_archive() ) {
        $per_page = absint( get_theme_mod( 'mw_archive_posts_per_page', 9 ) ) ?: 9;
        $query->set( 'posts_per_page', $per_page );
    }
} );

// ── Helper: obtener H1 y descripción de una página de archivo ─────────────────
function mw_archive_get_heading( $term = null ) {
    if ( ! $term ) $term = get_queried_object();
    if ( ! $term || ! isset( $term->term_id ) ) return [ 'h1' => '', 'desc' => '' ];

    $custom_h1   = get_term_meta( $term->term_id, 'mw_custom_h1',   true );
    $custom_desc = get_term_meta( $term->term_id, 'mw_custom_desc', true );

    $h1   = $custom_h1   ?: $term->name;
    $desc = $custom_desc ?: $term->description;

    return [ 'h1' => $h1, 'desc' => $desc ];
}

// ── Footer: columnas de fallback cuando no hay nada configurado ──────────────
function mw_footer_fallback_columns() {
    $cols = [];
    // Intentar usar los primeros 3 términos de tipo_ayuda como fallback
    $terms = get_terms( [ 'taxonomy' => 'tipo_ayuda', 'hide_empty' => false, 'number' => 3 ] );
    if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
        foreach ( $terms as $t ) {
            $cols[] = [ 'term' => $t, 'taxonomy' => 'tipo_ayuda', 'count' => 5 ];
        }
    }
    // Si no hay términos, devolver columnas vacías con nombres por defecto
    if ( empty( $cols ) ) {
        $defaults = [ 'Becas', 'Subvenciones', 'Convocatorias' ];
        foreach ( $defaults as $name ) {
            $t = get_term_by( 'name', $name, 'tipo_ayuda' );
            if ( $t ) $cols[] = [ 'term' => $t, 'taxonomy' => 'tipo_ayuda', 'count' => 5 ];
        }
    }
    return $cols;
}

// ── XML Sitemap: incluir CPT convocatoria ────────────────────────────────────
add_filter( 'wp_sitemaps_post_types', function( $post_types ) {
    if ( post_type_exists( 'convocatoria' ) ) {
        $post_types['convocatoria'] = get_post_type_object( 'convocatoria' );
    }
    return $post_types;
} );

// ── Mover controles nativos de logo y favicon a nuestra sección ──────────────
// Prioridad 20 garantiza que custom_logo y site_icon ya estén registrados (prio 10)
add_action( 'customize_register', function( $wp_customize ) {
    $logo = $wp_customize->get_control( 'custom_logo' );
    if ( $logo ) {
        $logo->section  = 'mw_logo';
        $logo->priority = 1;
        $logo->label    = __( 'Imagen del logo', 'monetawp' );
    }

    $favicon = $wp_customize->get_control( 'site_icon' );
    if ( $favicon ) {
        $favicon->section     = 'mw_logo';
        $favicon->priority    = 2;
        $favicon->label       = __( 'Favicon (ícono del sitio)', 'monetawp' );
        $favicon->description = __( 'Mínimo 512×512 px. Se usa como favicon, ícono en móviles y en pestañas del navegador.', 'monetawp' );
    }
}, 20 );

// ── Insertar términos por defecto al activar el tema ─────────────────────────
add_action( 'after_switch_theme', 'mw_insert_default_terms' );
