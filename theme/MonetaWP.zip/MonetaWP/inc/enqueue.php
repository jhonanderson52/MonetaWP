<?php
/**
 * Enqueue CSS y JS — sin jQuery, todo defer, mobile-first.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'wp_enqueue_scripts', 'mw_enqueue_assets' );
function mw_enqueue_assets() {

    // ── CSS ──────────────────────────────────────────────────────────────────
    wp_enqueue_style(
        'ae-main',
        MW_ASSETS . '/css/main.css',
        [],
        MW_VERSION
    );

    if ( is_front_page() ) {
        wp_enqueue_style(
            'ae-homepage',
            MW_ASSETS . '/css/homepage.css',
            [ 'ae-main' ],
            MW_VERSION
        );
    }

    // ── JS ───────────────────────────────────────────────────────────────────
    wp_enqueue_script(
        'ae-main',
        MW_ASSETS . '/js/main.js',
        [],
        MW_VERSION,
        true // footer
    );

    // Añadir defer a todos los scripts del tema
    add_filter( 'script_loader_tag', 'mw_add_defer', 10, 2 );
}

function mw_add_defer( $tag, $handle ) {
    $defer_handles = [ 'ae-main', 'ae-blocks' ];
    if ( in_array( $handle, $defer_handles, true ) ) {
        return str_replace( ' src=', ' defer src=', $tag );
    }
    return $tag;
}

// CSS crítico inline (above-the-fold) para LCP óptimo
add_action( 'wp_head', 'mw_inline_critical_css', 1 );
function mw_inline_critical_css() {
    $critical = '
    *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
    body{font-family:system-ui,-apple-system,sans-serif;font-size:18px;line-height:1.7;color:#1F2937;background:#fff}
    .site-header{--hdr-fg:#fff;--hdr-fg-muted:rgba(255,255,255,.55);--hdr-input-bg:rgba(255,255,255,.12);--hdr-input-border:rgba(255,255,255,.3);background:#1A2B4A;position:sticky;top:0;z-index:100}
    .site-nav{display:flex;align-items:center;gap:.75rem;padding:.6rem 1rem;max-width:1200px;margin:0 auto;width:100%}
    .nav-brand{flex-shrink:0;display:flex;align-items:center}
    .nav-brand .custom-logo{height:48px;max-width:220px;width:auto;object-fit:contain}
    .nav-actions{display:flex;align-items:center;gap:.5rem;margin-left:auto}
    .nav-menu-desktop{display:none}
    .nav-search-wrap{display:none}
    .mobile-drawer{display:none}
    .nav-toggle{background:none;border:none;cursor:pointer;color:#fff;width:40px;height:40px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;padding:.4rem}
    .hamburger-icon{display:flex;flex-direction:column;gap:5px}
    .hamburger-icon span{display:block;width:22px;height:2px;background:#fff;border-radius:2px}
    @media(min-width:1024px){.nav-toggle{display:none!important}.nav-menu-desktop{display:flex}.nav-search-wrap{display:block}}
    ';
    echo '<style id="ae-critical">' . $critical . '</style>' . "\n";
}
