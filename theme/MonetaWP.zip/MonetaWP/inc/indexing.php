<?php
/**
 * Indexación Masiva — Google Indexing API + IndexNow
 *
 * Página de administración en Herramientas → Indexación Masiva.
 * Envía todas las URLs publicadas a Google y/o Bing/Yandex en masa,
 * sin necesidad de hacerlo una a una en Search Console.
 */

defined( 'ABSPATH' ) || exit;

// ── A. Claves de wp_options ───────────────────────────────────────────────────
define( 'MWI_OPTION_SA_JSON',    'mw_google_sa_json' );
define( 'MWI_OPTION_IN_KEY',     'mw_indexnow_key' );
define( 'MWI_OPTION_LOG',        'mw_indexing_log' );
define( 'MWI_OPTION_DAILY',      'mw_indexing_daily_count' );
define( 'MWI_TRANSIENT_TOKEN',   'mw_google_access_token' );
define( 'MWI_TRANSIENT_TOKEN_SC', 'mw_google_access_token_sc' );
define( 'MWI_DAILY_LIMIT',       200 );
define( 'MWI_LOG_MAX',           500 );

// ── B. Registro de menú ───────────────────────────────────────────────────────
add_action( 'admin_menu', 'mwi_register_admin_page' );
function mwi_register_admin_page() {
    add_management_page(
        'Indexación Masiva',
        'Indexación Masiva',
        'manage_options',
        'mw-indexacion-masiva',
        'mwi_render_admin_page'
    );
}

// ── C. Renderer principal ─────────────────────────────────────────────────────
function mwi_render_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;

    // Guardar configuración
    if ( isset( $_POST['mwi_save_config'] ) ) {
        mwi_save_config();
    }

    // Limpiar historial
    if ( isset( $_POST['mwi_clear_log'] ) && check_admin_referer( 'mwi_clear_log' ) ) {
        delete_option( MWI_OPTION_LOG );
    }

    $tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'config';
    $base_url = admin_url( 'tools.php?page=mw-indexacion-masiva' );

    // mwiData disponible en todas las pestañas
    $daily_remaining = max( 0, MWI_DAILY_LIMIT - mwi_get_daily_count() );
    ?>
    <script>
    var mwiData = {
        nonce:           '<?php echo esc_js( wp_create_nonce( 'mwi_ajax' ) ); ?>',
        ajaxurl:         '<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>',
        daily_remaining: <?php echo intval( $daily_remaining ); ?>
    };
    </script>
    <div class="wrap">
        <h1>🔍 Indexación Masiva — MonetaWP</h1>

        <nav class="nav-tab-wrapper" style="margin-bottom:0">
            <a href="<?php echo esc_url( $base_url . '&tab=config' ); ?>"
               class="nav-tab <?php echo $tab === 'config' ? 'nav-tab-active' : ''; ?>">
               ⚙️ Configuración
            </a>
            <a href="<?php echo esc_url( $base_url . '&tab=send' ); ?>"
               class="nav-tab <?php echo $tab === 'send' ? 'nav-tab-active' : ''; ?>">
               🚀 Enviar URLs
            </a>
            <a href="<?php echo esc_url( $base_url . '&tab=history' ); ?>"
               class="nav-tab <?php echo $tab === 'history' ? 'nav-tab-active' : ''; ?>">
               📋 Historial
            </a>
        </nav>

        <div style="background:#fff;border:1px solid #c3c4c7;border-top:none;padding:24px;">
            <?php
            if ( $tab === 'config' )  mwi_render_tab_config();
            elseif ( $tab === 'send' ) mwi_render_tab_send();
            else                       mwi_render_tab_history();
            ?>
        </div>
    </div>
    <?php
    // Inline JS solo en esta página
    mwi_print_admin_js();
}

// ── D. Tab Configuración ──────────────────────────────────────────────────────
function mwi_save_config() {
    check_admin_referer( 'mwi_save_config' );

    $json = sanitize_textarea_field( wp_unslash( $_POST['mwi_sa_json'] ?? '' ) );
    $key  = sanitize_text_field( wp_unslash( $_POST['mwi_in_key'] ?? '' ) );

    // Validar que el JSON es un service account válido
    if ( $json ) {
        $parsed = json_decode( $json, true );
        if ( ! isset( $parsed['type'] ) || $parsed['type'] !== 'service_account' ) {
            add_settings_error( 'mwi', 'bad_json', 'El JSON no parece ser un Service Account válido.', 'error' );
            return;
        }
    }

    update_option( MWI_OPTION_SA_JSON, $json, false );
    update_option( MWI_OPTION_IN_KEY,  $key,  true );
    delete_transient( MWI_TRANSIENT_TOKEN ); // forzar nuevo token con nuevas credenciales

    add_settings_error( 'mwi', 'saved', 'Configuración guardada correctamente.', 'success' );
}

function mwi_render_tab_config() {
    settings_errors( 'mwi' );
    $saved_json   = get_option( MWI_OPTION_SA_JSON, '' );
    $indexnow_key = get_option( MWI_OPTION_IN_KEY, '' );
    $has_json     = ! empty( $saved_json );
    ?>
    <form method="post" action="<?php echo esc_url( admin_url( 'tools.php?page=mw-indexacion-masiva&tab=config' ) ); ?>">
        <?php wp_nonce_field( 'mwi_save_config' ); ?>
        <input type="hidden" name="mwi_save_config" value="1">

        <h2>Google Indexing API</h2>
        <p>
            Necesitas un <strong>Service Account</strong> de Google Cloud con permiso de
            <strong>Propietario</strong> en Search Console.
            <a href="#mwi-google-guide" style="text-decoration:none">Ver guía de configuración ↓</a>
        </p>

        <table class="form-table" role="presentation">
            <tr>
                <th scope="row"><label for="mwi_sa_json">Service Account JSON</label></th>
                <td>
                    <?php if ( $has_json ) : ?>
                        <p style="color:green;font-weight:600">✅ Credenciales guardadas.</p>
                        <p>
                            <label>
                                <input type="checkbox" name="mwi_replace_json" id="mwi_replace_json">
                                Reemplazar con un JSON nuevo
                            </label>
                        </p>
                        <div id="mwi_json_field" style="display:none">
                    <?php endif; ?>
                    <textarea id="mwi_sa_json" name="mwi_sa_json" rows="10" style="width:100%;font-family:monospace;font-size:12px"
                              placeholder='{ "type": "service_account", "project_id": "...", "private_key": "...", "client_email": "...", ... }'
                    ><?php echo $has_json ? '' : ''; ?></textarea>
                    <p class="description">
                        Pega aquí el contenido completo del fichero .json descargado de
                        Google Cloud Console → IAM & Admin → Service Accounts → Keys.
                        <strong>El JSON se guarda encriptado en la base de datos y nunca se expone en el frontend.</strong>
                    </p>
                    <?php if ( $has_json ) : ?>
                        </div>
                        <script>
                        document.getElementById('mwi_replace_json').addEventListener('change', function(){
                            document.getElementById('mwi_json_field').style.display = this.checked ? '' : 'none';
                            document.getElementById('mwi_sa_json').required = this.checked;
                        });
                        </script>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="mwi_in_key">Clave API IndexNow</label></th>
                <td>
                    <input type="text" id="mwi_in_key" name="mwi_in_key"
                           value="<?php echo esc_attr( $indexnow_key ); ?>"
                           class="regular-text" placeholder="abc123def456abc123def456abc12345">
                    <p class="description">
                        Genera una clave aleatoria (mínimo 8 caracteres hex) y crea el fichero de verificación
                        <code><?php echo esc_html( $indexnow_key ?: '{tu-clave}' ); ?>.txt</code>
                        en la raíz del sitio con la clave como único contenido.
                    </p>
                </td>
            </tr>
        </table>

        <p>
            <?php submit_button( 'Guardar configuración', 'primary', 'submit', false ); ?>
            &nbsp;
            <button type="button" id="mwi-test-token" class="button"
                    style="<?php echo $has_json ? '' : 'display:none'; ?>">
                Verificar credenciales Google
            </button>
            <span id="mwi-token-result" style="margin-left:8px;font-weight:600"></span>
        </p>
    </form>

    <hr>
    <h2 id="mwi-google-guide">Guía de Configuración — Google Indexing API</h2>
    <ol style="line-height:1.8">
        <li>Ve a <strong>console.cloud.google.com</strong> y crea un proyecto nuevo.</li>
        <li>En <em>APIs & Services → Library</em>, busca <strong>"Web Search Indexing API"</strong> y actívala.</li>
        <li>Ve a <em>IAM & Admin → Service Accounts</em> → <strong>Create Service Account</strong>.</li>
        <li>Ponle nombre (ej. <em>monetawp-indexing</em>), no asignes roles por ahora.</li>
        <li>Abre la cuenta creada → pestaña <strong>Keys</strong> → Add Key → Create new key → <strong>JSON</strong>. Se descargará el fichero.</li>
        <li>
            Ve a <strong>Google Search Console</strong> → tu propiedad → Configuración → Usuarios y permisos → Añadir usuario.<br>
            Introduce el email del Service Account (lo ves en el JSON, campo <code>client_email</code>).<br>
            Asigna permiso de <strong>Propietario</strong> (no "Propietario completo", sino el rol "Propietario").
        </li>
        <li>Pega el contenido del JSON descargado en el campo de arriba y guarda.</li>
        <li>Haz clic en <strong>Verificar credenciales Google</strong> para confirmar que funciona.</li>
    </ol>
    <?php
}

// ── E. Tab Enviar URLs ────────────────────────────────────────────────────────
function mwi_render_tab_send() {
    $daily     = mwi_get_daily_count();
    $remaining = max( 0, MWI_DAILY_LIMIT - $daily );
    $urls      = mwi_collect_all_urls();
    $log       = mwi_get_log();

    // Construir índice de último envío por URL
    $last_sent = [];
    $last_status = [];
    foreach ( $log as $entry ) {
        foreach ( $entry['urls'] as $u ) {
            if ( ! isset( $last_sent[ $u ] ) ) {
                $last_sent[ $u ]   = $entry['timestamp'];
                $last_status[ $u ] = $entry['responses'][ $u ]['status'] ?? '';
            }
        }
    }

    $has_creds = ! empty( get_option( MWI_OPTION_SA_JSON, '' ) );
    $has_inkey = ! empty( get_option( MWI_OPTION_IN_KEY, '' ) );
    ?>

    <?php if ( ! $has_creds && ! $has_inkey ) : ?>
        <div class="notice notice-warning inline"><p>
            ⚠️ No hay credenciales configuradas.
            <a href="<?php echo esc_url( admin_url( 'tools.php?page=mw-indexacion-masiva&tab=config' ) ); ?>">
                Ve a Configuración
            </a> primero.
        </p></div>
    <?php endif; ?>

    <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap;margin-bottom:16px">
        <div class="notice notice-info inline" style="margin:0;padding:8px 12px">
            <p style="margin:0">
                📊 Google hoy: <strong><?php echo intval( $daily ); ?>/<?php echo MWI_DAILY_LIMIT; ?></strong>
                &nbsp;·&nbsp; Disponibles: <strong><?php echo intval( $remaining ); ?></strong>
            </p>
        </div>
        <div class="notice notice-info inline" style="margin:0;padding:8px 12px">
            <p style="margin:0">📄 Total URLs: <strong><?php echo count( $urls ); ?></strong></p>
        </div>
    </div>

    <!-- Barra de progreso -->
    <div id="mwi-progress-wrap" style="display:none;margin:16px 0">
        <div style="background:#ddd;border-radius:4px;height:22px;width:100%;overflow:hidden">
            <div id="mwi-progress-bar"
                 style="background:#0073aa;height:22px;width:0%;border-radius:4px;transition:width .3s ease"></div>
        </div>
        <p id="mwi-progress-label" style="margin:6px 0;font-size:13px;color:#555">Preparando...</p>
    </div>
    <div id="mwi-result-box" style="display:none;margin:12px 0"></div>

    <p>
        <button type="button" id="mwi-select-all"   class="button">✅ Seleccionar todo</button>
        <button type="button" id="mwi-deselect-all" class="button">⬜ Deseleccionar todo</button>
        &nbsp;
        <button type="button" id="mwi-submit-google"
                class="button button-primary"
                <?php echo $has_creds ? '' : 'disabled title="Configura las credenciales primero"'; ?>>
            🔵 Enviar a Google (Indexing API)
        </button>
        <button type="button" id="mwi-submit-indexnow"
                class="button"
                <?php echo $has_inkey ? '' : 'disabled title="Configura la clave IndexNow primero"'; ?>>
            🟠 Enviar a IndexNow (Bing/Yandex)
        </button>
    </p>

    <table class="wp-list-table widefat fixed striped" style="margin-top:8px">
        <thead>
            <tr>
                <td class="manage-column column-cb check-column">
                    <input type="checkbox" id="mwi-check-all" checked>
                </td>
                <th>URL</th>
                <th style="width:130px">Tipo</th>
                <th style="width:150px">Último envío</th>
                <th style="width:120px">Estado Google</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ( $urls as $entry ) :
                $u       = $entry['url'];
                $ls      = $last_sent[ $u ] ?? null;
                $status  = $last_status[ $u ] ?? '';
                $sc      = mwi_status_class( $status );
            ?>
            <tr>
                <th class="check-column">
                    <input type="checkbox" class="mwi-url-cb" value="<?php echo esc_attr( $u ); ?>" checked>
                </th>
                <td style="word-break:break-all">
                    <a href="<?php echo esc_url( $u ); ?>" target="_blank" rel="noopener">
                        <?php echo esc_html( $u ); ?>
                    </a>
                </td>
                <td><?php echo esc_html( mwi_type_label( $entry['type'] ) ); ?></td>
                <td><?php echo $ls ? esc_html( date_i18n( 'd/m/Y H:i', $ls ) ) : '<span style="color:#aaa">—</span>'; ?></td>
                <td>
                    <?php
                    $label_map = [
                        'URL_UPDATED' => 'Enviada ✓',
                        'SUBMITTED'   => 'Enviada ✓',
                        'URL_DELETED' => 'Eliminada',
                        'PENDING'     => 'Pendiente',
                        'UNKNOWN'     => 'Desconocido',
                        'ACCEPTED'    => 'Aceptada ✓',
                    ];
                    $display_label = $label_map[ $status ] ?? esc_html( $status );
                    if ( str_starts_with( $status, 'ERROR' ) ) {
                        $display_label = 'Error';
                    }
                    ?>
                    <?php if ( $status ) : ?>
                        <span class="mwi-status-badge"
                              style="font-size:11px;padding:2px 6px;border-radius:3px;<?php echo esc_attr( $sc ); ?>">
                            <?php echo esc_html( $display_label ); ?>
                        </span>
                    <?php else : ?>
                        <span style="color:#aaa;font-size:11px">—</span>
                    <?php endif; ?>
                    <button type="button"
                            class="button button-small mwi-verify-btn"
                            data-url="<?php echo esc_attr( $u ); ?>"
                            style="margin-top:4px;display:block;font-size:11px;padding:1px 6px">
                        🔍 Verificar
                    </button>
                    <span class="mwi-verify-result"
                          style="display:none;margin-top:3px;font-size:11px;line-height:1.4"></span>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php
}

// ── F. Tab Historial ──────────────────────────────────────────────────────────
function mwi_render_tab_history() {
    $log = mwi_get_log();
    ?>
    <form method="post" style="margin-bottom:16px">
        <?php wp_nonce_field( 'mwi_clear_log' ); ?>
        <input type="hidden" name="mwi_clear_log" value="1">
        <button type="submit" class="button button-secondary"
                onclick="return confirm('¿Eliminar todo el historial?')">
            🗑️ Limpiar historial
        </button>
        <span style="color:#666;margin-left:12px;font-size:13px">
            <?php echo count( $log ); ?> registros guardados
        </span>
    </form>

    <?php if ( empty( $log ) ) : ?>
        <p style="color:#666">No hay registros aún. Envía algunas URLs para ver el historial aquí.</p>
    <?php else : ?>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th style="width:140px">Fecha</th>
                <th style="width:90px">API</th>
                <th style="width:80px">URLs</th>
                <th style="width:70px">✅ OK</th>
                <th style="width:80px">❌ Error</th>
                <th>Detalle</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ( $log as $entry ) : ?>
            <tr>
                <td><?php echo esc_html( date_i18n( 'd/m/Y H:i:s', $entry['timestamp'] ) ); ?></td>
                <td>
                    <strong><?php echo esc_html( strtoupper( $entry['api'] ) ); ?></strong>
                </td>
                <td><?php echo intval( $entry['total'] ); ?></td>
                <td style="color:green;font-weight:600"><?php echo intval( $entry['success'] ); ?></td>
                <td style="color:<?php echo $entry['failed'] > 0 ? 'red' : '#aaa'; ?>;font-weight:600">
                    <?php echo intval( $entry['failed'] ); ?>
                </td>
                <td>
                    <details>
                        <summary style="cursor:pointer;color:#0073aa">
                            Ver <?php echo intval( $entry['total'] ); ?> URLs
                        </summary>
                        <div style="max-height:200px;overflow:auto;margin-top:8px">
                        <table style="width:100%;font-size:12px;border-collapse:collapse">
                            <?php foreach ( $entry['urls'] as $u ) :
                                $resp   = $entry['responses'][ $u ] ?? [];
                                $code   = $resp['http_code'] ?? '?';
                                $status = $resp['status']    ?? '?';
                                $ok     = ( $code >= 200 && $code < 300 );
                            ?>
                            <tr style="border-bottom:1px solid #eee">
                                <td style="padding:3px 6px;color:<?php echo $ok ? 'green' : 'red'; ?>">
                                    <?php echo intval( $code ); ?>
                                </td>
                                <td style="padding:3px 6px;font-size:11px;color:#555">
                                    <?php echo esc_html( $status ); ?>
                                </td>
                                <td style="padding:3px 6px;word-break:break-all">
                                    <a href="<?php echo esc_url( $u ); ?>" target="_blank" rel="noopener">
                                        <?php echo esc_html( $u ); ?>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </table>
                        </div>
                    </details>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <?php
}

// ── G. AJAX Handlers ──────────────────────────────────────────────────────────
add_action( 'wp_ajax_mwi_index_google',        'mwi_ajax_index_google' );
add_action( 'wp_ajax_mwi_index_indexnow',     'mwi_ajax_index_indexnow' );
add_action( 'wp_ajax_mwi_test_token',         'mwi_ajax_test_token' );
add_action( 'wp_ajax_mwi_check_google_status', 'mwi_ajax_check_google_status' );

function mwi_ajax_index_google() {
    check_ajax_referer( 'mwi_ajax', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

    $urls = array_map( 'esc_url_raw', (array) ( $_POST['urls'] ?? [] ) );
    $urls = array_filter( $urls );
    if ( empty( $urls ) ) wp_send_json_error( 'No URLs recibidas.' );

    // Verificar límite diario
    $daily = mwi_get_daily_count();
    if ( $daily >= MWI_DAILY_LIMIT ) {
        wp_send_json_error( 'Límite diario de ' . MWI_DAILY_LIMIT . ' URLs alcanzado. Vuelve mañana.' );
    }
    $urls = array_slice( $urls, 0, MWI_DAILY_LIMIT - $daily );

    $result = mwi_call_google_api( $urls );
    if ( is_wp_error( $result ) ) {
        wp_send_json_error( $result->get_error_message() );
    }

    mwi_log_submission( $urls, $result, 'google' );
    mwi_increment_daily( count( $urls ) );

    wp_send_json_success( $result );
}

function mwi_ajax_index_indexnow() {
    check_ajax_referer( 'mwi_ajax', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

    $urls = array_map( 'esc_url_raw', (array) ( $_POST['urls'] ?? [] ) );
    $urls = array_filter( $urls );
    if ( empty( $urls ) ) wp_send_json_error( 'No URLs recibidas.' );

    $code = mwi_call_indexnow( $urls );

    $responses = [];
    $ok = ( $code >= 200 && $code < 300 ) || $code === 202;
    foreach ( $urls as $u ) {
        $responses[ $u ] = [ 'http_code' => $code, 'status' => $ok ? 'ACCEPTED' : 'ERROR_' . $code ];
    }

    mwi_log_submission( $urls, $responses, 'indexnow' );

    if ( $ok ) {
        wp_send_json_success( $responses );
    } else {
        wp_send_json_error( 'IndexNow respondió con código ' . $code );
    }
}

function mwi_ajax_test_token() {
    check_ajax_referer( 'mwi_ajax', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

    delete_transient( MWI_TRANSIENT_TOKEN );
    $token = mwi_get_google_token();
    if ( is_wp_error( $token ) ) {
        wp_send_json_error( $token->get_error_message() );
    }
    wp_send_json_success( 'Token obtenido correctamente.' );
}

// ── H. Generación JWT (puro PHP, sin librerías) ───────────────────────────────
function mwi_base64url( $data ) {
    return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
}

function mwi_get_google_token() {
    $cached = get_transient( MWI_TRANSIENT_TOKEN );
    if ( $cached ) return $cached;

    $json_str = get_option( MWI_OPTION_SA_JSON, '' );
    if ( ! $json_str ) return new WP_Error( 'no_creds', 'No hay credenciales de Service Account configuradas.' );

    $creds = json_decode( $json_str, true );
    if ( ! $creds || $creds['type'] !== 'service_account' ) {
        return new WP_Error( 'bad_creds', 'El JSON de credenciales no es válido.' );
    }

    $now = time();
    $header  = mwi_base64url( json_encode( [ 'alg' => 'RS256', 'typ' => 'JWT' ] ) );
    $payload = mwi_base64url( json_encode( [
        'iss'   => $creds['client_email'],
        'scope' => 'https://www.googleapis.com/auth/indexing',
        'aud'   => 'https://oauth2.googleapis.com/token',
        'iat'   => $now,
        'exp'   => $now + 3600,
    ] ) );

    $signing_input = $header . '.' . $payload;
    $pem           = $creds['private_key'];
    $pk            = openssl_pkey_get_private( $pem );

    if ( ! $pk ) {
        return new WP_Error( 'bad_key', 'No se pudo leer la clave privada del Service Account.' );
    }

    $sig = '';
    if ( ! openssl_sign( $signing_input, $sig, $pk, 'SHA256' ) ) {
        return new WP_Error( 'sign_fail', 'Error al firmar el JWT.' );
    }

    $jwt = $signing_input . '.' . mwi_base64url( $sig );

    $resp = wp_remote_post( 'https://oauth2.googleapis.com/token', [
        'body'    => [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion'  => $jwt,
        ],
        'timeout' => 15,
    ] );

    if ( is_wp_error( $resp ) ) return $resp;

    $body  = json_decode( wp_remote_retrieve_body( $resp ), true );
    $token = $body['access_token'] ?? '';

    if ( ! $token ) {
        $err = $body['error_description'] ?? $body['error'] ?? 'Respuesta vacía de Google.';
        return new WP_Error( 'no_token', $err );
    }

    set_transient( MWI_TRANSIENT_TOKEN, $token, 3500 );
    return $token;
}

// ── I. Llamada a Google Indexing API ──────────────────────────────────────────
function mwi_call_google_api( array $urls ) {
    $token = mwi_get_google_token();
    if ( is_wp_error( $token ) ) return $token;

    $responses = [];
    foreach ( $urls as $url ) {
        $resp = wp_remote_post(
            'https://indexing.googleapis.com/v3/urlNotifications:publish',
            [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json',
                ],
                'body'    => json_encode( [ 'url' => $url, 'type' => 'URL_UPDATED' ] ),
                'timeout' => 10,
            ]
        );

        $code = is_wp_error( $resp ) ? 0 : wp_remote_retrieve_response_code( $resp );
        $body = is_wp_error( $resp ) ? [] : json_decode( wp_remote_retrieve_body( $resp ), true );

        $status = mwi_parse_google_response( $resp, $body, $code );

        $responses[ $url ] = [ 'http_code' => $code, 'status' => $status ];
    }

    return $responses;
}

// ── J-0. Parser robusto de respuesta Google Indexing API (fix UNKNOWN) ────────
function mwi_parse_google_response( $resp, $body, $http_code ) {
    if ( is_wp_error( $resp ) ) {
        return 'ERROR: ' . $resp->get_error_message();
    }
    if ( $http_code >= 400 ) {
        $msg = $body['error']['message'] ?? $body['error']['status'] ?? ( 'HTTP ' . $http_code );
        return 'ERROR: ' . $msg;
    }
    // Respuesta correcta con tipo explícito (URL_UPDATED, URL_DELETED)
    $type = $body['urlNotificationMetadata']['latestUpdate']['type'] ?? null;
    if ( $type ) {
        return $type;
    }
    // Google confirmó la URL pero aún sin tipo (en cola de rastreo)
    if ( ! empty( $body['urlNotificationMetadata']['url'] ) ) {
        return 'SUBMITTED';
    }
    return 'PENDING';
}

// ── J-1. Token Search Console (scope webmasters) ──────────────────────────────
function mwi_get_google_token_sc() {
    $cached = get_transient( MWI_TRANSIENT_TOKEN_SC );
    if ( $cached ) return $cached;

    $json_str = get_option( MWI_OPTION_SA_JSON, '' );
    if ( ! $json_str ) return new WP_Error( 'no_creds', 'No hay credenciales configuradas.' );

    $creds = json_decode( $json_str, true );
    if ( ! $creds || ( $creds['type'] ?? '' ) !== 'service_account' ) {
        return new WP_Error( 'bad_creds', 'JSON de credenciales no válido.' );
    }

    $now     = time();
    $header  = mwi_base64url( json_encode( [ 'alg' => 'RS256', 'typ' => 'JWT' ] ) );
    $payload = mwi_base64url( json_encode( [
        'iss'   => $creds['client_email'],
        'scope' => 'https://www.googleapis.com/auth/webmasters.readonly',
        'aud'   => 'https://oauth2.googleapis.com/token',
        'iat'   => $now,
        'exp'   => $now + 3600,
    ] ) );

    $signing_input = $header . '.' . $payload;
    $pk = openssl_pkey_get_private( $creds['private_key'] );
    if ( ! $pk ) return new WP_Error( 'bad_key', 'No se pudo leer la clave privada.' );

    $sig = '';
    if ( ! openssl_sign( $signing_input, $sig, $pk, 'SHA256' ) ) {
        return new WP_Error( 'sign_fail', 'Error al firmar el JWT.' );
    }

    $jwt  = $signing_input . '.' . mwi_base64url( $sig );
    $resp = wp_remote_post( 'https://oauth2.googleapis.com/token', [
        'body'    => [
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion'  => $jwt,
        ],
        'timeout' => 15,
    ] );

    if ( is_wp_error( $resp ) ) return $resp;

    $body  = json_decode( wp_remote_retrieve_body( $resp ), true );
    $token = $body['access_token'] ?? '';
    if ( ! $token ) {
        $err = $body['error_description'] ?? $body['error'] ?? 'Respuesta vacía.';
        return new WP_Error( 'no_token', $err );
    }

    set_transient( MWI_TRANSIENT_TOKEN_SC, $token, 3500 );
    return $token;
}

// ── J-2. URL Inspection API (Search Console) ──────────────────────────────────
function mwi_inspect_url( $url, $token ) {
    $site_url = trailingslashit( get_option( 'siteurl' ) );
    $resp = wp_remote_post(
        'https://searchconsole.googleapis.com/v1/urlInspection/index:inspect',
        [
            'timeout' => 20,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
            ],
            'body' => json_encode( [
                'inspectionUrl' => $url,
                'siteUrl'       => $site_url,
            ] ),
        ]
    );

    if ( is_wp_error( $resp ) ) {
        return [ 'error' => $resp->get_error_message() ];
    }

    $code     = wp_remote_retrieve_response_code( $resp );
    $raw_body = json_decode( wp_remote_retrieve_body( $resp ), true );

    if ( $code !== 200 ) {
        $msg = $raw_body['error']['message'] ?? ( 'HTTP ' . $code );
        return [ 'error' => $msg ];
    }

    $index    = $raw_body['inspectionResult']['indexStatusResult'] ?? [];
    $verdict  = $index['indexingState'] ?? 'UNKNOWN';
    $coverage = $index['coverageState'] ?? '';
    $last_crawl       = $index['lastCrawlTime'] ?? null;
    $google_canonical = $index['googleCanonical'] ?? null;

    $indexed = in_array( $coverage, [
        'Submitted and indexed',
        'Indexed, not submitted in sitemap',
        'Indexed, though blocked by robots.txt',
    ], true );

    return compact( 'indexed', 'verdict', 'coverage', 'last_crawl', 'google_canonical' );
}

// ── J-3. AJAX handler — Verificar estado en Search Console ───────────────────
function mwi_ajax_check_google_status() {
    check_ajax_referer( 'mwi_ajax', 'nonce' );
    if ( ! current_user_can( 'manage_options' ) ) wp_die( -1 );

    $url = sanitize_url( wp_unslash( $_POST['url'] ?? '' ) );
    if ( ! $url ) wp_send_json_error( 'URL requerida.' );

    $token = mwi_get_google_token_sc();
    if ( is_wp_error( $token ) ) {
        wp_send_json_error( 'Token SC: ' . $token->get_error_message() );
    }

    $result = mwi_inspect_url( $url, $token );

    if ( isset( $result['error'] ) ) {
        wp_send_json_error( $result['error'] );
    }

    wp_send_json_success( $result );
}

// ── J. Llamada a IndexNow ─────────────────────────────────────────────────────
function mwi_call_indexnow( array $urls ) {
    $key  = get_option( MWI_OPTION_IN_KEY, '' );
    $host = wp_parse_url( home_url(), PHP_URL_HOST );

    $resp = wp_remote_post( 'https://api.indexnow.org/indexnow', [
        'headers' => [ 'Content-Type' => 'application/json; charset=utf-8' ],
        'body'    => json_encode( [
            'host'        => $host,
            'key'         => $key,
            'keyLocation' => home_url( '/' . $key . '.txt' ),
            'urlList'     => array_values( $urls ),
        ] ),
        'timeout' => 20,
    ] );

    return is_wp_error( $resp ) ? 0 : wp_remote_retrieve_response_code( $resp );
}

// ── K. Colector de URLs ───────────────────────────────────────────────────────
function mwi_collect_all_urls() {
    $entries = [];

    // Homepage
    $entries[] = [ 'url' => home_url( '/' ), 'type' => 'home' ];

    // Posts y páginas
    foreach ( [ 'post', 'page' ] as $pt ) {
        $ids = get_posts( [
            'post_type'      => $pt,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ] );
        foreach ( $ids as $id ) {
            $link = get_permalink( $id );
            if ( $link ) $entries[] = [ 'url' => $link, 'type' => $pt ];
        }
    }

    // CPT convocatoria
    $ids = get_posts( [
        'post_type'      => 'convocatoria',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'fields'         => 'ids',
    ] );
    foreach ( $ids as $id ) {
        $link = get_permalink( $id );
        if ( $link ) $entries[] = [ 'url' => $link, 'type' => 'convocatoria' ];
    }

    // Archivo CPT
    $arch = get_post_type_archive_link( 'convocatoria' );
    if ( $arch ) $entries[] = [ 'url' => $arch, 'type' => 'archive_convocatoria' ];

    // Taxonomías
    $taxonomies = [ 'tipo_ayuda', 'comunidad_autonoma', 'beneficiario', 'category', 'post_tag' ];
    foreach ( $taxonomies as $tax ) {
        $terms = get_terms( [ 'taxonomy' => $tax, 'hide_empty' => true ] );
        if ( is_wp_error( $terms ) ) continue;
        foreach ( $terms as $term ) {
            $link = get_term_link( $term );
            if ( ! is_wp_error( $link ) ) {
                $entries[] = [ 'url' => $link, 'type' => $tax ];
            }
        }
    }

    // Deduplicar
    $seen = [];
    $out  = [];
    foreach ( $entries as $e ) {
        if ( ! isset( $seen[ $e['url'] ] ) ) {
            $seen[ $e['url'] ] = true;
            $out[] = $e;
        }
    }

    return $out;
}

// ── L. Log ───────────────────────────────────────────────────────────────────
function mwi_get_log() {
    $raw = get_option( MWI_OPTION_LOG, '[]' );
    $log = json_decode( $raw, true );
    return is_array( $log ) ? $log : [];
}

function mwi_log_submission( array $urls, array $responses, string $api ) {
    $log = mwi_get_log();

    $success = 0;
    $failed  = 0;
    foreach ( $responses as $data ) {
        $code = $data['http_code'] ?? 0;
        if ( $code >= 200 && $code < 300 ) $success++;
        else $failed++;
    }

    array_unshift( $log, [
        'id'        => substr( uniqid(), -8 ),
        'timestamp' => time(),
        'api'       => $api,
        'urls'      => array_values( $urls ),
        'responses' => $responses,
        'total'     => count( $urls ),
        'success'   => $success,
        'failed'    => $failed,
    ] );

    $log = array_slice( $log, 0, MWI_LOG_MAX );
    update_option( MWI_OPTION_LOG, json_encode( $log ), false );
}

// ── Helpers del contador diario ───────────────────────────────────────────────
function mwi_get_daily_count() {
    $raw  = get_option( MWI_OPTION_DAILY, '{}' );
    $data = json_decode( $raw, true );
    $today = date( 'Y-m-d' );
    if ( ! is_array( $data ) || ( $data['date'] ?? '' ) !== $today ) return 0;
    return intval( $data['count'] ?? 0 );
}

function mwi_increment_daily( int $n ) {
    $today = date( 'Y-m-d' );
    $raw   = get_option( MWI_OPTION_DAILY, '{}' );
    $data  = json_decode( $raw, true );
    if ( ! is_array( $data ) || ( $data['date'] ?? '' ) !== $today ) {
        $data = [ 'date' => $today, 'count' => 0 ];
    }
    $data['count'] += $n;
    update_option( MWI_OPTION_DAILY, json_encode( $data ), false );
}

// ── Helpers de presentación ───────────────────────────────────────────────────
function mwi_type_label( string $type ): string {
    $map = [
        'home'                   => 'Inicio',
        'post'                   => 'Entrada',
        'page'                   => 'Página',
        'convocatoria'           => 'Convocatoria',
        'archive_convocatoria'   => 'Archivo CPT',
        'tipo_ayuda'             => 'Tipo de Ayuda',
        'comunidad_autonoma'     => 'Comunidad Autónoma',
        'beneficiario'           => 'Beneficiario',
        'category'               => 'Categoría',
        'post_tag'               => 'Etiqueta',
    ];
    return $map[ $type ] ?? ucfirst( $type );
}

function mwi_status_class( string $status ): string {
    if ( in_array( $status, [ 'URL_UPDATED', 'SUBMITTED', 'ACCEPTED', 'URL_DELETED' ], true )
         || str_contains( $status, 'INDEXED' ) ) {
        return 'background:#d4edda;color:#155724';
    }
    if ( str_contains( $status, 'ERROR' ) || str_contains( $status, 'FAIL' ) ) {
        return 'background:#f8d7da;color:#721c24';
    }
    if ( $status === 'PENDING' ) {
        return 'background:#e2e3e5;color:#383d41';
    }
    return 'background:#fff3cd;color:#856404';
}

// ── Inline JavaScript (cargado solo en la página de admin) ────────────────────
function mwi_print_admin_js() {
    $screen = get_current_screen();
    if ( ! $screen || $screen->id !== 'tools_page_mw-indexacion-masiva' ) return;
    ?>
    <script>
    (function(){
        // ── Seleccionar / deseleccionar todo ──────────────────────────────
        const checkAll   = document.getElementById('mwi-check-all');
        const selAll     = document.getElementById('mwi-select-all');
        const deselAll   = document.getElementById('mwi-deselect-all');

        function setAll(val) {
            document.querySelectorAll('.mwi-url-cb').forEach(cb => cb.checked = val);
            if (checkAll) checkAll.checked = val;
        }
        if (checkAll)  checkAll.addEventListener('change', () => setAll(checkAll.checked));
        if (selAll)    selAll.addEventListener('click',   () => setAll(true));
        if (deselAll)  deselAll.addEventListener('click', () => setAll(false));

        // ── Helpers UI ────────────────────────────────────────────────────
        function getSelectedUrls() {
            return [...document.querySelectorAll('.mwi-url-cb:checked')].map(cb => cb.value);
        }

        function showProgress(done, total) {
            const wrap  = document.getElementById('mwi-progress-wrap');
            const bar   = document.getElementById('mwi-progress-bar');
            const label = document.getElementById('mwi-progress-label');
            if (!wrap) return;
            wrap.style.display = '';
            const pct = total > 0 ? Math.round(done / total * 100) : 0;
            bar.style.width  = pct + '%';
            label.textContent = done + ' / ' + total + ' URLs procesadas (' + pct + '%)';
        }

        function showResult(ok, fail) {
            const box = document.getElementById('mwi-result-box');
            if (!box) return;
            box.style.display = '';
            const cls = fail > 0 ? 'notice-warning' : 'notice-success';
            box.innerHTML = '<div class="notice ' + cls + ' inline" style="margin:0"><p>' +
                '✅ <strong>' + ok   + '</strong> enviadas correctamente &nbsp;·&nbsp; ' +
                '❌ <strong>' + fail + '</strong> con error' +
                '</p></div>';
        }

        // ── Envío por lotes vía AJAX ──────────────────────────────────────
        async function submitBatch(action, urls) {
            if (!urls.length) { alert('Selecciona al menos una URL.'); return; }

            const data = typeof mwiData !== 'undefined' ? mwiData : {};
            const batchSize = 10;
            let done = 0, ok = 0, fail = 0;

            showProgress(0, urls.length);
            document.getElementById('mwi-result-box').style.display = 'none';

            // IndexNow: todo en una sola llamada
            if (action === 'mwi_index_indexnow') {
                const body = new URLSearchParams({
                    action: action,
                    nonce:  data.nonce,
                });
                urls.forEach(u => body.append('urls[]', u));
                const resp = await fetch(data.ajaxurl, { method:'POST', body });
                const json = await resp.json();
                showProgress(urls.length, urls.length);
                showResult(json.success ? urls.length : 0, json.success ? 0 : urls.length);
                return;
            }

            // Google: lotes de 10
            for (let i = 0; i < urls.length; i += batchSize) {
                const batch = urls.slice(i, i + batchSize);
                const body  = new URLSearchParams({ action, nonce: data.nonce });
                batch.forEach(u => body.append('urls[]', u));

                try {
                    const resp = await fetch(data.ajaxurl, { method:'POST', body });
                    const json = await resp.json();
                    if (json.success && json.data) {
                        Object.values(json.data).forEach(r => {
                            (r.http_code >= 200 && r.http_code < 300) ? ok++ : fail++;
                        });
                    } else {
                        fail += batch.length;
                    }
                } catch(e) {
                    fail += batch.length;
                }

                done += batch.length;
                showProgress(done, urls.length);
            }

            showResult(ok, fail);
        }

        // ── Botones de envío ──────────────────────────────────────────────
        const btnGoogle   = document.getElementById('mwi-submit-google');
        const btnIndexNow = document.getElementById('mwi-submit-indexnow');

        if (btnGoogle) {
            btnGoogle.addEventListener('click', function() {
                const urls = getSelectedUrls();
                const data = typeof mwiData !== 'undefined' ? mwiData : {};
                if (urls.length > data.daily_remaining) {
                    if (!confirm('Tienes ' + data.daily_remaining + ' URLs disponibles hoy. Se enviarán las primeras ' + data.daily_remaining + '. ¿Continuar?')) return;
                }
                submitBatch('mwi_index_google', urls);
            });
        }

        if (btnIndexNow) {
            btnIndexNow.addEventListener('click', function() {
                submitBatch('mwi_index_indexnow', getSelectedUrls());
            });
        }

        // ── Botón Verificar estado en Search Console ──────────────────────
        document.querySelectorAll('.mwi-verify-btn').forEach(function(btn) {
            btn.addEventListener('click', function() {
                const url    = btn.dataset.url;
                const result = btn.nextElementSibling;
                const data   = typeof mwiData !== 'undefined' ? mwiData : {};

                btn.disabled = true;
                btn.textContent = '⏳';
                result.style.display = '';
                result.innerHTML = '<span style="color:#555">Consultando Search Console...</span>';

                fetch(data.ajaxurl, {
                    method: 'POST',
                    body: new URLSearchParams({ action: 'mwi_check_google_status', nonce: data.nonce, url: url })
                })
                .then(function(r) { return r.json(); })
                .then(function(json) {
                    btn.disabled = false;
                    btn.textContent = '🔍 Verificar';
                    if (!json.success) {
                        result.innerHTML = '<span style="color:#c00">❌ ' + json.data + '</span>';
                        return;
                    }
                    const d = json.data;
                    const color = d.indexed ? '#155724' : '#856404';
                    const bg    = d.indexed ? '#d4edda'  : '#fff3cd';
                    let text = d.coverage || d.verdict;
                    if (d.last_crawl) text += '<br>🕐 ' + d.last_crawl.substring(0, 10);
                    if (d.google_canonical && d.google_canonical !== url) {
                        text += '<br>⚠️ Canonical diferente';
                    }
                    result.innerHTML = '<span style="display:inline-block;padding:3px 6px;border-radius:3px;background:' + bg + ';color:' + color + ';font-size:11px">' + text + '</span>';

                    // Actualizar badge de estado en la misma celda
                    const badge = btn.previousElementSibling;
                    if (badge && badge.classList.contains('mwi-status-badge')) {
                        badge.textContent = d.indexed ? 'Indexada ✓' : (d.coverage || d.verdict);
                        badge.style.cssText = 'font-size:11px;padding:2px 6px;border-radius:3px;background:' + bg + ';color:' + color;
                    }
                })
                .catch(function(e) {
                    btn.disabled = false;
                    btn.textContent = '🔍 Verificar';
                    result.innerHTML = '<span style="color:#c00">❌ Error de red</span>';
                });
            });
        });

        // ── Verificar token Google ────────────────────────────────────────
        const btnTest  = document.getElementById('mwi-test-token');
        const resLabel = document.getElementById('mwi-token-result');
        if (btnTest && resLabel) {
            btnTest.addEventListener('click', function() {
                resLabel.textContent = '⏳ Verificando...';
                resLabel.style.color = '#555';
                fetch(mwiData.ajaxurl, {
                    method: 'POST',
                    body: new URLSearchParams({ action: 'mwi_test_token', nonce: mwiData.nonce })
                })
                .then(r => r.text())
                .then(text => {
                    let json;
                    try { json = JSON.parse(text); } catch(e) {
                        resLabel.textContent = '❌ Respuesta inesperada: ' + text.substring(0, 100);
                        resLabel.style.color = 'red';
                        return;
                    }
                    if (json.success) {
                        resLabel.textContent = '✅ ' + json.data;
                        resLabel.style.color = 'green';
                    } else {
                        resLabel.textContent = '❌ ' + (json.data || 'Error desconocido');
                        resLabel.style.color = 'red';
                    }
                })
                .catch(err => {
                    resLabel.textContent = '❌ Error de red: ' + err.message;
                    resLabel.style.color = 'red';
                });
            });
        }
    })();
    </script>
    <?php
}
