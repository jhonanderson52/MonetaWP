<?php
/**
 * Cookie Consent Banner — RGPD/LOPD compliant.
 * Configurable 100% desde Apariencia → Personalizar → Aviso de Cookies.
 */

defined( 'ABSPATH' ) || exit;

// Mostrar banner en footer (antes de wp_footer)
add_action( 'wp_footer', 'mw_cookie_banner', 5 );
function mw_cookie_banner() {
    if ( ! get_theme_mod( 'mw_cookie_enable', '1' ) ) return;

    $text        = get_theme_mod( 'mw_cookie_text',        'Utilizamos cookies propias y de terceros para mejorar tu experiencia y mostrarte publicidad personalizada. Al continuar navegando aceptas nuestra' );
    $accept_text = get_theme_mod( 'mw_cookie_accept_text', 'Aceptar todas' );
    $reject_text = get_theme_mod( 'mw_cookie_reject_text', 'Solo necesarias' );
    $policy_text = get_theme_mod( 'mw_cookie_policy_text', 'Política de Cookies' );
    $policy_url  = get_theme_mod( 'mw_cookie_policy_url',  '/politica-de-cookies/' );
    $position    = get_theme_mod( 'mw_cookie_position',    'bottom' );
    $bg_color    = get_theme_mod( 'mw_cookie_bg_color',    '#1A2B4A' );
    $btn_color   = get_theme_mod( 'mw_cookie_btn_color',   '#CC0000' );
    ?>
    <div id="ae-cookie-banner"
         class="cookie-banner cookie-banner--<?php echo esc_attr( $position ); ?>"
         role="dialog"
         aria-live="polite"
         aria-label="<?php _e( 'Aviso de cookies', 'monetawp' ); ?>"
         style="background:<?php echo esc_attr( $bg_color ); ?>;"
         hidden>

        <div class="cookie-banner__inner">
            <div class="cookie-banner__text">
                <span class="cookie-banner__icon" aria-hidden="true">🍪</span>
                <p>
                    <?php echo esc_html( $text ); ?>
                    <?php if ( $policy_url && $policy_text ) : ?>
                        <a href="<?php echo esc_url( home_url( $policy_url ) ); ?>"><?php echo esc_html( $policy_text ); ?></a>.
                    <?php endif; ?>
                </p>
            </div>

            <div class="cookie-banner__actions">
                <button
                    id="ae-cookie-accept"
                    class="cookie-btn cookie-btn--accept"
                    style="background:<?php echo esc_attr( $btn_color ); ?>;">
                    <?php echo esc_html( $accept_text ); ?>
                </button>

                <?php if ( $reject_text ) : ?>
                    <button id="ae-cookie-reject" class="cookie-btn cookie-btn--reject">
                        <?php echo esc_html( $reject_text ); ?>
                    </button>
                <?php endif; ?>

                <button id="ae-cookie-close" class="cookie-btn cookie-btn--close" aria-label="<?php _e( 'Cerrar', 'monetawp' ); ?>">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true">
                        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <script>
    (function() {
        var banner   = document.getElementById('ae-cookie-banner');
        var COOKIE   = 'mw_cookie_consent';
        var DAYS     = 365;

        function getCookie(name) {
            var m = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
            return m ? m.pop() : '';
        }
        function setCookie(name, value, days) {
            var d = new Date();
            d.setTime(d.getTime() + days * 864e5);
            document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/;SameSite=Lax';
        }
        function hideBanner() {
            banner.setAttribute('hidden', '');
            banner.setAttribute('aria-hidden', 'true');
        }
        function accept(type) {
            setCookie(COOKIE, type, DAYS);
            hideBanner();
            // Disparar evento para cargar scripts de terceros (Analytics, etc.)
            document.dispatchEvent(new CustomEvent('mw_cookies_accepted', { detail: { type: type } }));
        }

        // Solo mostrar si no hay consentimiento previo
        if (!getCookie(COOKIE)) {
            banner.removeAttribute('hidden');
            banner.removeAttribute('aria-hidden');
        }

        var btnAccept = document.getElementById('ae-cookie-accept');
        var btnReject = document.getElementById('ae-cookie-reject');
        var btnClose  = document.getElementById('ae-cookie-close');

        if (btnAccept) btnAccept.addEventListener('click', function() { accept('all'); });
        if (btnReject) btnReject.addEventListener('click', function() { accept('necessary'); });
        if (btnClose)  btnClose.addEventListener('click',  function() { accept('necessary'); });
    })();
    </script>
    <?php
}

// CSS del banner (inline, no requiere archivo extra)
add_action( 'wp_head', 'mw_cookie_css', 99 );
function mw_cookie_css() {
    if ( ! get_theme_mod( 'mw_cookie_enable', '1' ) ) return;
    ?>
    <style id="ae-cookie-styles">
    .cookie-banner {
        position: fixed;
        left: 0; right: 0;
        z-index: 9999;
        padding: 1rem;
        color: #fff;
        box-shadow: 0 -4px 20px rgba(0,0,0,.25);
        transition: transform .3s ease;
    }
    .cookie-banner--bottom { bottom: 0; }
    .cookie-banner--top    { top: 0; box-shadow: 0 4px 20px rgba(0,0,0,.25); }
    .cookie-banner[hidden] { display: none !important; }

    .cookie-banner__inner {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: .75rem;
    }
    .cookie-banner__text {
        flex: 1;
        min-width: 200px;
        display: flex;
        align-items: flex-start;
        gap: .5rem;
        font-size: .9rem;
        line-height: 1.5;
    }
    .cookie-banner__text p { margin: 0; }
    .cookie-banner__text a { color: #F5A623; text-decoration: underline; }
    .cookie-banner__icon   { font-size: 1.4rem; flex-shrink: 0; margin-top: .1rem; }
    .cookie-banner__actions {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: .5rem;
        flex-shrink: 0;
    }
    .cookie-btn {
        border: none;
        border-radius: 6px;
        padding: .55rem 1.1rem;
        font-size: .875rem;
        font-weight: 700;
        cursor: pointer;
        min-height: 40px;
        transition: opacity .15s;
        font-family: inherit;
    }
    .cookie-btn:hover { opacity: .85; }
    .cookie-btn--accept { color: #fff; }
    .cookie-btn--reject {
        background: transparent;
        border: 1px solid rgba(255,255,255,.4);
        color: rgba(255,255,255,.85);
    }
    .cookie-btn--close {
        background: transparent;
        border: 1px solid rgba(255,255,255,.3);
        color: rgba(255,255,255,.7);
        padding: .4rem .6rem;
        min-height: 36px;
        display: flex;
        align-items: center;
    }
    @media (max-width: 599px) {
        .cookie-banner__inner { flex-direction: column; align-items: stretch; }
        .cookie-banner__actions { justify-content: stretch; }
        .cookie-btn--accept, .cookie-btn--reject { flex: 1; text-align: center; }
    }
    </style>
    <?php
}
