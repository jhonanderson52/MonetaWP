<?php
/**
 * Schema JSON-LD — Article, GovernmentService, BreadcrumbList, WebSite.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'wp_head', 'mw_output_schema', 3 );
function mw_output_schema() {
    if ( class_exists( 'RankMath' ) || defined( 'RANK_MATH_FILE' ) ) { return; }
    $schemas = [];

    // WebSite (siempre)
    $schemas[] = [
        '@context' => 'https://schema.org',
        '@type'    => 'WebSite',
        'name'     => get_bloginfo( 'name' ),
        'url'      => home_url( '/' ),
        'potentialAction' => [
            '@type'       => 'SearchAction',
            'target'      => [ '@type' => 'EntryPoint', 'urlTemplate' => home_url( '/?s={search_term_string}' ) ],
            'query-input' => 'required name=search_term_string',
        ],
    ];

    // Organization
    $schemas[] = [
        '@context' => 'https://schema.org',
        '@type'    => 'Organization',
        'name'     => get_bloginfo( 'name' ),
        'url'      => home_url( '/' ),
        'logo'     => [ '@type' => 'ImageObject', 'url' => MW_ASSETS . '/img/logo.svg' ],
    ];

    if ( is_singular( 'post' ) ) {
        // Article schema
        $schemas[] = mw_article_schema();
    } elseif ( is_singular( 'convocatoria' ) ) {
        // GovernmentService + Event schema
        $schemas[] = mw_convocatoria_schema();
    } elseif ( is_tax() || is_category() || is_archive() ) {
        // CollectionPage + ItemList para páginas de categoría/taxonomía/archivo
        $schemas[] = mw_archive_schema();
    }

    // BreadcrumbList (en cualquier página interna)
    if ( ! is_front_page() ) {
        $breadcrumb = mw_breadcrumb_schema();
        if ( $breadcrumb ) {
            $schemas[] = $breadcrumb;
        }
    }

    foreach ( $schemas as $schema ) {
        echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) . '</script>' . "\n";
    }
}

function mw_article_schema() {
    $image_url = get_the_post_thumbnail_url( null, 'ae-hero' ) ?: MW_ASSETS . '/img/og-default.jpg';
    return [
        '@context'         => 'https://schema.org',
        '@type'            => 'Article',
        'headline'         => get_the_title(),
        'description'      => wp_strip_all_tags( get_the_excerpt() ),
        'datePublished'    => get_the_date( 'c' ),
        'dateModified'     => get_the_modified_date( 'c' ),
        'author'           => [ '@type' => 'Person', 'name' => get_the_author() ],
        'publisher'        => [
            '@type' => 'Organization',
            'name'  => get_bloginfo( 'name' ),
            'logo'  => [ '@type' => 'ImageObject', 'url' => MW_ASSETS . '/img/logo.svg' ],
        ],
        'image'            => [ '@type' => 'ImageObject', 'url' => $image_url ],
        'mainEntityOfPage' => [ '@type' => 'WebPage', '@id' => get_permalink() ],
        'url'              => get_permalink(),
        'inLanguage'       => 'es-ES',
    ];
}

function mw_convocatoria_schema() {
    $post_id   = get_the_ID();
    $deadline  = get_post_meta( $post_id, '_convocatoria_deadline',  true );
    $amount    = get_post_meta( $post_id, '_convocatoria_amount',    true );
    $organismo = get_post_meta( $post_id, '_convocatoria_organismo', true );
    $url_boe   = get_post_meta( $post_id, '_convocatoria_url_boe',   true );
    $estado    = get_post_meta( $post_id, '_convocatoria_estado',    true );
    $image_url = get_the_post_thumbnail_url( null, 'ae-hero' ) ?: MW_ASSETS . '/img/og-default.jpg';

    $schema = [
        '@context'    => 'https://schema.org',
        '@type'       => 'GovernmentService',
        'name'        => get_the_title(),
        'description' => wp_strip_all_tags( get_the_excerpt() ),
        'url'         => get_permalink(),
        'image'       => $image_url,
        'inLanguage'  => 'es-ES',
        'serviceType' => 'Ayuda gubernamental',
        'areaServed'  => [ '@type' => 'Country', 'name' => 'Spain' ],
    ];

    if ( $organismo ) {
        $schema['provider'] = [ '@type' => 'GovernmentOrganization', 'name' => $organismo ];
    }

    if ( $url_boe ) {
        $schema['termsOfService'] = $url_boe;
    }

    // Añadir Event para la convocatoria si tiene fecha límite
    if ( $deadline ) {
        $schema['@type'] = [ 'GovernmentService', 'Event' ];
        $schema['endDate'] = $deadline;
        $schema['eventStatus'] = ( $estado === 'cerrada' )
            ? 'https://schema.org/EventCancelled'
            : 'https://schema.org/EventScheduled';
        $schema['eventAttendanceMode'] = 'https://schema.org/OnlineEventAttendanceMode';
        $schema['location'] = [ '@type' => 'VirtualLocation', 'url' => get_permalink() ];
        $schema['organizer'] = [ '@type' => 'GovernmentOrganization', 'name' => $organismo ?: get_bloginfo( 'name' ) ];
    }

    return $schema;
}

function mw_archive_schema() {
    $term = get_queried_object();
    if ( ! $term || ! isset( $term->term_id ) ) {
        return [ '@context' => 'https://schema.org', '@type' => 'CollectionPage', 'name' => get_the_archive_title(), 'url' => get_pagenum_link() ];
    }
    $heading = mw_archive_get_heading( $term );
    $h1      = $heading['h1'];
    $desc    = $heading['desc'] ?: sprintf( __( 'Todas las ayudas y subvenciones relacionadas con %s en España.', 'monetawp' ), $term->name );
    $url     = is_category() ? get_category_link( $term->term_id ) : get_term_link( $term );

    // ItemList con los posts de la página actual
    $list_items = [];
    $position   = 1;
    $posts      = get_posts( [
        'post_type'      => [ 'post', 'convocatoria' ],
        'posts_per_page' => absint( get_theme_mod( 'mw_archive_posts_per_page', 9 ) ),
        'no_found_rows'  => true,
        'tax_query'      => [ [
            'taxonomy' => $term->taxonomy,
            'field'    => 'term_id',
            'terms'    => $term->term_id,
        ] ],
    ] );
    foreach ( $posts as $p ) {
        $list_items[] = [
            '@type'    => 'ListItem',
            'position' => $position++,
            'url'      => get_permalink( $p->ID ),
            'name'     => get_the_title( $p->ID ),
        ];
    }

    return [
        '@context'    => 'https://schema.org',
        '@type'       => 'CollectionPage',
        'name'        => $h1,
        'description' => wp_strip_all_tags( $desc ),
        'url'         => is_wp_error( $url ) ? get_home_url() : $url,
        'inLanguage'  => 'es-ES',
        'about'       => [
            '@type' => 'Thing',
            'name'  => $term->name,
        ],
        'mainEntity' => [
            '@type'           => 'ItemList',
            'numberOfItems'   => count( $list_items ),
            'itemListElement' => $list_items,
        ],
    ];
}

function mw_breadcrumb_schema() {
    $items = [];
    $pos   = 1;

    // Home
    $items[] = [
        '@type'    => 'ListItem',
        'position' => $pos++,
        'name'     => __( 'Inicio', 'monetawp' ),
        'item'     => home_url( '/' ),
    ];

    if ( is_singular() ) {
        // Taxonomía principal
        $tax_terms = get_the_terms( get_the_ID(), 'tipo_ayuda' );
        if ( $tax_terms && ! is_wp_error( $tax_terms ) ) {
            $term = reset( $tax_terms );
            $items[] = [
                '@type'    => 'ListItem',
                'position' => $pos++,
                'name'     => $term->name,
                'item'     => get_term_link( $term ),
            ];
        }
        // Artículo actual
        $items[] = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'name'     => get_the_title(),
            'item'     => get_permalink(),
        ];
    } elseif ( is_tax() || is_category() ) {
        $term = get_queried_object();
        $items[] = [
            '@type'    => 'ListItem',
            'position' => $pos++,
            'name'     => $term->name,
            'item'     => get_term_link( $term ),
        ];
    }

    if ( count( $items ) < 2 ) return null;

    return [
        '@context'        => 'https://schema.org',
        '@type'           => 'BreadcrumbList',
        'itemListElement' => $items,
    ];
}

// ── Helper: Breadcrumbs HTML ─────────────────────────────────────────────────
function mw_breadcrumbs() {
    if ( is_front_page() ) return;
    ?>
    <nav class="breadcrumbs" aria-label="<?php _e( 'Ruta de navegación', 'monetawp' ); ?>">
        <ol class="breadcrumbs__list">
            <li class="breadcrumbs__item">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php _e( 'Inicio', 'monetawp' ); ?></a>
            </li>
            <?php if ( is_singular() ) :
                $tax_terms = get_the_terms( get_the_ID(), 'tipo_ayuda' );
                if ( $tax_terms && ! is_wp_error( $tax_terms ) ) :
                    $term = reset( $tax_terms );
                    ?>
                    <li class="breadcrumbs__item">
                        <a href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a>
                    </li>
                <?php endif; ?>
                <li class="breadcrumbs__item breadcrumbs__item--current" aria-current="page">
                    <?php echo esc_html( get_the_title() ); ?>
                </li>
            <?php elseif ( is_tax() || is_category() ) :
                $term = get_queried_object(); ?>
                <li class="breadcrumbs__item breadcrumbs__item--current" aria-current="page">
                    <?php echo esc_html( $term->name ); ?>
                </li>
            <?php elseif ( is_archive() ) : ?>
                <li class="breadcrumbs__item breadcrumbs__item--current" aria-current="page">
                    <?php the_archive_title(); ?>
                </li>
            <?php elseif ( is_search() ) : ?>
                <li class="breadcrumbs__item breadcrumbs__item--current" aria-current="page">
                    <?php printf( __( 'Búsqueda: %s', 'monetawp' ), get_search_query() ); ?>
                </li>
            <?php endif; ?>
        </ol>
    </nav>
    <?php
}
