<?php
/**
 * AdSense — 6 zonas como widget areas + inyección automática en contenido.
 */

defined( 'ABSPATH' ) || exit;

// ── Registrar 6 widget areas ─────────────────────────────────────────────────
add_action( 'widgets_init', 'mw_register_ad_zones' );
function mw_register_ad_zones() {
    $zones = [
        'adsense-header'     => __( 'AdSense: Cabecera (bajo nav)',              'monetawp' ),
        'adsense-between-2'  => __( 'AdSense: Entre secciones (tras destacadas)','monetawp' ),
        'adsense-between-3'  => __( 'AdSense: Entre secciones (tras segmentos)', 'monetawp' ),
        'adsense-in-content' => __( 'AdSense: Dentro del artículo (párrafo 3)',  'monetawp' ),
        'adsense-sidebar'    => __( 'AdSense: Sidebar (solo desktop)',           'monetawp' ),
        'adsense-footer'     => __( 'AdSense: Pie de página',                   'monetawp' ),
    ];

    foreach ( $zones as $id => $name ) {
        register_sidebar( [
            'id'            => $id,
            'name'          => $name,
            'before_widget' => '<div class="ad-container" aria-hidden="true">',
            'after_widget'  => '</div>',
            'before_title'  => '',
            'after_title'   => '',
        ] );
    }
}

// ── Helper: renderizar zona de anuncio ───────────────────────────────────────
function mw_ad_zone( $zone_id ) {
    if ( ! is_active_sidebar( $zone_id ) ) return;

    // No mostrar anuncios a admins logueados (para no afectar CTR)
    if ( current_user_can( 'manage_options' ) && ! apply_filters( 'mw_show_ads_to_admin', false ) ) {
        echo '<div class="ad-container ad-placeholder" aria-hidden="true" style="background:#f0f0f0;text-align:center;padding:8px;font-size:11px;color:#999;">Zona de anuncio: ' . esc_html( $zone_id ) . '</div>';
        return;
    }

    dynamic_sidebar( $zone_id );
}

// ── Inyección automática en contenido (párrafo 3) ───────────────────────────
add_filter( 'the_content', 'mw_inject_in_content_ad' );
function mw_inject_in_content_ad( $content ) {
    if ( ! is_singular() || ! is_active_sidebar( 'adsense-in-content' ) ) {
        return $content;
    }

    // Capturar el HTML del widget
    ob_start();
    mw_ad_zone( 'adsense-in-content' );
    $ad_html = ob_get_clean();

    if ( empty( $ad_html ) ) return $content;

    // Insertar tras el 3er párrafo </p>
    $paragraphs = explode( '</p>', $content );
    $count = count( $paragraphs );

    if ( $count > 4 ) {
        // Insertar después del párrafo 3
        $paragraphs[2] .= '</p>' . $ad_html;
        // Reconstruir sin el </p> extra que ya añadimos
        $result = '';
        foreach ( $paragraphs as $i => $p ) {
            if ( $i === 2 ) {
                $result .= $p; // ya tiene el </p>
            } else {
                $result .= $p . ( $i < $count - 1 ? '</p>' : '' );
            }
        }
        return $result;
    }

    return $content . $ad_html;
}

// ── Script de AdSense Auto Ads (si está activado) ───────────────────────────
add_action( 'wp_head', 'mw_adsense_script', 5 );
function mw_adsense_script() {
    $pub_id    = get_theme_mod( 'mw_adsense_pub_id', '' );
    $auto_ads  = get_theme_mod( 'mw_adsense_auto_ads', '0' );

    if ( empty( $pub_id ) || ! $auto_ads ) return;

    $pub_id = sanitize_text_field( $pub_id );
    // Solo el formato ca-pub-XXXXXXXXXX
    if ( ! preg_match( '/^ca-pub-\d{16}$/', $pub_id ) ) return;

    echo '<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . esc_attr( $pub_id ) . '" crossorigin="anonymous"></script>' . "\n";
    echo '<script>(adsbygoogle = window.adsbygoogle || []).push({google_ad_client: "' . esc_js( $pub_id ) . '", enable_page_level_ads: true});</script>' . "\n";
}
