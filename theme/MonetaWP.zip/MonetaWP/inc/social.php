<?php
/**
 * Social — OG meta tags, WhatsApp, share buttons, ManyChat, Facebook Pixel.
 */

defined( 'ABSPATH' ) || exit;

// ── Open Graph / Twitter Card meta tags ──────────────────────────────────────
add_action( 'wp_head', 'mw_social_meta_tags', 2 );
function mw_social_meta_tags() {
    global $post;

    $title       = is_singular() ? get_the_title() : get_bloginfo( 'name' );
    $description = is_singular()
        ? wp_strip_all_tags( get_the_excerpt() )
        : get_bloginfo( 'description' );
    $url         = is_singular() ? get_permalink() : home_url( '/' );
    $image       = '';

    if ( is_singular() && has_post_thumbnail() ) {
        $image = get_the_post_thumbnail_url( null, 'ae-hero' );
    }

    if ( empty( $image ) ) {
        $image = MW_ASSETS . '/img/og-default.jpg';
    }

    $description = mb_substr( $description, 0, 160 );
    ?>
    <!-- Open Graph -->
    <meta property="og:type"        content="<?php echo is_singular() ? 'article' : 'website'; ?>">
    <meta property="og:title"       content="<?php echo esc_attr( $title ); ?>">
    <meta property="og:description" content="<?php echo esc_attr( $description ); ?>">
    <meta property="og:url"         content="<?php echo esc_url( $url ); ?>">
    <meta property="og:image"       content="<?php echo esc_url( $image ); ?>">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height"content="630">
    <meta property="og:site_name"   content="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
    <meta property="og:locale"      content="es_ES">
    <!-- Twitter Card -->
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:title"       content="<?php echo esc_attr( $title ); ?>">
    <meta name="twitter:description" content="<?php echo esc_attr( $description ); ?>">
    <meta name="twitter:image"       content="<?php echo esc_url( $image ); ?>">
    <?php
}

// ── ManyChat widget (async) ───────────────────────────────────────────────────
add_action( 'wp_footer', 'mw_manychat_widget', 99 );
function mw_manychat_widget() {
    $page_id = get_theme_mod( 'mw_manychat_id', '' );
    if ( empty( $page_id ) ) return;
    $page_id = sanitize_text_field( $page_id );
    ?>
    <script>
    (function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
    n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
    document,'script','https://connect.facebook.net/en_US/fbevents.js'));
    </script>
    <div id="fb-root"></div>
    <script async defer src="https://connect.facebook.net/es_ES/sdk.js#xfbml=1&version=v19.0" crossorigin="anonymous"></script>
    <script async src="https://widget.manychat.com/<?php echo esc_attr( $page_id ); ?>.js"></script>
    <?php
}

// ── Helper: botón WhatsApp ────────────────────────────────────────────────────
function mw_whatsapp_url( $ref = '' ) {
    $number  = get_theme_mod( 'mw_whatsapp_number', '' );
    $message = get_theme_mod( 'mw_whatsapp_message', 'Hola, quiero información sobre ayudas' );
    if ( $ref ) {
        $message .= ' (' . $ref . ')';
    }
    return 'https://wa.me/' . rawurlencode( $number ) . '?text=' . rawurlencode( $message );
}

// ── Helper: share row ─────────────────────────────────────────────────────────
function mw_share_buttons() {
    $url   = urlencode( get_permalink() );
    $title = urlencode( get_the_title() );
    ?>
    <div class="share-row">
        <span class="share-row__label"><?php _e( 'Compartir:', 'monetawp' ); ?></span>
        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $url; ?>"
           target="_blank" rel="noopener" class="share-btn share-btn--facebook" aria-label="<?php _e( 'Compartir en Facebook', 'monetawp' ); ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
            Facebook
        </a>
        <a href="https://wa.me/?text=<?php echo $title . '%20' . $url; ?>"
           target="_blank" rel="noopener" class="share-btn share-btn--whatsapp" aria-label="<?php _e( 'Compartir por WhatsApp', 'monetawp' ); ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            WhatsApp
        </a>
        <button class="share-btn share-btn--native" data-url="<?php echo esc_attr( get_permalink() ); ?>" data-title="<?php echo esc_attr( get_the_title() ); ?>" aria-label="<?php _e( 'Más opciones para compartir', 'monetawp' ); ?>">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
            Más
        </button>
    </div>
    <?php
}
