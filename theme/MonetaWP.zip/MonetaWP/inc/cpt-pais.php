<?php
/**
 * CPT: País — Registra los países del hub global.
 */

defined( 'ABSPATH' ) || exit;

// ── Helper: emoji de bandera desde código ISO ────────────────────────────────
function mw_pais_flag_emoji( $codigo ) {
    $map = [
        'ES' => '🇪🇸', 'CA' => '🇨🇦', 'US' => '🇺🇸', 'EC' => '🇪🇨',
        'MX' => '🇲🇽', 'AR' => '🇦🇷', 'CO' => '🇨🇴', 'CL' => '🇨🇱',
        'PE' => '🇵🇪', 'VE' => '🇻🇪', 'BR' => '🇧🇷', 'UY' => '🇺🇾',
        'BO' => '🇧🇴', 'PY' => '🇵🇾', 'CR' => '🇨🇷', 'PA' => '🇵🇦',
        'GT' => '🇬🇹', 'HN' => '🇭🇳', 'SV' => '🇸🇻', 'NI' => '🇳🇮',
        'DO' => '🇩🇴', 'CU' => '🇨🇺', 'FR' => '🇫🇷', 'DE' => '🇩🇪',
        'IT' => '🇮🇹', 'PT' => '🇵🇹', 'GB' => '🇬🇧',
    ];
    return $map[ strtoupper( trim( $codigo ) ) ] ?? '';
}

// ── Registro del CPT ─────────────────────────────────────────────────────────
add_action( 'init', 'mw_register_cpt_pais' );
function mw_register_cpt_pais() {
    register_post_type( 'pais', [
        'labels' => [
            'name'               => __( 'Países',         'monetawp' ),
            'singular_name'      => __( 'País',           'monetawp' ),
            'add_new_item'       => __( 'Añadir País',    'monetawp' ),
            'edit_item'          => __( 'Editar País',    'monetawp' ),
            'new_item'           => __( 'Nuevo País',     'monetawp' ),
            'view_item'          => __( 'Ver País',       'monetawp' ),
            'search_items'       => __( 'Buscar Países',  'monetawp' ),
            'not_found'          => __( 'No se encontraron países.', 'monetawp' ),
        ],
        'public'            => true,
        'has_archive'       => false,
        'menu_icon'         => 'dashicons-location-alt',
        'menu_position'     => 6,
        'show_in_rest'      => true,
        'supports'          => [ 'title', 'excerpt', 'thumbnail' ],
        'rewrite'           => [ 'slug' => 'paises', 'with_front' => false ],
        'capability_type'   => 'post',
    ] );
}

// ── Meta box ─────────────────────────────────────────────────────────────────
add_action( 'add_meta_boxes', 'mw_pais_add_meta_box' );
function mw_pais_add_meta_box() {
    add_meta_box(
        'mw_pais_meta',
        __( 'Datos del País', 'monetawp' ),
        'mw_pais_render_meta_box',
        'pais',
        'normal',
        'high'
    );
}

function mw_pais_render_meta_box( $post ) {
    wp_nonce_field( 'mw_pais_save', 'mw_pais_nonce' );

    $emoji   = get_post_meta( $post->ID, '_pais_emoji',    true );
    $codigo  = get_post_meta( $post->ID, '_pais_codigo',   true );
    $url     = get_post_meta( $post->ID, '_pais_url_blog', true );
    $orden   = get_post_meta( $post->ID, '_pais_orden',    true );
    ?>
    <table class="form-table">
        <tr>
            <th><label for="pais_emoji"><?php _e( 'Emoji / Bandera', 'monetawp' ); ?></label></th>
            <td>
                <input type="text" id="pais_emoji" name="pais_emoji"
                       value="<?php echo esc_attr( $emoji ); ?>" placeholder="🇪🇸" style="width:80px;font-size:24px;" />
            </td>
        </tr>
        <tr>
            <th><label for="pais_codigo"><?php _e( 'Código ISO', 'monetawp' ); ?></label></th>
            <td>
                <input type="text" id="pais_codigo" name="pais_codigo"
                       value="<?php echo esc_attr( $codigo ); ?>" placeholder="es" style="width:80px;" />
                <p class="description"><?php _e( 'Ej: es, mx, ca, us, ec', 'monetawp' ); ?></p>
            </td>
        </tr>
        <tr>
            <th><label for="pais_url_blog"><?php _e( 'URL del Blog', 'monetawp' ); ?></label></th>
            <td>
                <input type="url" id="pais_url_blog" name="pais_url_blog"
                       value="<?php echo esc_attr( $url ); ?>"
                       placeholder="https://espana.convocatoriasybecas.online"
                       style="width:100%;max-width:420px;" />
                <p class="description"><?php _e( 'URL completa del blog de este país.', 'monetawp' ); ?></p>
            </td>
        </tr>
        <tr>
            <th><label for="pais_orden"><?php _e( 'Orden en el grid', 'monetawp' ); ?></label></th>
            <td>
                <input type="number" id="pais_orden" name="pais_orden"
                       value="<?php echo esc_attr( $orden ?: 0 ); ?>" min="0" max="99" style="width:80px;" />
                <p class="description"><?php _e( 'Número menor = aparece primero.', 'monetawp' ); ?></p>
            </td>
        </tr>
    </table>
    <?php
}

// ── Guardar meta ──────────────────────────────────────────────────────────────
add_action( 'save_post_pais', 'mw_pais_save_meta' );
function mw_pais_save_meta( $post_id ) {
    if ( ! isset( $_POST['mw_pais_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['mw_pais_nonce'], 'mw_pais_save' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    update_post_meta( $post_id, '_pais_emoji',    sanitize_text_field( $_POST['pais_emoji']    ?? '' ) );
    update_post_meta( $post_id, '_pais_codigo',   sanitize_text_field( $_POST['pais_codigo']   ?? '' ) );
    update_post_meta( $post_id, '_pais_url_blog', esc_url_raw(         $_POST['pais_url_blog'] ?? '' ) );
    update_post_meta( $post_id, '_pais_orden',    absint(              $_POST['pais_orden']    ?? 0  ) );
}

// ── Columnas en el listado del admin ─────────────────────────────────────────
add_filter( 'manage_pais_posts_columns', 'mw_pais_columns' );
function mw_pais_columns( $cols ) {
    return [
        'cb'             => $cols['cb'],
        'title'          => __( 'País', 'monetawp' ),
        'pais_emoji'     => __( 'Bandera', 'monetawp' ),
        'pais_codigo'    => __( 'Código', 'monetawp' ),
        'pais_url_blog'  => __( 'Blog', 'monetawp' ),
        'pais_orden'     => __( 'Orden', 'monetawp' ),
        'date'           => $cols['date'],
    ];
}

add_action( 'manage_pais_posts_custom_column', 'mw_pais_column_content', 10, 2 );
function mw_pais_column_content( $col, $post_id ) {
    switch ( $col ) {
        case 'pais_emoji':
            echo esc_html( get_post_meta( $post_id, '_pais_emoji', true ) );
            break;
        case 'pais_codigo':
            echo '<code>' . esc_html( get_post_meta( $post_id, '_pais_codigo', true ) ) . '</code>';
            break;
        case 'pais_url_blog':
            $url = get_post_meta( $post_id, '_pais_url_blog', true );
            if ( $url ) {
                echo '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $url ) . '</a>';
            }
            break;
        case 'pais_orden':
            echo esc_html( get_post_meta( $post_id, '_pais_orden', true ) );
            break;
    }
}
