<?php get_header(); ?>

<div class="container error-404">
    <div class="error-code">404</div>
    <h2><?php _e( 'Página no encontrada', 'monetawp' ); ?></h2>
    <p><?php _e( 'La ayuda que buscas puede haber cambiado de URL o ya no estar disponible.', 'monetawp' ); ?></p>
    <div style="margin-top:1.5rem;display:flex;flex-wrap:wrap;gap:.75rem;justify-content:center;">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn--primary">← <?php _e( 'Volver al inicio', 'monetawp' ); ?></a>
        <a href="<?php echo esc_url( home_url( '/convocatorias/' ) ); ?>" class="btn btn--danger"><?php _e( 'Ver todas las ayudas', 'monetawp' ); ?></a>
    </div>
    <div style="margin-top:2.5rem;max-width:400px;margin-left:auto;margin-right:auto;">
        <?php get_search_form(); ?>
    </div>
</div>

<?php get_footer();
