</main><!-- #main -->

<!-- ═══ ZONA DE ANUNCIO: FOOTER ═══════════════════════════════════════════ -->
<?php get_template_part( 'template-parts/ad-zone', 'footer' ); ?>

<!-- ═══ FOOTER ════════════════════════════════════════════════════════════ -->
<footer class="site-footer" role="contentinfo">
    <div class="container">

        <?php
        // ── Footer grid dinámico ──────────────────────────────────────────────
        $footer_order = get_theme_mod( 'mw_footer_order', 'date' );

        // Construir array de columnas configuradas
        $footer_columns = [];
        for ( $n = 1; $n <= 3; $n++ ) {
            $term_val = get_theme_mod( 'mw_footer_col' . $n . '_term', '' );
            $count    = absint( get_theme_mod( 'mw_footer_col' . $n . '_count', 5 ) ) ?: 5;

            if ( ! $term_val ) continue; // columna sin configurar, saltar

            $parts = explode( '|', $term_val, 2 );
            if ( count( $parts ) !== 2 ) continue;

            $taxonomy = sanitize_key( $parts[0] );
            $term_id  = absint( $parts[1] );
            $term_obj = get_term( $term_id, $taxonomy );

            if ( ! $term_obj || is_wp_error( $term_obj ) ) continue;

            $footer_columns[] = [
                'term'     => $term_obj,
                'taxonomy' => $taxonomy,
                'count'    => $count,
            ];
        }

        // Fallback cuando no hay nada configurado en el Customizer
        if ( empty( $footer_columns ) ) {
            $footer_columns = mw_footer_fallback_columns();
        }
        ?>

        <!-- Grid de columnas del footer -->
        <div class="footer-grid">
            <?php foreach ( $footer_columns as $col ) :

                // Consulta de posts para esta columna
                $query_args = [
                    'post_type'              => [ 'post', 'convocatoria' ],
                    'posts_per_page'         => $col['count'],
                    'no_found_rows'          => true,
                    'update_post_meta_cache' => false,
                    'tax_query'              => [ [
                        'taxonomy' => $col['taxonomy'],
                        'field'    => 'term_id',
                        'terms'    => $col['term']->term_id,
                    ] ],
                ];

                if ( $footer_order === 'rand' ) {
                    $query_args['orderby'] = 'rand';
                } else {
                    $query_args['orderby'] = 'date';
                    $query_args['order']   = 'DESC';
                }

                $col_posts = get_posts( $query_args );
                $col_url   = get_term_link( $col['term'] );
            ?>
            <div class="footer-col">
                <h4>
                    <?php if ( ! is_wp_error( $col_url ) ) : ?>
                        <a href="<?php echo esc_url( $col_url ); ?>"><?php echo esc_html( $col['term']->name ); ?></a>
                    <?php else : ?>
                        <?php echo esc_html( $col['term']->name ); ?>
                    <?php endif; ?>
                </h4>
                <ul>
                    <?php if ( ! empty( $col_posts ) ) : ?>
                        <?php foreach ( $col_posts as $p ) : ?>
                            <li><a href="<?php echo esc_url( get_permalink( $p->ID ) ); ?>"><?php echo esc_html( get_the_title( $p->ID ) ); ?></a></li>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <li><a href="<?php echo ! is_wp_error( $col_url ) ? esc_url( $col_url ) : '#'; ?>"><?php echo esc_html( $col['term']->name ); ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php endforeach; ?>

        </div><!-- .footer-grid -->

        <!-- Bottom bar -->
        <div class="footer-bottom">
            <p>&copy; <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?>. <?php _e( 'Todos los derechos reservados.', 'monetawp' ); ?></p>
            <div class="footer-links">
                <?php
                wp_nav_menu( [
                    'theme_location' => 'footer',
                    'container'      => false,
                    'depth'          => 1,
                    'fallback_cb'    => function() {
                        echo '<a href="' . esc_url( home_url( '/aviso-legal/' ) ) . '">' . __( 'Aviso Legal', 'monetawp' ) . '</a> · ';
                        echo '<a href="' . esc_url( home_url( '/politica-de-privacidad/' ) ) . '">' . __( 'Política de Privacidad', 'monetawp' ) . '</a> · ';
                        echo '<a href="' . esc_url( home_url( '/contacto/' ) ) . '">' . __( 'Contacto', 'monetawp' ) . '</a>';
                    },
                ] );
                ?>
            </div>
            <!-- Redes sociales -->
            <div class="footer-social">
                <?php $fb = get_theme_mod( 'mw_facebook_page', '' ); if ( $fb ) : ?>
                    <a href="<?php echo esc_url( $fb ); ?>" target="_blank" rel="noopener" aria-label="Facebook">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/></svg>
                    </a>
                <?php endif; ?>
                <?php $ig = get_theme_mod( 'mw_instagram_url', '' ); if ( $ig ) : ?>
                    <a href="<?php echo esc_url( $ig ); ?>" target="_blank" rel="noopener" aria-label="Instagram">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                    </a>
                <?php endif; ?>
                <?php $wa = get_theme_mod( 'mw_whatsapp_number', '' ); if ( $wa ) : ?>
                    <a href="<?php echo esc_url( mw_whatsapp_url() ); ?>" target="_blank" rel="noopener" aria-label="WhatsApp">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    </a>
                <?php endif; ?>
            </div>
        </div>

    </div><!-- .container -->
</footer>

<!-- WhatsApp Float Button -->
<?php get_template_part( 'template-parts/social-ctas' ); ?>

<!-- ManyChat Widget -->
<?php get_template_part( 'template-parts/manychat-widget' ); ?>

<?php wp_footer(); ?>
</body>
</html>
