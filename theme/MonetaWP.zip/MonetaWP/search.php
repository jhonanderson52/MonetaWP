<?php get_header(); ?>

<div class="archive-header">
    <div class="container">
        <h1>🔍 <?php printf( __( 'Resultados para: "%s"', 'monetawp' ), get_search_query() ); ?></h1>
        <p><?php printf( __( 'Se encontraron %d resultados.', 'monetawp' ), (int) $wp_query->found_posts ); ?></p>
    </div>
</div>

<div class="container" style="padding-bottom:3rem;">
    <div class="card-grid card-grid--3col">
        <?php if ( have_posts() ) :
            while ( have_posts() ) : the_post();
                get_template_part( 'template-parts/content', get_post_type() === 'convocatoria' ? 'convocatoria' : 'article' );
            endwhile;
        else :
            get_template_part( 'template-parts/content', 'none' );
        endif; ?>
    </div>
    <?php the_posts_pagination( [ 'prev_text' => '← Anterior', 'next_text' => 'Siguiente →' ] ); ?>
</div>

<?php get_footer();
