<?php
/**
 * Render: cta-whatsapp block.
 * Usa el número y el ManyChat Page ID del Theme Customizer.
 */
$titulo   = $attributes['titulo']  ?? __( '¿Quieres recibir esta ayuda en WhatsApp?', 'monetawp' );
$texto    = $attributes['texto']   ?? __( 'Te enviamos las últimas convocatorias abiertas directamente a tu móvil.', 'monetawp' );
$btn_text = $attributes['btnText'] ?? __( 'Suscribirme Gratis', 'monetawp' );
$ref      = $attributes['ref']     ?? '';

// Construir la URL: ManyChat si hay Page ID, WhatsApp como fallback
$manychat_id = get_theme_mod( 'mw_manychat_id', '' );
if ( $manychat_id ) {
    $url = 'https://m.me/' . rawurlencode( $manychat_id ) . ( $ref ? '?ref=' . rawurlencode( $ref ) : '' );
} else {
    $url = mw_whatsapp_url( $ref );
}
?>
<div class="cta-whatsapp-block">
    <h3><?php echo esc_html( $titulo ); ?></h3>
    <p><?php echo esc_html( $texto ); ?></p>
    <a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer" class="btn">
        📲 <?php echo esc_html( $btn_text ); ?>
    </a>
</div>
