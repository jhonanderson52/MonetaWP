<?php
/**
 * Render: deadline-banner block.
 * Variables disponibles: $attributes, $content, $block
 */

$fecha_limite = $attributes['fechaLimite'] ?? '';
$estado       = $attributes['estado']      ?? 'abierta';

if ( $estado === 'cerrada' ) {
    $bar_class = 'deadline-bar--closed';
    $icon      = '🔴';
    $text      = __( 'Esta convocatoria ya está cerrada.', 'monetawp' );
} elseif ( $fecha_limite ) {
    $days_left = (int) ceil( ( strtotime( $fecha_limite ) - time() ) / 86400 );

    if ( $days_left < 0 ) {
        $bar_class = 'deadline-bar--closed';
        $icon      = '🔴';
        $text      = __( 'El plazo ha finalizado.', 'monetawp' );
    } elseif ( $days_left === 0 ) {
        $bar_class = 'deadline-bar--urgent';
        $icon      = '🚨';
        $text      = __( '¡Último día! El plazo vence hoy.', 'monetawp' );
    } elseif ( $days_left < 7 ) {
        $bar_class = 'deadline-bar--urgent';
        $icon      = '🚨';
        $text      = sprintf( _n( 'Solo queda %d día para solicitar.', 'Solo quedan %d días para solicitar.', $days_left, 'monetawp' ), $days_left );
    } elseif ( $days_left < 30 ) {
        $bar_class = 'deadline-bar--soon';
        $icon      = '⏰';
        $text      = sprintf(
            __( 'Plazo próximo: %s (%d días restantes)', 'monetawp' ),
            date_i18n( 'd \d\e F \d\e Y', strtotime( $fecha_limite ) ),
            $days_left
        );
    } else {
        $bar_class = 'deadline-bar--ok';
        $icon      = '🟢';
        $text      = sprintf(
            __( 'Convocatoria abierta — Plazo hasta el %s', 'monetawp' ),
            date_i18n( 'd \d\e F \d\e Y', strtotime( $fecha_limite ) )
        );
    }
} else {
    $bar_class = 'deadline-bar--ok';
    $icon      = '🟢';
    $text      = __( 'Convocatoria abierta', 'monetawp' );
}
?>
<div class="deadline-bar <?php echo esc_attr( $bar_class ); ?>" data-deadline="<?php echo esc_attr( $fecha_limite ); ?>">
    <span aria-hidden="true"><?php echo $icon; ?></span>
    <span><?php echo esc_html( $text ); ?></span>
</div>
