<?php
/**
 * Render: ayuda-card block.
 */
$titulo    = $attributes['titulo']    ?? '';
$organismo = $attributes['organismo'] ?? '';
$importe   = $attributes['importe']   ?? '';
$plazo     = $attributes['plazo']     ?? '';
$url       = $attributes['url']       ?? '';
$estado    = $attributes['estado']    ?? 'abierta';

if ( empty( $titulo ) ) return;
?>
<div class="card" style="max-width:520px;margin:1.5rem auto;">
    <div class="card__body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:.5rem;margin-bottom:.5rem;">
            <h4 class="card__title" style="margin:0;"><?php echo esc_html( $titulo ); ?></h4>
            <span class="estado-pill estado-pill--<?php echo esc_attr( $estado ); ?>">
                <?php echo esc_html( ucfirst( $estado ) ); ?>
            </span>
        </div>

        <?php if ( $importe ) : ?>
            <div style="font-weight:700;color:var(--red);margin:.35rem 0;">
                💰 <?php echo esc_html( $importe ); ?>
            </div>
        <?php endif; ?>

        <?php if ( $organismo ) : ?>
            <div style="font-size:.9rem;color:var(--gray-600);">
                🏛️ <?php echo esc_html( $organismo ); ?>
            </div>
        <?php endif; ?>

        <?php if ( $plazo ) : ?>
            <div style="font-size:.9rem;margin-top:.35rem;">
                📅 <?php printf( __( 'Plazo: %s', 'monetawp' ), esc_html( date_i18n( 'd/m/Y', strtotime( $plazo ) ) ) ); ?>
            </div>
        <?php endif; ?>
    </div>

    <?php if ( $url ) : ?>
        <div class="card__footer">
            <a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer" class="btn btn--danger btn--full" style="font-size:.9rem;padding:.6rem 1rem;">
                <?php _e( 'Ver convocatoria oficial', 'monetawp' ); ?> →
            </a>
        </div>
    <?php endif; ?>
</div>
