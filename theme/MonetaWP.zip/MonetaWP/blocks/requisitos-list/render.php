<?php
/**
 * Render: requisitos-list block.
 */
$items = $attributes['items'] ?? [];
if ( empty( $items ) ) return;
?>
<ul class="requisitos-list" role="list">
    <?php foreach ( $items as $item ) : ?>
        <li><?php echo esc_html( $item ); ?></li>
    <?php endforeach; ?>
</ul>
