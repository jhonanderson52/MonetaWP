<?php
/**
 * Fallback template — WordPress lo usa cuando no encuentra otro template.
 * En la práctica, front-page.php, single.php, archive.php etc. tienen prioridad.
 */
get_header();
?>

<div class="container" style="padding-top:2rem;padding-bottom:3rem;">
    <div class="content-area">
        <main class="main-content">

            <?php if ( have_posts() ) : ?>

                <h1 class="section__title"><?php _e( 'Últimas Ayudas', 'monetawp' ); ?></h1>

                <div class="card-grid">
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php get_template_part( 'template-parts/content', 'article' ); ?>
                    <?php endwhile; ?>
                </div>

                <?php the_posts_pagination( [ 'prev_text' => '← Anterior', 'next_text' => 'Siguiente →' ] ); ?>

            <?php else : ?>

                <?php get_template_part( 'template-parts/content', 'none' ); ?>

            <?php endif; ?>

        </main>
    </div>
</div>

<?php get_footer();
