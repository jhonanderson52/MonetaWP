<?php
/**
 * Template: categorías estándar de WordPress (/becas/, /subvenciones-ayudas/, etc.)
 * El título H1 se obtiene automáticamente del nombre de la categoría,
 * o del campo personalizado "Título H1 personalizado" del admin de categorías.
 */
get_header();

$cols         = absint( get_theme_mod( 'mw_archive_cols', 3 ) ) ?: 3;
$show_related = get_theme_mod( 'mw_archive_show_related', '1' );
$term         = get_queried_object(); // WP_Term de la categoría actual
?>

<?php get_template_part( 'template-parts/archive', 'header' ); ?>

<div class="container" style="--archive-cols:<?php echo $cols; ?>;">
    <div class="archive-grid">
        <?php if ( have_posts() ) :
            while ( have_posts() ) : the_post();
                get_template_part( 'template-parts/content', 'article' );
            endwhile;
        else :
            get_template_part( 'template-parts/content', 'none' );
        endif; ?>
    </div>

    <?php the_posts_pagination( [
        'prev_text' => '← ' . __( 'Anterior', 'monetawp' ),
        'next_text' => __( 'Siguiente', 'monetawp' ) . ' →',
        'mid_size'  => 2,
    ] ); ?>
</div>

<?php if ( $show_related ) :
    // Categorías hermanas + taxonomías relacionadas como enlazado interno
    $otras_cats = get_categories( [
        'hide_empty' => true,
        'exclude'    => [ $term->term_id ],
        'number'     => 12,
        'orderby'    => 'count',
        'order'      => 'DESC',
    ] );
    $tipos = get_terms( [ 'taxonomy' => 'tipo_ayuda', 'hide_empty' => true ] );

    if ( ( ! empty( $otras_cats ) ) || ( ! is_wp_error( $tipos ) && ! empty( $tipos ) ) ) :
?>
    <section class="archive-related" aria-label="<?php _e( 'Categorías relacionadas', 'monetawp' ); ?>">
        <div class="container">
            <?php if ( ! empty( $otras_cats ) ) : ?>
                <p class="archive-related__title"><?php _e( 'Otras categorías', 'monetawp' ); ?></p>
                <div class="archive-related__pills" style="margin-bottom:1rem;">
                    <?php foreach ( $otras_cats as $cat ) : ?>
                        <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="archive-filter-pill">
                            <?php echo esc_html( $cat->name ); ?>
                            <sup style="font-size:.65em;margin-left:.2em;opacity:.75;"><?php echo absint( $cat->count ); ?></sup>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if ( ! is_wp_error( $tipos ) && ! empty( $tipos ) ) : ?>
                <p class="archive-related__title"><?php _e( 'Explorar por tipo de ayuda', 'monetawp' ); ?></p>
                <div class="archive-related__pills">
                    <?php foreach ( $tipos as $t ) :
                        $link = get_term_link( $t );
                        if ( is_wp_error( $link ) ) continue; ?>
                        <a href="<?php echo esc_url( $link ); ?>" class="archive-filter-pill">
                            <?php echo esc_html( $t->name ); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php
    endif;
endif; ?>

<?php get_footer();
