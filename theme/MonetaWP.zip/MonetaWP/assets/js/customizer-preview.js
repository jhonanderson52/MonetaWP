/**
 * Customizer Live Preview — actualiza estilos en tiempo real sin recargar.
 */
( function( $ ) {

    // ── Grid de Países: altura de la tarjeta completa ────────────────────────
    wp.customize( 'mw_countries_card_height', function( value ) {
        value.bind( function( newVal ) {
            document.querySelector( '.countries-section' )
                ?.style.setProperty( '--countries-card-height', newVal + 'px' );
        } );
    } );

    // ── Grid de Países: color de fondo de la caja de imagen ──────────────────
    wp.customize( 'mw_countries_card_bg', function( value ) {
        value.bind( function( newVal ) {
            document.querySelector( '.countries-section' )
                ?.style.setProperty( '--countries-card-bg', newVal );
        } );
    } );

} )( jQuery );
