/**
 * convocatoriasybecas.online — Main JS
 * Vanilla JS. Sin jQuery. Carga con defer.
 */
(function () {
    'use strict';

    // ── Mobile nav toggle (hamburguesa) ──────────────────────────────────────
    var navToggle    = document.getElementById('nav-toggle');
    var mobileDrawer = document.getElementById('mobile-drawer');

    function closeDrawer() {
        if (!mobileDrawer || !navToggle) return;
        mobileDrawer.classList.remove('is-open');
        mobileDrawer.setAttribute('aria-hidden', 'true');
        navToggle.classList.remove('is-active');
        navToggle.setAttribute('aria-expanded', 'false');
    }

    function openDrawer() {
        if (!mobileDrawer || !navToggle) return;
        mobileDrawer.classList.add('is-open');
        mobileDrawer.setAttribute('aria-hidden', 'false');
        navToggle.classList.add('is-active');
        navToggle.setAttribute('aria-expanded', 'true');
    }

    if (navToggle && mobileDrawer) {
        navToggle.addEventListener('click', function (e) {
            e.stopPropagation();
            mobileDrawer.classList.contains('is-open') ? closeDrawer() : openDrawer();
        });

        // Cerrar al hacer click fuera
        document.addEventListener('click', function (e) {
            if (mobileDrawer.classList.contains('is-open') &&
                !mobileDrawer.contains(e.target) &&
                !navToggle.contains(e.target)) {
                closeDrawer();
            }
        });

        // Cerrar con Escape
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') closeDrawer();
        });

        // Cerrar al redimensionar a desktop
        window.addEventListener('resize', function () {
            if (window.innerWidth >= 1024) closeDrawer();
        });
    }

    // ── Submenú móvil: toggle en drawer ──────────────────────────────────────
    document.querySelectorAll('.mobile-drawer .menu-item-has-children > a').forEach(function (link) {
        link.addEventListener('click', function (e) {
            var parent = this.parentElement;
            var submenu = parent.querySelector('.sub-menu');
            if (submenu) {
                e.preventDefault();
                var isOpen = parent.classList.contains('is-open');
                // Cerrar todos los submenús abiertos en el mismo nivel
                var siblings = parent.parentElement.querySelectorAll('.menu-item-has-children.is-open');
                siblings.forEach(function (sib) {
                    if (sib !== parent) {
                        sib.classList.remove('is-open');
                        var s = sib.querySelector('.sub-menu');
                        if (s) s.classList.remove('is-open');
                    }
                });
                parent.classList.toggle('is-open', !isOpen);
                submenu.classList.toggle('is-open', !isOpen);
            }
        });
    });

    // ── Web Share API (share buttons) ────────────────────────────────────────
    const nativeShareBtns = document.querySelectorAll('.share-btn--native');
    nativeShareBtns.forEach(function (btn) {
        if (!navigator.share) {
            btn.style.display = 'none';
            return;
        }
        btn.addEventListener('click', function () {
            navigator.share({
                title: btn.dataset.title || document.title,
                url: btn.dataset.url || location.href,
            }).catch(function () { /* user cancelled */ });
        });
    });

    // Ocultar share nativo si no hay soporte
    if (!navigator.share) {
        document.querySelectorAll('.share-btn--native').forEach(function (btn) {
            btn.style.display = 'none';
        });
    }

    // ── Smooth scroll para anclas internas ───────────────────────────────────
    document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
        anchor.addEventListener('click', function (e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

    // ── Lazy load polyfill para browsers sin soporte nativo ──────────────────
    if ('loading' in HTMLImageElement.prototype === false) {
        const lazyImages = document.querySelectorAll('img[loading="lazy"]');
        const observer = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                    }
                    observer.unobserve(img);
                }
            });
        });
        lazyImages.forEach(function (img) { observer.observe(img); });
    }

    // ── Countdown días restantes en deadline badges ──────────────────────────
    document.querySelectorAll('[data-deadline]').forEach(function (el) {
        const deadline = new Date(el.dataset.deadline);
        if (isNaN(deadline)) return;
        const now = new Date();
        const diff = Math.ceil((deadline - now) / (1000 * 60 * 60 * 24));

        if (diff < 0) {
            el.querySelector('.days-remaining') && (el.querySelector('.days-remaining').textContent = 'Plazo cerrado');
        } else if (diff === 0) {
            el.querySelector('.days-remaining') && (el.querySelector('.days-remaining').textContent = '¡Último día!');
        } else {
            el.querySelector('.days-remaining') && (el.querySelector('.days-remaining').textContent = diff + ' días restantes');
        }
    });

})();
