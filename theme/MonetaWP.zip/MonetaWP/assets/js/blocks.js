/**
 * Ayudas España — Gutenberg Blocks JS
 * Registro de bloques custom. Sin build pipeline (usa wp.* globals).
 */
(function (blocks, element, blockEditor, components, i18n) {
    'use strict';

    var el = element.createElement;
    var __ = i18n.__;
    var InspectorControls = blockEditor.InspectorControls;
    var TextControl = components.TextControl;
    var SelectControl = components.SelectControl;
    var PanelBody = components.PanelBody;

    // ── 1. Deadline Banner ───────────────────────────────────────────────────
    blocks.registerBlockType('ayudas-espana/deadline-banner', {
        title: __('Banner de Plazo', 'ayudas-espana'),
        icon: 'calendar-alt',
        category: 'ayudas-espana',
        description: __('Muestra el plazo límite de solicitud con color según urgencia.', 'ayudas-espana'),
        attributes: {
            fechaLimite: { type: 'string', default: '' },
            estado: { type: 'string', default: 'abierta' },
        },
        edit: function (props) {
            var attrs = props.attributes;
            var deadline = attrs.fechaLimite ? new Date(attrs.fechaLimite) : null;
            var daysLeft = deadline ? Math.ceil((deadline - new Date()) / 86400000) : null;
            var cls = 'deadline-bar deadline-bar--ok';
            var emoji = '🟢';

            if (attrs.estado === 'cerrada') { cls = 'deadline-bar deadline-bar--closed'; emoji = '🔴'; }
            else if (daysLeft !== null && daysLeft < 7)  { cls = 'deadline-bar deadline-bar--urgent'; emoji = '🔴'; }
            else if (daysLeft !== null && daysLeft < 30) { cls = 'deadline-bar deadline-bar--soon'; emoji = '🟡'; }

            return el('div', null,
                el(InspectorControls, null,
                    el(PanelBody, { title: __('Configuración', 'ayudas-espana') },
                        el(TextControl, {
                            label: __('Fecha límite (YYYY-MM-DD)', 'ayudas-espana'),
                            type: 'date',
                            value: attrs.fechaLimite,
                            onChange: function (val) { props.setAttributes({ fechaLimite: val }); },
                        }),
                        el(SelectControl, {
                            label: __('Estado', 'ayudas-espana'),
                            value: attrs.estado,
                            options: [
                                { label: '🟢 Abierta',      value: 'abierta'  },
                                { label: '🟡 Próximamente', value: 'proxima'  },
                                { label: '🔴 Cerrada',      value: 'cerrada'  },
                            ],
                            onChange: function (val) { props.setAttributes({ estado: val }); },
                        })
                    )
                ),
                el('div', { className: cls },
                    el('span', null, emoji),
                    el('span', null,
                        attrs.estado === 'cerrada'
                            ? __('Convocatoria cerrada', 'ayudas-espana')
                            : (attrs.fechaLimite
                                ? __('Plazo hasta: ', 'ayudas-espana') + attrs.fechaLimite + (daysLeft !== null ? ' (' + daysLeft + ' días)' : '')
                                : __('Indica una fecha límite', 'ayudas-espana')
                              )
                    )
                )
            );
        },
        save: function () { return null; }, // Render via PHP
    });

    // ── 2. Requisitos List ───────────────────────────────────────────────────
    blocks.registerBlockType('ayudas-espana/requisitos-list', {
        title: __('Lista de Requisitos', 'ayudas-espana'),
        icon: 'list-view',
        category: 'ayudas-espana',
        description: __('Lista con checkmarks verdes para requisitos de una ayuda.', 'ayudas-espana'),
        attributes: {
            items: { type: 'array', default: ['Requisito 1', 'Requisito 2'] },
        },
        edit: function (props) {
            var items = props.attributes.items;
            return el('div', { className: 'ayudas-block-editor' },
                el('p', { style: { color: '#666', fontSize: '12px', marginBottom: '8px' } },
                    __('Lista de Requisitos (edita en el panel lateral →)', 'ayudas-espana')
                ),
                el(InspectorControls, null,
                    el(PanelBody, { title: __('Requisitos', 'ayudas-espana') },
                        items.map(function (item, i) {
                            return el(TextControl, {
                                key: i,
                                label: __('Requisito', 'ayudas-espana') + ' ' + (i + 1),
                                value: item,
                                onChange: function (val) {
                                    var newItems = items.slice();
                                    newItems[i] = val;
                                    props.setAttributes({ items: newItems });
                                },
                            });
                        }),
                        el('button', {
                            className: 'button',
                            onClick: function () {
                                props.setAttributes({ items: items.concat(['']) });
                            },
                        }, __('+ Añadir requisito', 'ayudas-espana'))
                    )
                ),
                el('ul', { className: 'requisitos-list' },
                    items.map(function (item, i) {
                        return el('li', { key: i }, item);
                    })
                )
            );
        },
        save: function () { return null; },
    });

    // ── 3. CTA WhatsApp ──────────────────────────────────────────────────────
    blocks.registerBlockType('ayudas-espana/cta-whatsapp', {
        title: __('CTA WhatsApp', 'ayudas-espana'),
        icon: 'format-chat',
        category: 'ayudas-espana',
        description: __('Bloque de llamada a acción para WhatsApp o ManyChat.', 'ayudas-espana'),
        attributes: {
            titulo:  { type: 'string', default: '¿Quieres recibir esta ayuda en WhatsApp?' },
            texto:   { type: 'string', default: 'Te enviamos las últimas convocatorias abiertas directamente a tu móvil.' },
            btnText: { type: 'string', default: 'Suscribirme Gratis' },
            ref:     { type: 'string', default: '' },
        },
        edit: function (props) {
            var attrs = props.attributes;
            return el('div', null,
                el(InspectorControls, null,
                    el(PanelBody, { title: __('Configuración CTA', 'ayudas-espana') },
                        el(TextControl, { label: 'Título', value: attrs.titulo, onChange: function (v) { props.setAttributes({ titulo: v }); } }),
                        el(TextControl, { label: 'Texto', value: attrs.texto, onChange: function (v) { props.setAttributes({ texto: v }); } }),
                        el(TextControl, { label: 'Texto del botón', value: attrs.btnText, onChange: function (v) { props.setAttributes({ btnText: v }); } }),
                        el(TextControl, {
                            label: 'Ref ManyChat (opcional)',
                            help: 'Ej: ayudas-autonomos → activa flow específico',
                            value: attrs.ref,
                            onChange: function (v) { props.setAttributes({ ref: v }); },
                        })
                    )
                ),
                el('div', { className: 'cta-whatsapp-block' },
                    el('h3', null, attrs.titulo),
                    el('p', null, attrs.texto),
                    el('span', { className: 'btn' }, '📲 ' + attrs.btnText)
                )
            );
        },
        save: function () { return null; },
    });

    // ── 4. Ayuda Card ────────────────────────────────────────────────────────
    blocks.registerBlockType('ayudas-espana/ayuda-card', {
        title: __('Card de Ayuda', 'ayudas-espana'),
        icon: 'awards',
        category: 'ayudas-espana',
        description: __('Tarjeta embebible con detalles de una ayuda específica.', 'ayudas-espana'),
        attributes: {
            titulo:    { type: 'string', default: 'Nombre de la ayuda' },
            organismo: { type: 'string', default: '' },
            importe:   { type: 'string', default: '' },
            plazo:     { type: 'string', default: '' },
            url:       { type: 'string', default: '' },
            estado:    { type: 'string', default: 'abierta' },
        },
        edit: function (props) {
            var attrs = props.attributes;
            return el('div', null,
                el(InspectorControls, null,
                    el(PanelBody, { title: __('Detalles de la ayuda', 'ayudas-espana') },
                        el(TextControl, { label: 'Título', value: attrs.titulo, onChange: function (v) { props.setAttributes({ titulo: v }); } }),
                        el(TextControl, { label: 'Organismo', value: attrs.organismo, onChange: function (v) { props.setAttributes({ organismo: v }); } }),
                        el(TextControl, { label: 'Importe', value: attrs.importe, onChange: function (v) { props.setAttributes({ importe: v }); } }),
                        el(TextControl, { label: 'Fecha límite (YYYY-MM-DD)', type: 'date', value: attrs.plazo, onChange: function (v) { props.setAttributes({ plazo: v }); } }),
                        el(TextControl, { label: 'URL oficial', value: attrs.url, onChange: function (v) { props.setAttributes({ url: v }); } }),
                        el(SelectControl, {
                            label: 'Estado',
                            value: attrs.estado,
                            options: [
                                { label: '🟢 Abierta', value: 'abierta' },
                                { label: '🟡 Próximamente', value: 'proxima' },
                                { label: '🔴 Cerrada', value: 'cerrada' },
                            ],
                            onChange: function (v) { props.setAttributes({ estado: v }); },
                        })
                    )
                ),
                el('div', { className: 'ayuda-card-block' },
                    el('div', { className: 'ayuda-card-block__title' }, attrs.titulo),
                    attrs.importe && el('div', { className: 'ayuda-card-block__amount' }, '💰 ' + attrs.importe),
                    attrs.organismo && el('div', { style: { fontSize: '14px', color: '#666' } }, '🏛️ ' + attrs.organismo),
                    attrs.plazo && el('div', { style: { fontSize: '14px' } }, '📅 Plazo: ' + attrs.plazo)
                )
            );
        },
        save: function () { return null; },
    });

})(window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.i18n);
