<?php
/**
 * Taxonomy archive: tipo_ayuda (Becas, Subvenciones, Convocatorias…)
 */
get_header();

$cols         = absint( get_theme_mod( 'mw_archive_cols', 3 ) ) ?: 3;
$show_related = get_theme_mod( 'mw_archive_show_related', '1' );
$term         = get_queried_object();
?>

<?php get_template_part( 'template-parts/archive', 'header' ); ?>

<div class="container" style="--archive-cols:<?php echo $cols; ?>;">
    <div class="archive-grid">
        <?php if ( have_posts() ) :
            while ( have_posts() ) : the_post();
                get_template_part( 'template-parts/content', 'article' );
            endwhile;
        else :
            get_template_part( 'template-parts/content', 'none' );
        endif; ?>
    </div>

    <?php the_posts_pagination( [
        'prev_text' => '← ' . __( 'Anterior', 'monetawp' ),
        'next_text' => __( 'Siguiente', 'monetawp' ) . ' →',
        'mid_size'  => 2,
    ] ); ?>
</div>

<?php if ( $show_related ) :
    // Mostrar otros tipos de ayuda + tipos de beneficiario como enlazado interno
    $other_tipos = get_terms( [ 'taxonomy' => 'tipo_ayuda', 'hide_empty' => true, 'exclude' => [ $term->term_id ] ] );
    $beneficiarios = get_terms( [ 'taxonomy' => 'beneficiario', 'hide_empty' => true, 'number' => 8 ] );
    if ( ( ! is_wp_error( $other_tipos ) && $other_tipos ) || ( ! is_wp_error( $beneficiarios ) && $beneficiarios ) ) : ?>
    <section class="archive-related" aria-label="<?php _e( 'Categorías relacionadas', 'monetawp' ); ?>">
        <div class="container">
            <?php if ( ! is_wp_error( $other_tipos ) && $other_tipos ) : ?>
                <p class="archive-related__title"><?php _e( 'Otros tipos de ayuda', 'monetawp' ); ?></p>
                <div class="archive-related__pills" style="margin-bottom:1rem;">
                    <?php foreach ( $other_tipos as $t ) :
                        $link = get_term_link( $t );
                        if ( is_wp_error( $link ) ) continue; ?>
                        <a href="<?php echo esc_url( $link ); ?>" class="archive-filter-pill"><?php echo esc_html( $t->name ); ?></a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?php if ( ! is_wp_error( $beneficiarios ) && $beneficiarios ) : ?>
                <p class="archive-related__title"><?php _e( 'Ayudas por tipo de beneficiario', 'monetawp' ); ?></p>
                <div class="archive-related__pills">
                    <?php foreach ( $beneficiarios as $t ) :
                        $link = get_term_link( $t );
                        if ( is_wp_error( $link ) ) continue; ?>
                        <a href="<?php echo esc_url( $link ); ?>" class="archive-filter-pill"><?php echo esc_html( $t->name ); ?></a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif;
endif; ?>

<?php get_footer();
