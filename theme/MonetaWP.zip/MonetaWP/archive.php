<?php
/**
 * Template genérico de archivo — fallback para autores, fechas y cualquier otro
 * tipo de archivo no cubierto por category.php o los templates de taxonomía.
 */
get_header();

$cols = absint( get_theme_mod( 'mw_archive_cols', 3 ) ) ?: 3;

// Determinar título y descripción según el tipo de archivo
if ( is_category() ) {
    $term    = get_queried_object();
    $heading = mw_archive_get_heading( $term );
    $h1      = $heading['h1'];
    $desc    = $heading['desc'];
    $count   = $term->count;
} elseif ( is_tax() ) {
    $term    = get_queried_object();
    $heading = mw_archive_get_heading( $term );
    $h1      = $heading['h1'];
    $desc    = $heading['desc'];
    $count   = $term->count;
} elseif ( is_author() ) {
    $author  = get_queried_object();
    $h1      = sprintf( __( 'Artículos de %s', 'monetawp' ), $author->display_name );
    $desc    = get_the_author_meta( 'description', $author->ID );
    $count   = count_user_posts( $author->ID, 'post' );
} elseif ( is_date() ) {
    $h1    = get_the_archive_title();
    $desc  = '';
    $count = 0;
} else {
    $h1    = get_the_archive_title();
    $desc  = get_the_archive_description();
    $count = 0;
}
?>

<!-- Archive header genérico -->
<div class="archive-header">
    <div class="container">
        <h1><?php echo esc_html( $h1 ); ?></h1>
        <?php if ( $desc ) : ?>
            <p class="archive-header__desc"><?php echo wp_kses_post( $desc ); ?></p>
        <?php endif; ?>
        <?php if ( $count > 0 ) : ?>
            <div class="archive-header__meta">
                <span class="archive-count">
                    <?php printf( _n( '%s entrada', '%s entradas', $count, 'monetawp' ), number_format_i18n( $count ) ); ?>
                </span>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="container" style="--archive-cols:<?php echo $cols; ?>;">
    <div class="archive-grid">
        <?php if ( have_posts() ) :
            while ( have_posts() ) : the_post();
                get_template_part( 'template-parts/content', 'article' );
            endwhile;
        else :
            get_template_part( 'template-parts/content', 'none' );
        endif; ?>
    </div>

    <?php the_posts_pagination( [
        'prev_text' => '← ' . __( 'Anterior', 'monetawp' ),
        'next_text' => __( 'Siguiente', 'monetawp' ) . ' →',
        'mid_size'  => 2,
    ] ); ?>
</div>

<?php get_footer();
