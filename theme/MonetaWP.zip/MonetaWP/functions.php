<?php
/**
 * convocatoriasybecas.online — Theme Bootstrap
 *
 * Carga todos los archivos /inc/ y registra hooks principales.
 * No contiene lógica directa: delega a archivos especializados.
 */

defined( 'ABSPATH' ) || exit;

// Constantes del tema
define( 'MW_VERSION',   '1.0.0' );
define( 'MW_DIR',       get_template_directory() );
define( 'MW_URI',       get_template_directory_uri() );
define( 'MW_ASSETS',    MW_URI . '/assets' );

// ── Includes ─────────────────────────────────────────────────────────────────
require_once MW_DIR . '/inc/setup.php';
require_once MW_DIR . '/inc/enqueue.php';
require_once MW_DIR . '/inc/performance.php';
require_once MW_DIR . '/inc/cpt-pais.php';
require_once MW_DIR . '/inc/cpt-convocatoria.php';
require_once MW_DIR . '/inc/meta-boxes.php';
require_once MW_DIR . '/inc/adsense.php';
require_once MW_DIR . '/inc/schema.php';
require_once MW_DIR . '/inc/social.php';
require_once MW_DIR . '/inc/gutenberg-blocks.php';
require_once MW_DIR . '/inc/cookies.php';
require_once MW_DIR . '/inc/integrations.php';
require_once MW_DIR . '/inc/indexing.php';

// ── Permalinks de categorías sin prefijo /category/ ──────────────────────────
// Compatibilidad con categorías raíz (/becas-educacion/) y jerárquicas (/blog/guias-tutoriales/)

// 1. Quitar /category/ de todos los enlaces generados por WordPress
add_filter( 'category_link', function ( $link ) {
    return str_replace( '/category/', '/', $link );
}, 100 );

// 2. Generar reglas de rewrite sin el prefijo /category/
add_action( 'init', function () {
    global $wp_rewrite;
    $wp_rewrite->extra_permastructs['category']['struct']     = '%category%';
    $wp_rewrite->extra_permastructs['category']['with_front'] = false;
}, 999 );

// 3. Resolver conflictos página vs categoría.
//    Prioridad: Página > Categoría > Post (WordPress default).
add_action( 'parse_request', function ( &$wp ) {

    // Obtener el path limpio de la petición actual
    $req = isset( $_SERVER['PATH_INFO'] ) ? $_SERVER['PATH_INFO'] : $_SERVER['REQUEST_URI'];
    list( $req ) = explode( '?', $req );
    $req = str_replace( home_url( '', 'relative' ), '', $req );
    $req = trim( $req, '/' );

    if ( ! $req ) return;

    // No interferir con admin, API, archivos, feeds directos
    if ( preg_match( '#^(wp-admin|wp-content|wp-includes|wp-json|wp-login|xmlrpc)#', $req ) ) return;

    // Quitar /page/N/ y /feed/ para comprobar el path base
    $check_path = preg_replace( '#/page/[0-9]+$#', '', $req );
    $check_path = preg_replace( '#/feed(/.*)?$#', '', $check_path );

    // ── PRIORIDAD 1: ¿Existe una página con esta ruta? ──
    $page = get_page_by_path( $check_path );
    if ( $page ) {
        // Si WordPress lo identificó erróneamente como categoría, corregir a página
        if ( ! empty( $wp->query_vars['category_name'] ) ) {
            unset( $wp->query_vars['category_name'] );
            $wp->query_vars['pagename'] = $check_path;
        }
        return; // Es una página → dejar que WordPress la sirva
    }

    // ── PRIORIDAD 2: ¿Es una categoría? ──
    $cat = get_category_by_path( $check_path );
    if ( $cat && ! is_wp_error( $cat ) ) {
        // Es una categoría real → forzar query de categoría
        $wp->query_vars['category_name'] = $cat->slug;
        unset( $wp->query_vars['pagename'] );
        unset( $wp->query_vars['name'] );
        unset( $wp->query_vars['error'] );
        // Preservar paginación si existe
        if ( preg_match( '#/page/([0-9]+)$#', $req, $m ) ) {
            $wp->query_vars['paged'] = (int) $m[1];
        }
        return;
    }

    // ── PRIORIDAD 3: Si el rewrite asignó category_name pero NO es categoría real → es un post ──
    if ( ! empty( $wp->query_vars['category_name'] ) ) {
        unset( $wp->query_vars['category_name'] );
        $wp->query_vars['name'] = $check_path;
        unset( $wp->query_vars['error'] );
    }
}, 10 );

// 4. Redirigir /category/slug/ → /slug/ con 301
add_action( 'template_redirect', function () {
    if ( is_category() && strpos( $_SERVER['REQUEST_URI'], '/category/' ) !== false ) {
        wp_redirect( get_category_link( get_queried_object_id() ), 301 );
        exit;
    }
} );

// 5. Regenerar reglas al activar el tema
add_action( 'after_switch_theme', 'flush_rewrite_rules' );
