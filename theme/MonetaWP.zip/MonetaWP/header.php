<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="screen-reader-text" href="#main"><?php _e( 'Saltar al contenido', 'monetawp' ); ?></a>

<!-- ═══ CABECERA ══════════════════════════════════════════════════════════ -->
<header class="site-header" role="banner">

    <!-- Barra principal: Logo | Menú (desktop) | Búsqueda (desktop) | Toggle (mobile) -->
    <div class="site-nav">

        <!-- Logo (siempre visible) -->
        <div class="nav-brand">
            <?php if ( has_custom_logo() ) : ?>
                <?php the_custom_logo(); ?>
            <?php else : ?>
                <a class="site-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                    🌎
                    <span>
                        <?php bloginfo( 'name' ); ?>
                        <span class="site-logo__sub"><?php _e( 'Ayudas · Becas · Subvenciones', 'monetawp' ); ?></span>
                    </span>
                </a>
            <?php endif; ?>
        </div>

        <!-- Menú principal — solo visible en desktop via CSS -->
        <nav class="nav-menu-desktop" id="nav-menu-desktop" aria-label="<?php _e( 'Menú principal', 'monetawp' ); ?>">
            <?php wp_nav_menu( [
                'theme_location' => 'primary',
                'menu_id'        => 'desktop-menu',
                'container'      => false,
                'fallback_cb'    => '__return_false',
            ] ); ?>
        </nav>

        <!-- Acciones derecha -->
        <div class="nav-actions">
            <!-- Búsqueda — solo visible en desktop via CSS -->
            <div class="nav-search-wrap" role="search" aria-label="<?php _e( 'Buscar', 'monetawp' ); ?>">
                <?php get_search_form(); ?>
            </div>

            <!-- Botón hamburguesa — solo visible en mobile via CSS -->
            <button class="nav-toggle"
                    id="nav-toggle"
                    aria-controls="mobile-drawer"
                    aria-expanded="false"
                    aria-label="<?php _e( 'Abrir menú', 'monetawp' ); ?>">
                <span class="hamburger-icon" aria-hidden="true">
                    <span></span><span></span><span></span>
                </span>
            </button>
        </div>

    </div><!-- .site-nav -->

    <!-- Menú móvil drawer — oculto por defecto, se abre con JS -->
    <div class="mobile-drawer" id="mobile-drawer" aria-hidden="true" role="navigation" aria-label="<?php _e( 'Menú móvil', 'monetawp' ); ?>">
        <?php wp_nav_menu( [
            'theme_location' => 'primary',
            'menu_id'        => 'mobile-menu',
            'container'      => false,
            'fallback_cb'    => '__return_false',
        ] ); ?>
        <div class="mobile-drawer__search">
            <?php get_search_form(); ?>
        </div>
    </div>

</header><!-- .site-header -->

<?php if ( ! is_front_page() ) : ?>
<?php mw_breadcrumbs(); ?>
<?php endif; ?>

<?php get_template_part( 'template-parts/ad-zone', 'header' ); ?>

<main id="main" class="site-main" role="main">
