<?php mw_ad_zone( 'adsense-between-2' ); ?>
