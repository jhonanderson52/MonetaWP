<?php
/**
 * Últimos Artículos — configurable desde Personalizar → Últimos Artículos
 */

$section_title = get_theme_mod( 'mw_latest_title',       'Últimos Artículos' );
$count         = absint( get_theme_mod( 'mw_latest_count', 6 ) ) ?: 6;
$layout        = get_theme_mod( 'mw_latest_layout',      'grid' ); // grid | list
$cols          = absint( get_theme_mod( 'mw_latest_cols',  3 ) ) ?: 3;
$show_date     = get_theme_mod( 'mw_latest_show_date',   '1' );
$show_author   = get_theme_mod( 'mw_latest_show_author', '0' );
$cta_show      = get_theme_mod( 'mw_latest_cta_show',    '1' );
$cta_text      = get_theme_mod( 'mw_latest_cta_text',    'Ver todos los artículos →' );
$cta_url       = get_theme_mod( 'mw_latest_cta_url',     '/blog/' );
$cta_color     = get_theme_mod( 'mw_latest_cta_color',   '#1A2B4A' );

$latest_query = new WP_Query( [
    'post_type'              => 'post',
    'posts_per_page'         => $count,
    'no_found_rows'          => true,
    'update_post_meta_cache' => false,
] );

if ( ! $latest_query->have_posts() ) return;

$section_class = 'latest-section section';
if ( $layout === 'list' ) $section_class .= ' latest--list';

$section_style = '--latest-cols:' . $cols . ';';
$btn_style     = 'background:' . esc_attr( sanitize_hex_color( $cta_color ) ?: '#1A2B4A' ) . ';border-color:' . esc_attr( sanitize_hex_color( $cta_color ) ?: '#1A2B4A' ) . ';';
?>

<section class="<?php echo esc_attr( $section_class ); ?>"
         style="<?php echo esc_attr( $section_style ); ?>"
         aria-label="<?php echo esc_attr( $section_title ); ?>">
    <div class="container">
        <h2 class="section__title"><?php echo esc_html( $section_title ); ?></h2>

        <div class="latest-grid">
            <?php while ( $latest_query->have_posts() ) : $latest_query->the_post(); ?>
                <article class="card article-card">

                    <!-- Imagen -->
                    <a href="<?php the_permalink(); ?>" class="card__img-wrap" tabindex="-1" aria-hidden="true">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <?php the_post_thumbnail( 'mw-card', [
                                'class'   => 'card__img',
                                'loading' => 'lazy',
                                'alt'     => the_title_attribute( [ 'echo' => false ] ),
                            ] ); ?>
                        <?php else : ?>
                            <div class="card__img card__img--placeholder">
                                <span aria-hidden="true">📋</span>
                            </div>
                        <?php endif; ?>
                    </a>

                    <!-- Cuerpo -->
                    <div class="card__body">
                        <?php
                        $tipos = get_the_terms( get_the_ID(), 'tipo_ayuda' );
                        if ( ! $tipos || is_wp_error( $tipos ) ) {
                            $tipos = get_the_category();
                        }
                        if ( $tipos && ! is_wp_error( $tipos ) ) :
                            $tipo = reset( $tipos );
                            $tipo_url = ( $tipo instanceof WP_Term && $tipo->taxonomy !== 'category' )
                                ? get_term_link( $tipo )
                                : get_category_link( $tipo->term_id );
                        ?>
                            <a href="<?php echo esc_url( $tipo_url ); ?>" class="card__category">
                                <?php echo esc_html( $tipo->name ); ?>
                            </a>
                        <?php endif; ?>

                        <h3 class="card__title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                    </div>

                    <!-- Footer: fecha y/o autor -->
                    <?php if ( $show_date || $show_author ) : ?>
                    <footer class="card__footer">
                        <?php if ( $show_date ) : ?>
                            <time datetime="<?php echo get_the_date( 'c' ); ?>" class="card__date">
                                <?php echo get_the_date(); ?>
                            </time>
                        <?php endif; ?>
                        <?php if ( $show_author ) : ?>
                            <span class="card__author">
                                <?php _e( 'por', 'monetawp' ); ?>
                                <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
                                    <?php the_author(); ?>
                                </a>
                            </span>
                        <?php endif; ?>
                    </footer>
                    <?php endif; ?>

                </article>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>

        <?php if ( $cta_show && $cta_text && $cta_url ) : ?>
        <div style="text-align:center;margin-top:1.5rem;">
            <a href="<?php echo esc_url( home_url( $cta_url ) ); ?>"
               class="btn"
               style="<?php echo esc_attr( $btn_style ); ?>color:#fff;">
                <?php echo esc_html( $cta_text ); ?>
            </a>
        </div>
        <?php endif; ?>

    </div>
</section>
