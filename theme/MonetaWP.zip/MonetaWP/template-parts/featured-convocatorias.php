<?php
/**
 * Convocatorias Destacadas — 4 cards configurables desde el Customizer.
 * Apariencia → Personalizar → Ayudas España → Convocatorias Destacadas
 */

$section_title = get_theme_mod( 'mw_featured_title', 'Convocatorias Destacadas' );
$cta_text      = get_theme_mod( 'mw_featured_cta_text', 'Ver todas las convocatorias →' );
$cta_url       = get_theme_mod( 'mw_featured_cta_url',  '/convocatorias/' );

// Colores de icono válidos
$valid_colors = [ 'red', 'blue', 'green', 'gold' ];

// Defaults cuando no se ha configurado nada → usar los 4 posts más recientes
$auto_posts = [];

/**
 * Construye los datos de una tarjeta a partir de la configuración del Customizer.
 */
function mw_build_featured_card( $n, &$auto_posts ) {
    $prefix = 'mw_card_' . $n;

    $post_id      = absint( get_theme_mod( $prefix . '_post_id', 0 ) );
    $icon         = get_theme_mod( $prefix . '_icon',  '' );
    $color        = get_theme_mod( $prefix . '_color', '' );
    $custom_title = get_theme_mod( $prefix . '_custom_title', '' );
    $custom_text  = get_theme_mod( $prefix . '_custom_text',  '' );

    $defaults_icon  = [ 1 => '📋', 2 => '🎓', 3 => '💰', 4 => '🏦' ];
    $defaults_color = [ 1 => 'red', 2 => 'blue', 3 => 'green', 4 => 'gold' ];

    $icon  = $icon  ?: $defaults_icon[ $n ];
    $color = ( $color && in_array( $color, [ 'red', 'blue', 'green', 'gold' ], true ) ) ? $color : $defaults_color[ $n ];

    // Si no se eligió post, tomar del pool automático
    if ( ! $post_id ) {
        if ( empty( $auto_posts ) ) {
            // Intentar con convocatorias destacadas, luego convocatorias, luego posts
            $auto_posts = get_posts( [
                'post_type'      => 'convocatoria',
                'numberposts'    => 4,
                'meta_query'     => [ [ 'key' => '_convocatoria_featured', 'value' => '1', 'compare' => '=' ] ],
                'no_found_rows'  => true,
            ] );
            if ( count( $auto_posts ) < 4 ) {
                $auto_posts = get_posts( [ 'post_type' => [ 'convocatoria', 'post' ], 'numberposts' => 4, 'no_found_rows' => true ] );
            }
        }
        $idx  = $n - 1;
        $post = isset( $auto_posts[ $idx ] ) ? $auto_posts[ $idx ] : null;
    } else {
        $post = get_post( $post_id );
        if ( ! $post || $post->post_status !== 'publish' ) {
            $post = null;
        }
    }

    $title   = '';
    $excerpt = '';
    $url     = '#';

    if ( $post ) {
        $title   = $post->post_title;
        $url     = get_permalink( $post->ID );
        $raw_exc = $post->post_excerpt ?: wp_trim_words( wp_strip_all_tags( $post->post_content ), 20, '…' );
        $excerpt = $raw_exc;
    }

    // Sobrescribir con valores personalizados si los hay
    if ( $custom_title ) $title   = $custom_title;
    if ( $custom_text  ) $excerpt = $custom_text;

    return compact( 'icon', 'color', 'title', 'excerpt', 'url' );
}
?>

<section class="featured-section section">
    <div class="container">
        <h2 class="section__title"><?php echo esc_html( $section_title ); ?></h2>

        <div class="card-grid card-grid--4col">
            <?php for ( $n = 1; $n <= 4; $n++ ) :
                $card = mw_build_featured_card( $n, $auto_posts );
                if ( ! $card['title'] && ! $card['excerpt'] ) continue;
            ?>
            <article class="featured-card">

                <div class="featured-card__icon featured-card__icon--<?php echo esc_attr( $card['color'] ); ?>">
                    <?php echo $card['icon']; ?>
                </div>

                <h3>
                    <?php if ( $card['url'] !== '#' ) : ?>
                        <a href="<?php echo esc_url( $card['url'] ); ?>" style="color:inherit;text-decoration:none;">
                            <?php echo esc_html( $card['title'] ); ?>
                        </a>
                    <?php else : ?>
                        <?php echo esc_html( $card['title'] ); ?>
                    <?php endif; ?>
                </h3>

                <?php if ( $card['excerpt'] ) : ?>
                    <p class="featured-card__excerpt"><?php echo esc_html( $card['excerpt'] ); ?></p>
                <?php endif; ?>

                <?php if ( $card['url'] !== '#' ) : ?>
                    <a href="<?php echo esc_url( $card['url'] ); ?>" class="cta-link">
                        <?php _e( 'Ver detalles', 'monetawp' ); ?>
                    </a>
                <?php endif; ?>

            </article>
            <?php endfor; ?>
        </div>

        <?php if ( $cta_text && $cta_url ) : ?>
        <div style="text-align:center;margin-top:1.5rem;">
            <a href="<?php echo esc_url( home_url( $cta_url ) ); ?>" class="btn btn--danger">
                <?php echo esc_html( $cta_text ); ?>
            </a>
        </div>
        <?php endif; ?>

    </div>
</section>
