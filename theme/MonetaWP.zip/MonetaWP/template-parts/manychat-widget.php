<?php
/**
 * ManyChat widget — el script se carga en wp_footer via inc/social.php
 * Este archivo puede usarse para el botón "Messenger" visible si se desea.
 */
$manychat_id = get_theme_mod( 'mw_manychat_id', '' );
if ( empty( $manychat_id ) ) return;
// El widget se carga automáticamente via inc/social.php mw_manychat_widget()
// Este archivo queda disponible para añadir un botón personalizado si se necesita.
