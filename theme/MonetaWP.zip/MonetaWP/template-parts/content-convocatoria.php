<?php
/**
 * Card de convocatoria — usado en archivos y búsquedas.
 */
$post_id   = get_the_ID();
$amount    = get_post_meta( $post_id, '_convocatoria_amount',    true );
$organismo = get_post_meta( $post_id, '_convocatoria_organismo', true );
$estado    = get_post_meta( $post_id, '_convocatoria_estado',    true ) ?: 'abierta';
$deadline  = get_post_meta( $post_id, '_convocatoria_deadline',  true );
?>

<article class="card" <?php post_class(); ?>>
    <?php if ( has_post_thumbnail() ) : ?>
        <a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
            <?php the_post_thumbnail( 'ae-card', [
                'class'   => 'card__img',
                'loading' => 'lazy',
                'alt'     => the_title_attribute( [ 'echo' => false ] ),
            ] ); ?>
        </a>
    <?php endif; ?>

    <div class="card__body">
        <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:.5rem;align-items:center;">
            <span class="estado-pill estado-pill--<?php echo esc_attr( $estado ); ?>">
                <?php echo esc_html( ucfirst( $estado ) ); ?>
            </span>
            <?php if ( $deadline ) : ?>
                <span style="font-size:.75rem;color:var(--gray-600);">
                    📅 <?php echo esc_html( date_i18n( 'd/m/Y', strtotime( $deadline ) ) ); ?>
                </span>
            <?php endif; ?>
        </div>

        <h3 class="card__title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>

        <?php if ( $amount ) : ?>
            <div style="font-weight:700;color:var(--red);font-size:.9rem;margin:.25rem 0;">
                💰 <?php echo esc_html( $amount ); ?>
            </div>
        <?php endif; ?>

        <?php if ( $organismo ) : ?>
            <div style="font-size:.8rem;color:var(--gray-600);">
                🏛️ <?php echo esc_html( $organismo ); ?>
            </div>
        <?php endif; ?>
    </div>

    <footer class="card__footer">
        <a href="<?php the_permalink(); ?>" class="btn btn--danger btn--full" style="font-size:.9rem;padding:.6rem 1rem;">
            <?php _e( 'Ver detalles', 'monetawp' ); ?> →
        </a>
    </footer>
</article>
