<?php mw_ad_zone( 'adsense-footer' ); ?>
