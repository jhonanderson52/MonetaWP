<?php
/**
 * Sección de Pills/Etiquetas — configurable desde Personalizar → Sección de Etiquetas (Pills)
 */

// Si está desactivada, no mostrar nada
if ( ! get_theme_mod( 'mw_pills_enable', '1' ) ) return;

$section_title = get_theme_mod( 'mw_pills_title', 'Subvenciones por Comunidad Autónoma' );
$pill_bg       = get_theme_mod( 'mw_pills_bg',     '#FFFFFF' );
$pill_border   = get_theme_mod( 'mw_pills_border', '#E5E7EB' );
$pill_color    = get_theme_mod( 'mw_pills_color',  '#1A2B4A' );
$pill_hover    = get_theme_mod( 'mw_pills_hover',  '#CC0000' );

// Parsear los ítems del textarea
$items_raw = get_theme_mod( 'mw_pills_items', '' );
$pills     = [];

if ( $items_raw ) {
    foreach ( explode( "\n", $items_raw ) as $line ) {
        $line = trim( $line );
        if ( ! $line ) continue;

        $parts = array_map( 'trim', explode( '|', $line, 3 ) );
        if ( count( $parts ) < 2 ) continue;

        $icon  = $parts[0] ?? '';
        $name  = $parts[1] ?? '';
        $url   = isset( $parts[2] ) && $parts[2] ? home_url( $parts[2] ) : '';

        // Si no hay URL manual, intentar buscar el término por nombre en las taxonomías registradas
        if ( ! $url && $name ) {
            foreach ( [ 'comunidad_autonoma', 'category', 'beneficiario', 'tipo_ayuda' ] as $_tax ) {
                $_term = get_term_by( 'name', $name, $_tax );
                if ( $_term && ! is_wp_error( $_term ) ) {
                    $_link = get_term_link( $_term );
                    if ( ! is_wp_error( $_link ) ) { $url = $_link; break; }
                }
            }
        }

        if ( ! $name ) continue;
        $pills[] = [ 'icon' => $icon, 'name' => $name, 'url' => $url ?: '#' ];
    }
}

if ( empty( $pills ) ) return;

// CSS custom properties inline para los colores
$section_style = '--pill-bg:' . esc_attr( sanitize_hex_color( $pill_bg ) ?: '#fff' ) . ';'
    . '--pill-border:' . esc_attr( sanitize_hex_color( $pill_border ) ?: '#E5E7EB' ) . ';'
    . '--pill-color:' . esc_attr( sanitize_hex_color( $pill_color ) ?: '#1A2B4A' ) . ';'
    . '--pill-hover:' . esc_attr( sanitize_hex_color( $pill_hover ) ?: '#CC0000' ) . ';';
?>

<section class="comunidades-section section" style="<?php echo esc_attr( $section_style ); ?>" aria-label="<?php echo esc_attr( $section_title ); ?>">
    <div class="container">
        <h2 class="section__title"><?php echo esc_html( $section_title ); ?></h2>

        <div class="comunidades-grid">
            <?php foreach ( $pills as $pill ) : ?>
                <a href="<?php echo esc_url( $pill['url'] ); ?>" class="comunidad-pill">
                    <?php if ( $pill['icon'] ) : ?>
                        <span class="comunidad-pill__icon" aria-hidden="true"><?php echo $pill['icon']; ?></span>
                    <?php endif; ?>
                    <?php echo esc_html( $pill['name'] ); ?>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
