<?php
/**
 * Card de artículo para páginas de archivo — lee config del Customizer.
 */

// En la página Blog usa sus propios settings; en archivos/categorías usa los de Archivo
if ( ! empty( $GLOBALS['mw_blog_context'] ) ) {
    $show_date    = $GLOBALS['mw_blog_show_date'];
    $show_author  = $GLOBALS['mw_blog_show_author'];
    $show_excerpt = $GLOBALS['mw_blog_show_excerpt'];
} else {
    $show_date    = get_theme_mod( 'mw_archive_show_date',    '1' );
    $show_author  = get_theme_mod( 'mw_archive_show_author',  '0' );
    $show_excerpt = get_theme_mod( 'mw_archive_show_excerpt', '1' );
}

// Etiqueta de taxonomía principal
$tax_label = '';
$tax_url   = '';
$tipos = get_the_terms( get_the_ID(), 'tipo_ayuda' );
if ( $tipos && ! is_wp_error( $tipos ) ) {
    $tipo      = reset( $tipos );
    $tax_label = $tipo->name;
    $tax_url   = get_term_link( $tipo );
} else {
    $cats = get_the_category();
    if ( $cats ) {
        $tax_label = $cats[0]->name;
        $tax_url   = get_category_link( $cats[0]->term_id );
    }
}
?>
<article class="archive-card" <?php post_class(); ?>>

    <!-- Imagen -->
    <a href="<?php the_permalink(); ?>" class="archive-card__img-wrap" tabindex="-1" aria-hidden="true">
        <?php if ( has_post_thumbnail() ) : ?>
            <?php the_post_thumbnail( 'mw-card', [
                'class'   => 'archive-card__img',
                'loading' => 'lazy',
                'alt'     => the_title_attribute( [ 'echo' => false ] ),
            ] ); ?>
        <?php else : ?>
            <div class="archive-card__img--placeholder" aria-hidden="true">📋</div>
        <?php endif; ?>
    </a>

    <!-- Cuerpo -->
    <div class="archive-card__body">
        <?php if ( $tax_label && ! is_wp_error( $tax_url ) ) : ?>
            <a href="<?php echo esc_url( $tax_url ); ?>" class="archive-card__tax">
                <?php echo esc_html( $tax_label ); ?>
            </a>
        <?php endif; ?>

        <h3 class="archive-card__title">
            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
        </h3>

        <?php if ( $show_excerpt && get_the_excerpt() ) : ?>
            <p class="archive-card__excerpt"><?php echo wp_trim_words( get_the_excerpt(), 20 ); ?></p>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="archive-card__footer">
        <div class="archive-card__meta">
            <?php if ( $show_date ) : ?>
                <time class="archive-card__date" datetime="<?php echo get_the_date( 'c' ); ?>">
                    <?php echo get_the_date(); ?>
                </time>
            <?php endif; ?>
            <?php if ( $show_author ) : ?>
                <span class="archive-card__author">
                    <?php _e( 'por', 'monetawp' ); ?>
                    <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
                        <?php the_author(); ?>
                    </a>
                </span>
            <?php endif; ?>
        </div>
        <a href="<?php the_permalink(); ?>" class="archive-card__readmore" aria-label="<?php printf( esc_attr__( 'Leer más sobre %s', 'monetawp' ), get_the_title() ); ?>">
            <?php _e( 'Leer más →', 'monetawp' ); ?>
        </a>
    </footer>

</article>
