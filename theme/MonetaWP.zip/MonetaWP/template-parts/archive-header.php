<?php
/**
 * Cabecera reutilizable para todas las páginas de archivo / taxonomía.
 * Muestra: H1 personalizable, descripción, contador de entradas y pills de filtro.
 *
 * @param WP_Term $term  Término actual (se obtiene del query si no se pasa).
 */

$term       = $term ?? get_queried_object();
$heading    = mw_archive_get_heading( $term );
$h1         = $heading['h1'];
$desc       = $heading['desc'];
$term_link  = get_term_link( $term );
$post_count = $term->count ?? 0;

$show_filters = get_theme_mod( 'mw_archive_show_filters', '1' );

// ── Pills de filtro: otros términos de la misma taxonomía ────────────────────
$filter_terms = [];
if ( $show_filters ) {
    $siblings = get_terms( [
        'taxonomy'   => $term->taxonomy,
        'hide_empty' => true,
        'exclude'    => [ $term->term_id ],
        'number'     => 10,
        'orderby'    => 'count',
        'order'      => 'DESC',
    ] );
    if ( ! is_wp_error( $siblings ) ) $filter_terms = $siblings;
}
?>

<!-- ── Archive header ─────────────────────────────────────────── -->
<div class="archive-header">
    <div class="container">
        <h1><?php echo esc_html( $h1 ); ?></h1>

        <?php if ( $desc ) : ?>
            <p class="archive-header__desc"><?php echo wp_kses_post( $desc ); ?></p>
        <?php endif; ?>

        <div class="archive-header__meta">
            <?php if ( $post_count > 0 ) : ?>
                <span class="archive-count">
                    <?php printf( _n( '%s entrada', '%s entradas', $post_count, 'monetawp' ), number_format_i18n( $post_count ) ); ?>
                </span>
            <?php endif; ?>
            <?php if ( ! is_wp_error( $term_link ) ) : ?>
                <span><?php _e( 'Actualizado constantemente', 'monetawp' ); ?></span>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if ( $show_filters && ! empty( $filter_terms ) ) : ?>
<!-- ── Barra de filtros ───────────────────────────────────────── -->
<nav class="archive-filters" aria-label="<?php _e( 'Filtrar por categoría', 'monetawp' ); ?>">
    <div class="archive-filters__inner">
        <span class="archive-filters__label"><?php _e( 'Ver también:', 'monetawp' ); ?></span>
        <?php foreach ( $filter_terms as $ft ) :
            $ft_link = get_term_link( $ft );
            if ( is_wp_error( $ft_link ) ) continue;
        ?>
            <a href="<?php echo esc_url( $ft_link ); ?>" class="archive-filter-pill">
                <?php echo esc_html( $ft->name ); ?>
                <sup style="font-size:.65em;margin-left:.2em;opacity:.75;"><?php echo absint( $ft->count ); ?></sup>
            </a>
        <?php endforeach; ?>
    </div>
</nav>
<?php endif; ?>
