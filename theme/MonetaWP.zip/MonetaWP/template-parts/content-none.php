<?php
/**
 * Empty state — sin resultados.
 */
?>
<div class="no-results">
    <span style="font-size:3rem;">🔍</span>
    <h2><?php _e( 'No se encontraron resultados', 'monetawp' ); ?></h2>
    <p><?php _e( 'Prueba con otros términos de búsqueda o explora las categorías.', 'monetawp' ); ?></p>
    <div style="margin-top:1.5rem;display:flex;flex-wrap:wrap;gap:.75rem;justify-content:center;">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn--primary"><?php _e( 'Volver al inicio', 'monetawp' ); ?></a>
        <a href="<?php echo esc_url( home_url( '/convocatorias/' ) ); ?>" class="btn btn--danger"><?php _e( 'Ver todas las ayudas', 'monetawp' ); ?></a>
    </div>
</div>
