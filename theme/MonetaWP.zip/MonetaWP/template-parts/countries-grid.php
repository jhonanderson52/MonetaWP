<?php
/**
 * Countries Grid — Hub global de países.
 * Muestra los países registrados en el CPT 'pais', con imagen de fondo completa y texto superpuesto.
 */

$section_title = get_theme_mod( 'mw_countries_title',      'Encuentra Ayudas en tu País' );
$cta_label     = get_theme_mod( 'mw_countries_cta',        'Explorar ayudas' );
$card_height   = absint( get_theme_mod( 'mw_countries_card_height', 280 ) );
$card_bg       = sanitize_hex_color( get_theme_mod( 'mw_countries_card_bg', '#002244' ) ) ?: '#002244';
$layout        = get_theme_mod( 'mw_countries_layout',     '2-3' );
$overlay_pct   = absint( get_theme_mod( 'mw_countries_overlay',    40 ) );
$overlay_alpha = round( min( $overlay_pct, 100 ) / 100, 2 );
$text_color    = sanitize_hex_color( get_theme_mod( 'mw_countries_text_color',  '#FFFFFF' ) ) ?: '#FFFFFF';
$link_color    = sanitize_hex_color( get_theme_mod( 'mw_countries_link_color',  '#67E8F9' ) ) ?: '#67E8F9';

$btn_show  = get_theme_mod( 'mw_countries_cta_show',  '1' );
$btn_text  = get_theme_mod( 'mw_countries_cta_text',  'Ver todos los países →' );
$btn_url   = get_theme_mod( 'mw_countries_cta_url',   '/paises/' );
$btn_color = sanitize_hex_color( get_theme_mod( 'mw_countries_cta_color', '#002244' ) ) ?: '#002244';

$section_style = '--ctry-height:' . $card_height . 'px;'
               . '--ctry-overlay:' . $overlay_alpha . ';'
               . '--ctry-text:' . $text_color . ';'
               . '--ctry-link:' . $link_color . ';'
               . '--ctry-bg:' . $card_bg . ';';

$paises = new WP_Query( [
    'post_type'      => 'pais',
    'posts_per_page' => -1,
    'no_found_rows'  => true,
    'meta_key'       => '_pais_orden',
    'orderby'        => [ 'meta_value_num' => 'ASC', 'title' => 'ASC' ],
] );

if ( ! $paises->have_posts() ) return;
?>

<section class="countries-section section"
         style="<?php echo esc_attr( $section_style ); ?>"
         data-layout="<?php echo esc_attr( $layout ); ?>"
         aria-label="<?php echo esc_attr( $section_title ); ?>">
    <div class="container">

        <h2 class="section__title"><?php echo esc_html( $section_title ); ?></h2>

        <div class="countries-grid">
            <?php while ( $paises->have_posts() ) : $paises->the_post();
                $codigo   = strtoupper( trim( get_post_meta( get_the_ID(), '_pais_codigo', true ) ) );
                $url_blog = get_post_meta( get_the_ID(), '_pais_url_blog', true );
                $excerpt  = get_the_excerpt();
                $thumb    = get_the_post_thumbnail_url( null, 'large' );

                $code_lc = strtolower( $codigo );

                // Imagen — prioridad: 1) Customizer  2) thumbnail del post  3) bandera SVG CDN
                $customizer_img = $codigo ? get_theme_mod( 'mw_country_img_' . $code_lc, '' ) : '';
                $bg_url = $customizer_img
                    ? $customizer_img
                    : ( $thumb
                        ? $thumb
                        : ( $codigo ? 'https://cdn.jsdelivr.net/npm/flag-icons@7.2.3/flags/4x3/' . esc_attr( $code_lc ) . '.svg' : '' ) );

                // Enlace — prioridad: 1) Customizer  2) meta _pais_url_blog  3) permalink del CPT
                $customizer_url = $codigo ? get_theme_mod( 'mw_country_url_' . $code_lc, '' ) : '';
                if ( $customizer_url ) {
                    $url_blog = $customizer_url;
                } elseif ( ! $url_blog ) {
                    $url_blog = get_permalink();
                }
            ?>
            <a href="<?php echo esc_url( $url_blog ); ?>"
               class="country-card"
               rel="noopener"
               <?php if ( $bg_url ) : ?>
               style="background-image:url('<?php echo esc_url( $bg_url ); ?>');"
               <?php endif; ?>
               aria-label="<?php echo esc_attr( get_the_title() ); ?>">

                <!-- Overlay oscuro -->
                <div class="country-card__overlay" aria-hidden="true"></div>

                <!-- Contenido superpuesto -->
                <div class="country-card__body">
                    <?php if ( $codigo ) : ?>
                    <span class="country-card__code"><?php echo esc_html( strtolower( $codigo ) ); ?></span>
                    <?php endif; ?>

                    <h3 class="country-card__title"><?php the_title(); ?></h3>

                    <?php if ( $excerpt ) : ?>
                    <p class="country-card__excerpt"><?php echo esc_html( wp_trim_words( $excerpt, 18 ) ); ?></p>
                    <?php endif; ?>

                    <?php if ( $cta_label ) : ?>
                    <span class="country-card__cta"><?php echo esc_html( $cta_label ); ?> →</span>
                    <?php endif; ?>
                </div>

            </a>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>

        <?php if ( $btn_show && $btn_text && $btn_url ) : ?>
        <div class="countries-section__footer">
            <a href="<?php echo esc_url( home_url( $btn_url ) ); ?>"
               class="btn countries-section__btn"
               style="background:<?php echo $btn_color; ?>;border-color:<?php echo $btn_color; ?>;color:#fff;">
                <?php echo esc_html( $btn_text ); ?>
            </a>
        </div>
        <?php endif; ?>

    </div>
</section>
