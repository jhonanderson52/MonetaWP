<?php
/**
 * Cuadros de Categorías — configurable desde Personalizar → Cuadros de Categorías
 */

$section_title = get_theme_mod( 'mw_segments_title', 'Encuentra Ayudas para Ti' );
$cols          = absint( get_theme_mod( 'mw_segments_cols', 2 ) ) ?: 2;
$height        = absint( get_theme_mod( 'mw_segments_height', 280 ) ) ?: 280;
$label_bg      = sanitize_hex_color( get_theme_mod( 'mw_segments_label_bg',  '#1E3A5F' ) ) ?: '#1E3A5F';
$label_bg2     = sanitize_hex_color( get_theme_mod( 'mw_segments_label_bg2', '#0891B2' ) ) ?: '#0891B2';
$overlay_pct   = absint( get_theme_mod( 'mw_segments_overlay', 30 ) );
$overlay_alpha = round( min( $overlay_pct, 100 ) / 100, 2 );

$label_style   = 'background:linear-gradient(to right,' . esc_attr( $label_bg ) . ',' . esc_attr( $label_bg2 ) . ');';
// Custom properties en el section → las leen CSS y el live preview JS puede actualizarlas directamente
$section_style = '--seg-cols:' . $cols . ';--seg-height:' . $height . 'px;--seg-overlay:' . $overlay_alpha . ';';

$default_icons = [ 1 => '🎓', 2 => '💼', 3 => '🏢', 4 => '🚀' ];

// Defaults cuando no se ha configurado nada
$fallback_segments = [
    1 => [ 'term' => 'beneficiario|', 'slug' => 'estudiantes',  'label' => 'Estudiantes',   'url' => '/beneficiario/estudiantes/' ],
    2 => [ 'term' => 'beneficiario|', 'slug' => 'autonomos',    'label' => 'Autónomos',     'url' => '/beneficiario/autonomos/' ],
    3 => [ 'term' => 'beneficiario|', 'slug' => 'pymes',        'label' => 'PYMES',         'url' => '/beneficiario/pymes/' ],
    4 => [ 'term' => 'beneficiario|', 'slug' => 'emprendedores','label' => 'Emprendedores', 'url' => '/beneficiario/emprendedores/' ],
];

$cards = [];
for ( $n = 1; $n <= 4; $n++ ) {
    $sp = 'mw_seg_' . $n;

    $term_value   = get_theme_mod( $sp . '_term',  '' );
    $custom_label = get_theme_mod( $sp . '_label', '' );
    $custom_url   = get_theme_mod( $sp . '_url',   '' );
    $raw_image    = get_theme_mod( $sp . '_image', '' );
    $image_url    = $raw_image ? set_url_scheme( $raw_image, 'https' ) : '';
    $icon         = get_theme_mod( $sp . '_icon',  $default_icons[ $n ] );

    $label = '';
    $url   = '';

    // Resolver término asociado
    if ( $term_value ) {
        $parts = explode( '|', $term_value, 2 );
        if ( count( $parts ) === 2 ) {
            $term_obj = get_term( (int) $parts[1], $parts[0] );
            if ( $term_obj && ! is_wp_error( $term_obj ) ) {
                $label = $term_obj->name;
                $url   = get_term_link( $term_obj );
                if ( is_wp_error( $url ) ) $url = '';
            }
        }
    }

    // Sobrescribir con valores manuales
    if ( $custom_label ) $label = $custom_label;
    if ( $custom_url )   $url   = home_url( $custom_url );

    // Si sigue vacío, usar fallback
    if ( ! $label && isset( $fallback_segments[ $n ] ) ) {
        $label = $fallback_segments[ $n ]['label'];
    }
    if ( ! $url && isset( $fallback_segments[ $n ] ) ) {
        $url = home_url( $fallback_segments[ $n ]['url'] );
    }

    if ( ! $label ) continue; // omitir cuadros sin configurar

    $cards[] = compact( 'label', 'url', 'image_url', 'icon' );
}
?>

<section class="segments-section section" style="<?php echo esc_attr( $section_style ); ?>" aria-label="<?php echo esc_attr( $section_title ); ?>">
    <div class="container">
        <h2 class="section__title"><?php echo esc_html( $section_title ); ?></h2>

        <div class="segment-grid">
            <?php foreach ( $cards as $card ) : ?>
                <a href="<?php echo esc_url( $card['url'] ); ?>"
                   class="segment-card">

                    <?php if ( $card['image_url'] ) : ?>
                        <img
                            src="<?php echo esc_url( $card['image_url'] ); ?>"
                            alt="<?php echo esc_attr( $card['label'] ); ?>"
                            width="480" height="<?php echo $height; ?>"
                            loading="lazy"
                        >
                    <?php else : ?>
                        <div class="segment-card__placeholder" aria-hidden="true"></div>
                    <?php endif; ?>

                    <div class="segment-card__label" style="<?php echo esc_attr( $label_style ); ?>">
                        <span class="segment-card__icon" aria-hidden="true"><?php echo $card['icon']; ?></span>
                        <?php echo esc_html( $card['label'] ); ?>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
