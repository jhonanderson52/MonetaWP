<?php
/**
 * Hero — Sección principal de la homepage.
 */
$bg_image  = get_theme_mod( 'mw_hero_bg', '' );
$title     = get_theme_mod( 'mw_hero_title',    'Encuentra Ayudas Gubernamentales en tu País' );
$subtitle  = get_theme_mod( 'mw_hero_subtitle', 'Becas, subvenciones y auxilios para autónomos, madres cabeza de familia, jóvenes y más — en España, México, Canadá, Ecuador y EE.UU.' );
$cta1_text = get_theme_mod( 'mw_hero_cta1_text', 'Ver Becas' );
$cta1_url  = get_theme_mod( 'mw_hero_cta1_url',  '/categoria/becas-educacion/' );
$cta2_text = get_theme_mod( 'mw_hero_cta2_text', 'Ayudas Autónomos' );
$cta2_url  = get_theme_mod( 'mw_hero_cta2_url',  '/categoria/ayudas-autonomos/' );
$cta3_text = get_theme_mod( 'mw_hero_cta3_text', 'Ver Guía' );
$cta3_url  = get_theme_mod( 'mw_hero_cta3_url',  '/guia-de-ayudas/' );

// Iconos de los botones
$cta1_icon = get_theme_mod( 'mw_hero_cta1_icon', '🎓' );
$cta2_icon = get_theme_mod( 'mw_hero_cta2_icon', '💼' );
$cta3_icon = get_theme_mod( 'mw_hero_cta3_icon', '📖' );

// Colores de los botones — Paleta Global "Humanitas"
$cta1_bg   = get_theme_mod( 'mw_hero_cta1_bg',     '#F97316' );  // Orange CTA
$cta1_tc   = get_theme_mod( 'mw_hero_cta1_text_c', '#FFFFFF' );
$cta2_bg   = get_theme_mod( 'mw_hero_cta2_bg',     '#0891B2' );  // Teal secundario
$cta2_tc   = get_theme_mod( 'mw_hero_cta2_text_c', '#FFFFFF' );
$cta3_bg   = get_theme_mod( 'mw_hero_cta3_bg',     'transparent' );
$cta3_tc   = get_theme_mod( 'mw_hero_cta3_text_c', '#FFFFFF' );

// Helper: genera el inline style para cada botón
function mw_btn_style( $bg, $tc ) {
    $s = 'color:' . esc_attr( $tc ) . ';';
    if ( $bg === 'transparent' ) {
        $s .= 'background:transparent;border-color:' . esc_attr( $tc ) . ';';
    } else {
        $safe = sanitize_hex_color( $bg ) ?: '#1A2B4A';
        $s   .= 'background:' . $safe . ';border-color:' . $safe . ';';
    }
    return $s;
}

// Oscuridad del overlay: 0 (sin oscuridad) → 100 (negro total). Default 60.
$overlay_pct   = absint( get_theme_mod( 'mw_hero_overlay', 60 ) );
$overlay_alpha = round( min( $overlay_pct, 100 ) / 100, 2 );
$hero_style    = '--hero-overlay-opacity:' . $overlay_alpha . ';';
?>

<section class="hero" style="<?php echo esc_attr( $hero_style ); ?>" aria-label="<?php _e( 'Presentación', 'monetawp' ); ?>">

    <?php if ( $bg_image ) : ?>
        <div class="hero__bg" style="background-image:url('<?php echo esc_url( $bg_image ); ?>');" role="presentation"></div>
    <?php endif; ?>

    <div class="hero__inner">
        <h1><?php echo esc_html( $title ); ?></h1>
        <p class="hero__subtitle"><?php echo esc_html( $subtitle ); ?></p>

        <div class="hero__ctas">
            <?php if ( $cta1_text && $cta1_url ) : ?>
            <a href="<?php echo esc_url( home_url( $cta1_url ) ); ?>"
               class="btn"
               style="<?php echo mw_btn_style( $cta1_bg, $cta1_tc ); ?>">
                <?php if ( $cta1_icon ) : ?><span aria-hidden="true"><?php echo $cta1_icon; ?></span><?php endif; ?>
                <?php echo esc_html( $cta1_text ); ?>
            </a>
            <?php endif; ?>

            <?php if ( $cta2_text && $cta2_url ) : ?>
            <a href="<?php echo esc_url( home_url( $cta2_url ) ); ?>"
               class="btn"
               style="<?php echo mw_btn_style( $cta2_bg, $cta2_tc ); ?>">
                <?php if ( $cta2_icon ) : ?><span aria-hidden="true"><?php echo $cta2_icon; ?></span><?php endif; ?>
                <?php echo esc_html( $cta2_text ); ?>
            </a>
            <?php endif; ?>

            <?php if ( $cta3_text && $cta3_url ) : ?>
            <a href="<?php echo esc_url( home_url( $cta3_url ) ); ?>"
               class="btn"
               style="<?php echo mw_btn_style( $cta3_bg, $cta3_tc ); ?>">
                <?php if ( $cta3_icon ) : ?><span aria-hidden="true"><?php echo $cta3_icon; ?></span><?php endif; ?>
                <?php echo esc_html( $cta3_text ); ?>
            </a>
            <?php endif; ?>
        </div>
    </div>

</section>
