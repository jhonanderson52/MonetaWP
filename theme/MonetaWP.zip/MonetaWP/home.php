<?php
/**
 * Template: Página de entradas (Blog).
 * WordPress usa home.php cuando se configura una "Página de entradas" en
 * Ajustes → Lectura. Lee toda su configuración desde el Customizer.
 */
get_header();

$blog_title     = get_theme_mod( 'mw_blog_title',          'Últimas Ayudas' );
$blog_subtitle  = get_theme_mod( 'mw_blog_subtitle',       '' );
$cols           = absint( get_theme_mod( 'mw_blog_cols',   2 ) ) ?: 2;
$img_height     = absint( get_theme_mod( 'mw_blog_card_img_height', 200 ) );
$header_bg      = sanitize_hex_color( get_theme_mod( 'mw_blog_header_bg', '#F0F9FF' ) ) ?: '#F0F9FF';
$header_tc      = sanitize_hex_color( get_theme_mod( 'mw_blog_header_tc', '#002244' ) ) ?: '#002244';
$show_header    = get_theme_mod( 'mw_blog_show_header', '1' );

// Pasar configuración a content-article.php vía globals
$GLOBALS['mw_blog_show_date']    = get_theme_mod( 'mw_blog_show_date',    '1' );
$GLOBALS['mw_blog_show_author']  = get_theme_mod( 'mw_blog_show_author',  '0' );
$GLOBALS['mw_blog_show_excerpt'] = get_theme_mod( 'mw_blog_show_excerpt', '1' );
$GLOBALS['mw_blog_context']      = true; // flag para que content-article.php use los settings del blog
?>

<?php if ( $show_header ) : ?>
<div class="blog-header" style="background:<?php echo esc_attr( $header_bg ); ?>;color:<?php echo esc_attr( $header_tc ); ?>;" data-customizer="mw_blog_header">
    <div class="container">
        <h1 class="blog-header__title" style="color:<?php echo esc_attr( $header_tc ); ?>;">
            <?php echo esc_html( $blog_title ); ?>
        </h1>
        <?php if ( $blog_subtitle ) : ?>
        <p class="blog-header__subtitle" style="color:<?php echo esc_attr( $header_tc ); ?>;">
            <?php echo esc_html( $blog_subtitle ); ?>
        </p>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<div class="container blog-archive"
     style="--blog-cols:<?php echo $cols; ?>;--blog-img-height:<?php echo $img_height; ?>px;padding-top:2rem;padding-bottom:3rem;">

    <div class="archive-grid blog-grid">
        <?php if ( have_posts() ) :
            while ( have_posts() ) : the_post();
                get_template_part( 'template-parts/content', 'article' );
            endwhile;
        else :
            get_template_part( 'template-parts/content', 'none' );
        endif; ?>
    </div>

    <?php the_posts_pagination( [
        'prev_text' => '← ' . __( 'Anterior', 'monetawp' ),
        'next_text' => __( 'Siguiente', 'monetawp' ) . ' →',
        'mid_size'  => 2,
    ] ); ?>

</div>

<?php
// Limpiar globals
unset( $GLOBALS['mw_blog_context'], $GLOBALS['mw_blog_show_date'], $GLOBALS['mw_blog_show_author'], $GLOBALS['mw_blog_show_excerpt'] );
get_footer();
