<?php
/**
 * Single convocatoria — CPT convocatoria individual.
 */
get_header();
?>

<div class="container" style="padding-top:1.5rem;padding-bottom:3rem;">
    <div class="content-area content-area--with-sidebar">

        <article class="main-content" <?php post_class( 'convocatoria-single' ); ?>>
            <?php while ( have_posts() ) : the_post();

                $deadline  = get_post_meta( get_the_ID(), '_convocatoria_deadline',  true );
                $amount    = get_post_meta( get_the_ID(), '_convocatoria_amount',    true );
                $organismo = get_post_meta( get_the_ID(), '_convocatoria_organismo', true );
                $url_boe   = get_post_meta( get_the_ID(), '_convocatoria_url_boe',   true );
                $estado    = get_post_meta( get_the_ID(), '_convocatoria_estado',    true ) ?: 'abierta';

                // Calcular días restantes
                $days_left = null;
                if ( $deadline ) {
                    $diff = ( strtotime( $deadline ) - time() ) / 86400;
                    $days_left = (int) ceil( $diff );
                }

                // Clase del banner de deadline
                if ( $estado === 'cerrada' ) {
                    $bar_class = 'deadline-bar--closed';
                    $bar_icon  = '🔴';
                    $bar_text  = __( 'Esta convocatoria está cerrada', 'monetawp' );
                } elseif ( $days_left !== null && $days_left < 7 ) {
                    $bar_class = 'deadline-bar--urgent';
                    $bar_icon  = '🚨';
                    $bar_text  = sprintf( __( '¡Solo quedan %d días! Plazo hasta el %s', 'monetawp' ), $days_left, date_i18n( 'd M Y', strtotime( $deadline ) ) );
                } elseif ( $days_left !== null && $days_left < 30 ) {
                    $bar_class = 'deadline-bar--soon';
                    $bar_icon  = '⏰';
                    $bar_text  = sprintf( __( 'Plazo próximo: %s (%d días restantes)', 'monetawp' ), date_i18n( 'd M Y', strtotime( $deadline ) ), $days_left );
                } else {
                    $bar_class = 'deadline-bar--ok';
                    $bar_icon  = '🟢';
                    $bar_text  = $deadline
                        ? sprintf( __( 'Convocatoria abierta hasta el %s', 'monetawp' ), date_i18n( 'd M Y', strtotime( $deadline ) ) )
                        : __( 'Convocatoria abierta', 'monetawp' );
                }
            ?>

                <!-- Banner deadline -->
                <div class="deadline-bar <?php echo esc_attr( $bar_class ); ?>" data-deadline="<?php echo esc_attr( $deadline ); ?>">
                    <span><?php echo $bar_icon; ?></span>
                    <span><?php echo esc_html( $bar_text ); ?></span>
                </div>

                <!-- Cabecera -->
                <header class="entry-header">
                    <h1 class="entry-title"><?php the_title(); ?></h1>

                    <div class="entry-meta">
                        <?php
                        $tipos = get_the_terms( get_the_ID(), 'tipo_ayuda' );
                        if ( $tipos && ! is_wp_error( $tipos ) ) :
                            foreach ( $tipos as $tipo ) : ?>
                                <a href="<?php echo esc_url( get_term_link( $tipo ) ); ?>"><?php echo esc_html( $tipo->name ); ?></a>
                            <?php endforeach;
                        endif;
                        ?>
                        <span class="estado-pill estado-pill--<?php echo esc_attr( $estado ); ?>">
                            <?php echo esc_html( ucfirst( $estado ) ); ?>
                        </span>
                    </div>

                    <?php if ( has_post_thumbnail() ) :
                        the_post_thumbnail( 'ae-hero', [
                            'loading' => 'eager',
                            'style'   => 'width:100%;border-radius:8px;margin-bottom:1.5rem;',
                            'alt'     => the_title_attribute( [ 'echo' => false ] ),
                        ] );
                    endif; ?>
                </header>

                <!-- Meta rápido -->
                <div class="convocatoria-meta">
                    <?php if ( $amount ) : ?>
                        <div class="conv-meta-item">
                            <span class="conv-meta-label">💰 <?php _e( 'Importe', 'monetawp' ); ?></span>
                            <span class="conv-meta-value"><?php echo esc_html( $amount ); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if ( $organismo ) : ?>
                        <div class="conv-meta-item">
                            <span class="conv-meta-label">🏛️ <?php _e( 'Organismo', 'monetawp' ); ?></span>
                            <span class="conv-meta-value"><?php echo esc_html( $organismo ); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if ( $deadline ) : ?>
                        <div class="conv-meta-item">
                            <span class="conv-meta-label">📅 <?php _e( 'Plazo límite', 'monetawp' ); ?></span>
                            <span class="conv-meta-value"><?php echo esc_html( date_i18n( 'd/m/Y', strtotime( $deadline ) ) ); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php
                    $beneficiarios = get_the_terms( get_the_ID(), 'beneficiario' );
                    if ( $beneficiarios && ! is_wp_error( $beneficiarios ) ) :
                        $ben_names = wp_list_pluck( $beneficiarios, 'name' );
                    ?>
                        <div class="conv-meta-item">
                            <span class="conv-meta-label">👥 <?php _e( 'Para', 'monetawp' ); ?></span>
                            <span class="conv-meta-value"><?php echo esc_html( implode( ', ', $ben_names ) ); ?></span>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Enlace oficial destacado -->
                <?php if ( $url_boe ) : ?>
                    <p style="margin-bottom:1.5rem;">
                        <a href="<?php echo esc_url( $url_boe ); ?>" target="_blank" rel="noopener noreferrer" class="btn btn--danger">
                            📄 <?php _e( 'Ver convocatoria oficial', 'monetawp' ); ?> →
                        </a>
                    </p>
                <?php endif; ?>

                <!-- Contenido -->
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>

                <!-- Share -->
                <?php mw_share_buttons(); ?>

            <?php endwhile; ?>
        </article>

        <!-- Sidebar -->
        <aside class="sidebar" role="complementary">
            <?php mw_ad_zone( 'adsense-sidebar' ); ?>
        </aside>

    </div>
</div>

<?php get_footer();
