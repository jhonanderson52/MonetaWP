<?php
/**
 * Archivo de convocatorias — lista todas las convocatorias.
 */
get_header();
?>

<div class="archive-header">
    <div class="container">
        <h1>🏆 <?php _e( 'Todas las Convocatorias', 'monetawp' ); ?></h1>
        <p><?php _e( 'Encuentra todas las ayudas y convocatorias abiertas en España.', 'monetawp' ); ?></p>
    </div>
</div>

<div class="container" style="padding-bottom:3rem;">
    <div class="card-grid card-grid--3col">
        <?php if ( have_posts() ) :
            while ( have_posts() ) : the_post();
                get_template_part( 'template-parts/content', 'convocatoria' );
            endwhile;
        else :
            get_template_part( 'template-parts/content', 'none' );
        endif; ?>
    </div>

    <?php the_posts_pagination( [ 'prev_text' => '← Anterior', 'next_text' => 'Siguiente →' ] ); ?>
</div>

<?php get_footer();
