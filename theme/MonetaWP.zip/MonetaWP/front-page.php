<?php
/**
 * Homepage — Portada del blog global.
 * Composición de template-parts por secciones.
 */
get_header();
?>

<!-- ═══ HERO ══════════════════════════════════════════════════════════════ -->
<?php get_template_part( 'template-parts/hero' ); ?>

<!-- ═══ GRID DE PAÍSES ════════════════════════════════════════════════════ -->
<?php get_template_part( 'template-parts/countries-grid' ); ?>

<!-- ═══ ZONA DE ANUNCIO: ENTRE SECCIONES ════════════════════════════════ -->
<?php get_template_part( 'template-parts/ad-zone', 'between-sections' ); ?>

<!-- ═══ ENCUENTRA AYUDAS PARA TI (SEGMENTOS) ══════════════════════════════ -->
<?php get_template_part( 'template-parts/beneficiary-segments' ); ?>

<!-- ═══ ZONA DE ANUNCIO: ENTRE SECCIONES ════════════════════════════════ -->
<?php get_template_part( 'template-parts/ad-zone', 'between-sections' ); ?>

<!-- ═══ CATEGORÍAS (PILLS) ════════════════════════════════════════════════ -->
<?php get_template_part( 'template-parts/comunidades-grid' ); ?>

<!-- ═══ TARJETAS DESTACADAS ══════════════════════════════════════════════ -->
<?php if ( get_theme_mod( 'mw_featured_visible', true ) ) :
    get_template_part( 'template-parts/featured-convocatorias' );
endif; ?>

<!-- ═══ ÚLTIMOS ARTÍCULOS ════════════════════════════════════════════════ -->
<?php get_template_part( 'template-parts/latest-articles' ); ?>

<?php get_footer();
