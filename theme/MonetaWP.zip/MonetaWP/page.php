<?php
/**
 * Página estática (Aviso Legal, Política de Privacidad, Contacto, etc.)
 */
get_header();
?>

<div class="container" style="padding-top:2rem;padding-bottom:3rem;max-width:800px;">
    <?php while ( have_posts() ) : the_post(); ?>
        <article <?php post_class(); ?>>
            <h1 class="entry-title"><?php the_title(); ?></h1>
            <div class="entry-content" style="margin-top:1.5rem;">
                <?php the_content(); ?>
            </div>
        </article>
    <?php endwhile; ?>
</div>

<?php get_footer();
