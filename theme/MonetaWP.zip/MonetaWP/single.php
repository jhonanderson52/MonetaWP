<?php
/**
 * Single post — Artículo estándar (posts de tipo 'post').
 */
get_header();
?>

<div class="container" style="padding-top:1.5rem;padding-bottom:3rem;">
    <div class="content-area content-area--with-sidebar">

        <article class="main-content" <?php post_class(); ?>>
            <?php while ( have_posts() ) : the_post(); ?>

                <!-- Cabecera del artículo -->
                <header class="entry-header">
                    <h1 class="entry-title"><?php the_title(); ?></h1>

                    <div class="entry-meta">
                        <!-- Categorías / Tipo de ayuda -->
                        <?php
                        $tipos = get_the_terms( get_the_ID(), 'tipo_ayuda' );
                        if ( $tipos && ! is_wp_error( $tipos ) ) :
                            foreach ( $tipos as $tipo ) :
                            ?>
                                <a href="<?php echo esc_url( get_term_link( $tipo ) ); ?>" class="meta-cat"><?php echo esc_html( $tipo->name ); ?></a>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <?php
                        $ccaa = get_the_terms( get_the_ID(), 'comunidad_autonoma' );
                        if ( $ccaa && ! is_wp_error( $ccaa ) ) :
                            $ccaa_term = reset( $ccaa );
                        ?>
                            <a href="<?php echo esc_url( get_term_link( $ccaa_term ) ); ?>" class="meta-region">📍 <?php echo esc_html( $ccaa_term->name ); ?></a>
                        <?php endif; ?>
                    </div>

                    <?php if ( has_post_thumbnail() ) : ?>
                        <figure class="entry-thumbnail">
                            <?php the_post_thumbnail( 'ae-hero', [
                                'loading' => 'eager',
                                'style'   => 'width:100%;border-radius:8px;margin-bottom:1.5rem;',
                                'alt'     => the_title_attribute( [ 'echo' => false ] ),
                            ] ); ?>
                        </figure>
                    <?php endif; ?>
                </header>

                <!-- Contenido (el ad in-content se inyecta via the_content filter) -->
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>

                <!-- Share buttons -->
                <?php mw_share_buttons(); ?>

            <?php endwhile; ?>
        </article>

        <!-- Sidebar (solo desktop via CSS) -->
        <aside class="sidebar" role="complementary">
            <?php mw_ad_zone( 'adsense-sidebar' ); ?>
        </aside>

    </div>
</div>

<?php
get_footer();
